/* global CBCodeTizer */
'use strict';

document.addEventListener('DOMContentLoaded', function () {
    var maxUpload = document.getElementById('cb-codetizer-max-upload');
    var defaultLang = document.getElementById('cb-codetizer-default-lang');
    var scanProfile = document.getElementById('cb-codetizer-scan-profile');
    var indentSize = document.getElementById('cb-codetizer-indent-size');
    var indentType = document.getElementById('cb-codetizer-indent-type');
    var saveBtn = document.getElementById('cb-codetizer-save-settings-btn');
    var resetBtn = document.getElementById('cb-codetizer-reset-settings-btn');
    var clearBtn = document.getElementById('cb-codetizer-clear-reports-btn');

    /**
     * Extract a human-readable message from an AJAX response.
     *
     * The WP AJAX contract is { success: bool, data: { message: string } | string | null }.
     * This helper tolerates all three shapes so showToast never receives an
     * object (which would render as "[object Object]").
     *
     * @param {Object} res   The response object from CBCodeTizer.ajax().
     * @param {string} fallback Default message when no message is available.
     * @returns {string} The message to display.
     */
    function errorMessage(res, fallback) {
        if (res && res.data) {
            if (typeof res.data === 'string') return res.data;
            if (res.data.message && typeof res.data.message === 'string') return res.data.message;
        }
        return fallback;
    }

    /**
     * Re-enable a button after a failure, with a short delay so the user
     * can read the error toast before clicking again.
     *
     * @param {HTMLButtonElement} btn The button to re-enable.
     */
    function reenableOnFailure(btn) {
        if (!btn) return;
        setTimeout(function () { btn.disabled = false; }, 1000);
    }

    if (!saveBtn) return;

    saveBtn.addEventListener('click', function () {
        var settings = {
            max_upload_size: maxUpload ? maxUpload.value : '',
            default_language: defaultLang ? defaultLang.value : '',
            scan_profile: scanProfile ? scanProfile.value : '',
            indent_size: indentSize ? indentSize.value : '',
            indent_type: indentType ? indentType.value : ''
        };
        saveBtn.disabled = true;
        CBCodeTizer.ajax('cb_codetizer_save_settings', { settings: JSON.stringify(settings) })
            .then(function (res) {
                if (res && res.success) {
                    CBCodeTizer.showToast('Settings saved successfully.', 'success');
                } else {
                    CBCodeTizer.showToast(errorMessage(res, 'Failed to save settings.'), 'error');
                }
            })
            .catch(function () {
                CBCodeTizer.showToast('Failed to save settings due to a network error.', 'error');
            })
            .then(function () {
                saveBtn.disabled = false;
            });
    });

    if (resetBtn) {
        resetBtn.addEventListener('click', function () {
            if (!confirm('Reset all settings to defaults?')) return;
            resetBtn.disabled = true;
            CBCodeTizer.ajax('cb_codetizer_reset_settings', {})
                .then(function (res) {
                    if (res && res.success) {
                        location.reload();
                    } else {
                        CBCodeTizer.showToast(errorMessage(res, 'Failed to reset settings.'), 'error');
                        resetBtn.disabled = false;
                    }
                })
                .catch(function () {
                    CBCodeTizer.showToast('Failed to reset settings due to a network error.', 'error');
                    resetBtn.disabled = false;
                });
        });
    }

    if (clearBtn) {
        clearBtn.addEventListener('click', function () {
            if (!confirm('Are you sure you want to delete ALL reports? This cannot be undone.')) return;
            clearBtn.disabled = true;
            CBCodeTizer.ajax('cb_codetizer_clear_reports', {})
                .then(function (res) {
                    if (res && res.success) {
                        CBCodeTizer.showToast('All reports cleared.', 'success');
                    } else {
                        CBCodeTizer.showToast(errorMessage(res, 'Failed to clear reports.'), 'error');
                    }
                })
                .catch(function () {
                    CBCodeTizer.showToast('Failed to clear reports due to a network error.', 'error');
                })
                .then(function () {
                    setTimeout(function () { clearBtn.disabled = false; }, 2000);
                });
        });
    }
});
