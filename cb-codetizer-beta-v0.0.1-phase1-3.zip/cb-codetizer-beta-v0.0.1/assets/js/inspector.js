/* global CBCodeTizer */
'use strict';

document.addEventListener('DOMContentLoaded', function () {
    var codeInput  = document.getElementById('cb-codetizer-code-input');
    var langSelect = document.getElementById('cb-codetizer-language-select');
    var fileUpload = document.getElementById('cb-codetizer-upload-file');
    var scanBtn    = document.getElementById('cb-codetizer-scan-btn');
    var progress   = document.getElementById('cb-codetizer-progress');
    var progressBar= document.getElementById('cb-codetizer-progress-bar');
    var resultsDiv = document.getElementById('cb-codetizer-results');

    if (!scanBtn || !codeInput) return;

    var lastReport = null;

    var extMap = {
        js: 'javascript', ts: 'javascript', php: 'php', html: 'html', htm: 'html',
        svg: 'svg', css: 'css', json: 'json', xml: 'xml', md: 'markdown',
        txt: 'txt', markdown: 'markdown'
    };

    if (fileUpload) {
        fileUpload.addEventListener('change', function () {
            var file = fileUpload.files[0];
            if (!file) return;
            var reader = new FileReader();
            reader.onload = function (e) {
                codeInput.value = e.target.result;
                if (langSelect && file.name) {
                    var ext = file.name.split('.').pop().toLowerCase();
                    if (extMap[ext]) langSelect.value = extMap[ext];
                }
            };
            reader.readAsText(file);
        });
    }

    scanBtn.addEventListener('click', function () {
        var code     = codeInput.value.trim();
        var language = langSelect ? langSelect.value : '';

        if (!code) {
            CBCodeTizer.showToast('Please enter or upload code to scan.', 'error');
            return;
        }

        if (progress)    progress.style.display = 'block';
        if (progressBar) progressBar.style.width = '30%';

        var ticker = setTimeout(function () {
            if (progressBar) progressBar.style.width = '70%';
        }, 300);

        CBCodeTizer.ajax('cb_codetizer_inspect', { code: code, language: language })
            .then(function (res) {
                clearTimeout(ticker);
                if (progressBar) progressBar.style.width = '100%';
                setTimeout(function () {
                    if (progress)    progress.style.display = 'none';
                    if (progressBar) progressBar.style.width = '0%';
                }, 500);

                if (res.success) {
                    lastReport = res.data;
                    renderResults(res.data);
                } else {
                    var msg = (res.data && res.data.message) ? res.data.message : 'Inspection failed.';
                    CBCodeTizer.showToast(msg, 'error');
                }
            })
            .catch(function () {
                clearTimeout(ticker);
                if (progress) progress.style.display = 'none';
                CBCodeTizer.showToast('Network error during inspection.', 'error');
            });
    });

    function escHtml(str) {
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function scoreClass(score) {
        if (score >= 80) return 'score-good';
        if (score >= 50) return 'score-warn';
        return 'score-danger';
    }

    function renderResults(data) {
        resultsDiv.innerHTML = '';

        // ── Original code preview ────────────────────────────────────────
        if (data.original_code) {
            var previewSection = document.createElement('div');
            previewSection.className = 'cb-codetizer-section';
            var previewTitle = document.createElement('h3');
            previewTitle.textContent = 'Original Code';
            previewSection.appendChild(previewTitle);
            var pre = document.createElement('pre');
            pre.className = 'cb-codetizer-code-block';
            var codeEl = document.createElement('code');
            codeEl.textContent = data.original_code;
            pre.appendChild(codeEl);
            previewSection.appendChild(pre);
            resultsDiv.appendChild(previewSection);
        }

        // ── Score header ─────────────────────────────────────────────────
        if (data.score !== undefined) {
            var header = document.createElement('div');
            header.className = 'cb-codetizer-score-header';

            var scoreNum = document.createElement('span');
            scoreNum.className = 'cb-codetizer-score-number ' + scoreClass(data.score);
            scoreNum.textContent = data.score + '/100';

            var detectedLang = document.createElement('span');
            detectedLang.className = 'cb-codetizer-detected-lang';
            detectedLang.textContent = 'Detected: ' + (data.language || 'unknown').toUpperCase();

            var summary = document.createElement('span');
            summary.className = 'cb-codetizer-score-summary';
            summary.textContent = data.summary || '';

            header.appendChild(scoreNum);
            header.appendChild(detectedLang);
            header.appendChild(summary);
            resultsDiv.appendChild(header);
        }

        // ── Threat counts ────────────────────────────────────────────────
        if (data.stats) {
            var stats = document.createElement('div');
            stats.className = 'cb-codetizer-stats-row';
            [
                { label: 'High',   val: data.threats_high   || data.stats.threats_high   || 0, cls: 'high'   },
                { label: 'Medium', val: data.threats_medium || data.stats.threats_medium || 0, cls: 'medium' },
                { label: 'Low',    val: data.threats_low    || data.stats.threats_low    || 0, cls: 'low'    },
                { label: 'Info',   val: data.threats_info   || data.stats.threats_info   || 0, cls: 'info'   },
            ].forEach(function (s) {
                var item = document.createElement('span');
                item.className = 'cb-stat-item severity-' + s.cls;
                item.innerHTML = '<strong>' + s.val + '</strong> ' + s.label;
                stats.appendChild(item);
            });
            resultsDiv.appendChild(stats);
        }

        // ── Threats list ─────────────────────────────────────────────────
        var threats = data.threats || [];
        if (threats.length > 0) {
            var section = document.createElement('div');
            section.className = 'cb-codetizer-section cb-threats-section';

            var title = document.createElement('h3');
            title.textContent = 'Threats Found (' + threats.length + ')';
            section.appendChild(title);

            threats.forEach(function (t) {
                var div = document.createElement('div');
                div.className = 'cb-codetizer-threat-item severity-' + (t.severity || 'info');
                div.innerHTML =
                    '<div class="cb-threat-header">' +
                        '<span class="cb-threat-type">' + escHtml(t.type || '') + '</span>' +
                        '<span class="cb-threat-badge badge-' + escHtml(t.severity || 'info') + '">' + escHtml(t.severity || 'info') + '</span>' +
                        '<span class="cb-threat-location">Line ' + (t.line || '?') + ', Col ' + (t.column || '?') + '</span>' +
                    '</div>' +
                    '<div class="cb-threat-desc">' + escHtml(t.description || '') + '</div>' +
                    '<div class="cb-threat-snippet"><code>' + (t.snippet || '').slice(0, 200) + '</code></div>' +
                    '<div class="cb-threat-rec"><strong>Recommendation:</strong> ' + escHtml(t.recommendation || '') + '</div>';
                section.appendChild(div);
            });

            resultsDiv.appendChild(section);
        } else {
            var cleanMsg = document.createElement('div');
            cleanMsg.className = 'cb-codetizer-clean-msg';
            cleanMsg.textContent = 'No threats detected. The code appears safe.';
            resultsDiv.appendChild(cleanMsg);
        }

        // ── Recommendations ───────────────────────────────────────────────
        if (data.recommendations && data.recommendations.length > 0) {
            var recSection = document.createElement('div');
            recSection.className = 'cb-codetizer-section';
            var recTitle = document.createElement('h3');
            recTitle.textContent = 'Recommendations';
            recSection.appendChild(recTitle);
            var ul = document.createElement('ul');
            data.recommendations.forEach(function (r) {
                var li = document.createElement('li');
                li.textContent = r;
                ul.appendChild(li);
            });
            recSection.appendChild(ul);
            resultsDiv.appendChild(recSection);
        }

        // ── Download buttons ──────────────────────────────────────────────
        var dlSection = document.createElement('div');
        dlSection.className = 'cb-codetizer-action-buttons';

        var dlJsonBtn = document.createElement('button');
        dlJsonBtn.type = 'button';
        dlJsonBtn.className = 'cb-codetizer-btn cb-codetizer-btn-secondary';
        dlJsonBtn.textContent = 'Download JSON Report';
        dlJsonBtn.addEventListener('click', function () {
            if (!lastReport) return;
            downloadText(JSON.stringify(lastReport, null, 2), 'inspection-report.json', 'application/json');
        });

        var dlCsvBtn = document.createElement('button');
        dlCsvBtn.type = 'button';
        dlCsvBtn.className = 'cb-codetizer-btn cb-codetizer-btn-secondary';
        dlCsvBtn.textContent = 'Download CSV Report';
        dlCsvBtn.addEventListener('click', function () {
            if (!lastReport) return;
            var csv = buildCsv(lastReport);
            downloadText(csv, 'inspection-report.csv', 'text/csv');
        });

        dlSection.appendChild(dlJsonBtn);
        dlSection.appendChild(dlCsvBtn);
        resultsDiv.appendChild(dlSection);
    }

    function buildCsv(data) {
        var rows = [
            ['Type', 'Severity', 'Line', 'Column', 'Description', 'Recommendation']
        ];
        (data.threats || []).forEach(function (t) {
            rows.push([
                t.type        || '',
                t.severity    || '',
                t.line        || '',
                t.column      || '',
                t.description || '',
                t.recommendation || ''
            ]);
        });
        return rows.map(function (row) {
            return row.map(function (cell) {
                var s = String(cell).replace(/"/g, '""');
                if (s.indexOf(',') !== -1 || s.indexOf('"') !== -1 || s.indexOf('\n') !== -1) {
                    s = '"' + s + '"';
                }
                return s;
            }).join(',');
        }).join('\r\n');
    }

    function downloadText(content, filename, mime) {
        var blob = new Blob([content], { type: mime });
        var url  = URL.createObjectURL(blob);
        var a    = document.createElement('a');
        a.href   = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }
});
