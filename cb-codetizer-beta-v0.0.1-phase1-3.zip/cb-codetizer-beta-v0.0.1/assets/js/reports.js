/* global CBCodeTizer */
'use strict';

document.addEventListener('DOMContentLoaded', function () {
    var searchInput = document.getElementById('cb-codetizer-research-input');
    var filterSelect= document.getElementById('cb-codetizer-filter-select');
    var tbody       = document.getElementById('cb-codetizer-reports-tbody');
    var exportBtn   = document.getElementById('cb-codetizer-export-csv-btn');
    var clearBtn    = document.getElementById('cb-codetizer-clear-reports-btn');
    var paginationEl= document.getElementById('cb-codetizer-reports-pagination');

    if (!tbody) return;

    var currentPage  = 1;
    var perPage      = 20;
    var debounceTimer= null;

    // ── Initial load ──────────────────────────────────────────────────────
    loadReports();

    // ── Search / filter ───────────────────────────────────────────────────
    if (searchInput) {
        searchInput.addEventListener('input', function () {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(function () {
                currentPage = 1;
                loadReports();
            }, 400);
        });
    }

    if (filterSelect) {
        filterSelect.addEventListener('change', function () {
            currentPage = 1;
            loadReports();
        });
    }

    // ── Load and render ───────────────────────────────────────────────────
    function loadReports() {
        tbody.innerHTML = '<tr><td colspan="9" class="cb-codetizer-no-data">Loading…</td></tr>';

        CBCodeTizer.ajax('cb_codetizer_get_reports', {
            search  : searchInput   ? searchInput.value   : '',
            filter  : filterSelect  ? filterSelect.value  : '',
            page    : currentPage,
            per_page: perPage
        }).then(function (res) {
            tbody.innerHTML = '';

            if (!res.success) {
                tbody.innerHTML = '<tr><td colspan="9" class="cb-codetizer-no-data">' +
                    escHtml((res.data && res.data.message) || 'Failed to load reports.') + '</td></tr>';
                return;
            }

            var data    = res.data;
            var reports = data.reports || [];

            if (reports.length === 0) {
                tbody.innerHTML = '<tr><td colspan="9" class="cb-codetizer-no-data">No reports found.</td></tr>';
                renderPagination(0, 0);
                return;
            }

            reports.forEach(function (r) {
                var tr = document.createElement('tr');

                // ID
                var tdId = document.createElement('td');
                tdId.textContent = r.id || '';
                tr.appendChild(tdId);

                // Type badge
                var tdType = document.createElement('td');
                var badge  = document.createElement('span');
                badge.className  = 'cb-codetizer-badge cb-codetizer-badge-' + escHtml(r.type || 'default');
                badge.textContent= r.type || '';
                tdType.appendChild(badge);
                tr.appendChild(tdType);

                // Language
                var tdLang = document.createElement('td');
                tdLang.textContent = (r.language || '').toUpperCase();
                tr.appendChild(tdLang);

                // Score
                var tdScore = document.createElement('td');
                if (r.score !== undefined && r.score !== null) {
                    var scoreSpan = document.createElement('span');
                    var scoreVal  = parseInt(r.score, 10);
                    scoreSpan.textContent = scoreVal + '/100';
                    scoreSpan.className = 'cb-score-inline ' + (
                        scoreVal >= 80 ? 'score-good' : scoreVal >= 50 ? 'score-warn' : 'score-danger'
                    );
                    tdScore.appendChild(scoreSpan);
                } else {
                    tdScore.textContent = r.type === 'beautifier' ? 'N/A' : '—';
                }
                tr.appendChild(tdScore);

                // Input summary
                var tdSummary = document.createElement('td');
                tdSummary.className = 'cb-report-summary';
                tdSummary.textContent = truncate(r.summary || '', 80);
                tdSummary.title = r.summary || '';
                tr.appendChild(tdSummary);

                // Threats
                var tdThreats = document.createElement('td');
                var tCount = parseInt(r.threats, 10) || 0;
                if (tCount > 0) {
                    var tSpan = document.createElement('span');
                    tSpan.className = 'cb-threat-count cb-threat-count-danger';
                    tSpan.textContent = tCount;
                    tdThreats.appendChild(tSpan);
                } else {
                    tdThreats.textContent = '0';
                }
                tr.appendChild(tdThreats);

                // Severity summary
                var tdSev = document.createElement('td');
                tdSev.className = 'cb-report-severity';
                tdSev.textContent = truncate(r.severity || '', 60);
                tdSev.title = r.severity || '';
                tr.appendChild(tdSev);

                // Date
                var tdDate = document.createElement('td');
                tdDate.textContent = formatDate(r.date || '');
                tr.appendChild(tdDate);

                // Actions
                var tdActions = document.createElement('td');
                var delBtn    = document.createElement('button');
                delBtn.type      = 'button';
                delBtn.className = 'cb-codetizer-btn cb-codetizer-btn-danger cb-btn-sm';
                delBtn.textContent = 'Delete';
                delBtn.setAttribute('data-confirm', 'Delete this report?');
                delBtn.addEventListener('click', function () {
                    if (!confirm('Delete this report?')) return;
                    deleteReport(r.id, tr);
                });
                tdActions.appendChild(delBtn);
                tr.appendChild(tdActions);

                tbody.appendChild(tr);
            });

            renderPagination(data.total || 0, data.pages || 1);
        }).catch(function () {
            tbody.innerHTML = '<tr><td colspan="9" class="cb-codetizer-no-data">Network error loading reports.</td></tr>';
        });
    }

    function deleteReport(id, trEl) {
        CBCodeTizer.ajax('cb_codetizer_delete_report', { report_id: id })
            .then(function (res) {
                if (res.success) {
                    trEl.remove();
                    CBCodeTizer.showToast('Report deleted.', 'success');
                    // If table is now empty, reload.
                    if (!tbody.querySelector('tr')) loadReports();
                } else {
                    CBCodeTizer.showToast((res.data && res.data.message) || 'Failed to delete.', 'error');
                }
            })
            .catch(function () {
                CBCodeTizer.showToast('Failed to delete report due to a network error.', 'error');
            });
    }

    // ── Pagination ────────────────────────────────────────────────────────
    function renderPagination(total, pages) {
        if (!paginationEl) return;
        paginationEl.innerHTML = '';

        if (pages <= 1) return;

        for (var i = 1; i <= pages; i++) {
            (function (page) {
                var btn = document.createElement('button');
                btn.type      = 'button';
                btn.className = 'cb-codetizer-btn cb-btn-sm' + (page === currentPage ? ' cb-btn-active' : '');
                btn.textContent = page;
                btn.addEventListener('click', function () {
                    currentPage = page;
                    loadReports();
                });
                paginationEl.appendChild(btn);
            })(i);
        }

        var info = document.createElement('span');
        info.className = 'cb-pagination-info';
        info.textContent = 'Total: ' + total;
        paginationEl.appendChild(info);
    }

    // ── Export CSV ────────────────────────────────────────────────────────
    if (exportBtn) {
        exportBtn.addEventListener('click', function () {
            exportBtn.disabled = true;
            CBCodeTizer.ajax('cb_codetizer_export_csv', {})
                .then(function (res) {
                    if (res.success && res.data && res.data.csv) {
                        var blob = new Blob([res.data.csv], { type: 'text/csv;charset=utf-8;' });
                        var url  = URL.createObjectURL(blob);
                        var a    = document.createElement('a');
                        a.href   = url;
                        a.download = 'cb-codetizer-reports.csv';
                        document.body.appendChild(a);
                        a.click();
                        document.body.removeChild(a);
                        URL.revokeObjectURL(url);
                        CBCodeTizer.showToast('CSV export downloaded.', 'success');
                    } else {
                        CBCodeTizer.showToast((res.data && res.data.message) || 'No reports to export.', 'error');
                    }
                })
                .catch(function () {
                    CBCodeTizer.showToast('Failed to export CSV due to a network error.', 'error');
                })
                .then(function () {
                    exportBtn.disabled = false;
                });
        });
    }

    // ── Clear all ─────────────────────────────────────────────────────────
    if (clearBtn) {
        clearBtn.addEventListener('click', function () {
            if (!confirm('Clear all reports? This cannot be undone.')) return;
            clearBtn.disabled = true;
            CBCodeTizer.ajax('cb_codetizer_clear_reports', {})
                .then(function (res) {
                    if (res.success) {
                        CBCodeTizer.showToast('All reports cleared.', 'success');
                        currentPage = 1;
                        loadReports();
                    } else {
                        CBCodeTizer.showToast((res.data && res.data.message) || 'Failed to clear reports.', 'error');
                    }
                })
                .catch(function () {
                    CBCodeTizer.showToast('Failed to clear reports due to a network error.', 'error');
                })
                .then(function () {
                    clearBtn.disabled = false;
                });
        });
    }

    // ── Helpers ───────────────────────────────────────────────────────────
    function truncate(str, maxLen) {
        if (!str) return '';
        return str.length > maxLen ? str.slice(0, maxLen) + '…' : str;
    }

    function formatDate(dateStr) {
        if (!dateStr) return '';
        try {
            var d = new Date(dateStr.replace(' ', 'T'));
            if (isNaN(d.getTime())) return dateStr;
            return d.toLocaleDateString() + ' ' + d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
        } catch (e) {
            return dateStr;
        }
    }

    function escHtml(str) {
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }
});
