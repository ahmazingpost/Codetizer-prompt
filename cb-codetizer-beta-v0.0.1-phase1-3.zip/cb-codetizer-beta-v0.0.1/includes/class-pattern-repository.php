<?php
/**
 * CB CODETIZER - Pattern Repository
 *
 * The single authoritative source for all security rules used by the
 * Inspector and Sanitizer engines. Each rule is defined once here and
 * consumed by both engines, eliminating pattern duplication and drift.
 *
 * Rule metadata structure:
 *   - id:                    Unique rule identifier (e.g., 'php.eval')
 *   - category:              Rule category (code_execution, xss, xxe, etc.)
 *   - severity:              Threat severity (high, medium, low, info)
 *   - description:           Human-readable threat description
 *   - recommendation:        Actionable recommendation for fixing the threat
 *   - languages:             Array of language identifiers this rule applies to
 *   - pattern:               The regex pattern string (including delimiters and modifiers)
 *   - case_insensitive:      Whether the pattern uses /i (true for PHP function names,
 *                             HTML/CSS attributes; false for JS function names and JSON keys)
 *   - inspector:             Whether the Inspector should report this as a threat
 *   - sanitizer:             Whether the Sanitizer should attempt automatic remediation
 *   - auto_remediation:      Whether automatic remediation is safe (true) or manual
 *                             review is required (false)
 *   - manual_review:         Whether this threat always requires manual review
 *   - sanitizer_type:        The type identifier used in removed_items entries
 *   - sanitizer_replacement: The replacement string for preg_replace (or null if N/A)
 *   - profiles:              Which scan profiles include this rule ('standard', 'strict')
 *
 * Case Sensitivity Strategy:
 *   - PHP function names are case-insensitive in PHP, so patterns for PHP
 *     built-in functions (eval, system, unserialize, etc.) use the /i modifier.
 *     This ensures EvAl(), SYSTEM(), etc. are detected.
 *   - JavaScript function names are case-sensitive, so patterns for JS
 *     built-in functions (eval, document.write, etc.) do NOT use /i.
 *     EvAl() is not valid JS and would throw a ReferenceError.
 *   - HTML/SVG/CSS are case-insensitive, so their patterns use /i.
 *   - JSON keys are case-sensitive, so __proto__ patterns do NOT use /i.
 *     __PROTO__ is not a valid prototype-pollution key.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CB_Codetizer_Pattern_Repository
 *
 * Provides a centralized registry of security rules. Both the Inspector
 * and Sanitizer engines query this repository instead of maintaining
 * their own inline pattern definitions.
 */
class CB_Codetizer_Pattern_Repository {

	/**
	 * The master rule definitions.
	 *
	 * @var array<string, array>
	 */
	private static array $rules = array();

	/**
	 * Whether the rules have been initialized.
	 *
	 * @var bool
	 */
	private static bool $initialized = false;

	/**
	 * Initialize the default rule set.
	 *
	 * Populates the repository with all built-in security rules. This is
	 * called lazily on the first access. Third-party code can register
	 * additional rules via register_rule() after initialization.
	 *
	 * @return void
	 */
	private static function init(): void {
		if ( self::$initialized ) {
			return;
		}

		$rules = array(

			// ════════════════════════════════════════════════════════════════
			// PHP RULES
			// PHP function names are case-insensitive, so all PHP function
			// patterns use the /i modifier to detect EvAl(), SYSTEM(), etc.
			// ════════════════════════════════════════════════════════════════

			'php.eval' => array(
				'id'           => 'php.eval',
				'category'     => 'code_execution',
				'severity'     => 'high',
				'description'  => 'eval() — arbitrary code execution.',
				'recommendation' => 'Avoid eval() entirely. Use safer alternatives like call_user_func() with validated input.',
				'languages'    => array( 'php' ),
				'pattern'      => '/\beval\s*\(/i',
				'case_insensitive' => true,
				'inspector'    => true,
				'sanitizer'    => true,
				'auto_remediation' => true,
				'manual_review' => false,
				'sanitizer_type' => 'php_eval',
				'sanitizer_replacement' => '/* CB_EVAL_REMOVED */ (',
				'profiles'     => array( 'standard', 'strict' ),
			),

			'php.command_execution' => array(
				'id'           => 'php.command_execution',
				'category'     => 'code_execution',
				'severity'     => 'high',
				'description'  => 'Command execution function (system/exec/passthru/shell_exec/proc_open/popen).',
				'recommendation' => 'Avoid shell commands. If unavoidable, use escapeshellarg()/escapeshellcmd() on all inputs.',
				'languages'    => array( 'php' ),
				'pattern'      => '/\b(system|exec|passthru|shell_exec|proc_open|popen)\s*\(/i',
				'case_insensitive' => true,
				'inspector'    => true,
				'sanitizer'    => true,
				'auto_remediation' => true,
				'manual_review' => false,
				'sanitizer_type' => 'php_command_execution',
				'sanitizer_replacement' => '/* CB_CMD_REMOVED */ (',
				'profiles'     => array( 'standard', 'strict' ),
			),

			'php.superglobal_output' => array(
				'id'           => 'php.superglobal_output',
				'category'     => 'xss',
				'severity'     => 'high',
				'description'  => 'Direct output of superglobal ($_GET/$_POST/$_REQUEST/$_COOKIE/$_SERVER) — XSS risk.',
				'recommendation' => 'Always escape output with esc_html()/esc_url()/wp_kses_post() before printing.',
				'languages'    => array( 'php' ),
				'pattern'      => '/(?:echo|print)\s.*\$(_GET|_POST|_REQUEST|_COOKIE|_SERVER)\b/i',
				'case_insensitive' => true,
				'inspector'    => true,
				'sanitizer'    => true,
				'auto_remediation' => false,
				'manual_review' => true,
				'sanitizer_type' => 'php_superglobal_output',
				'sanitizer_replacement' => null,
				'profiles'     => array( 'standard', 'strict' ),
			),

			'php.preg_replace_e' => array(
				'id'           => 'php.preg_replace_e',
				'category'     => 'code_execution',
				'severity'     => 'high',
				'description'  => 'preg_replace() with /e modifier — code execution via regex.',
				'recommendation' => 'Use preg_replace_callback() instead of the /e modifier.',
				'languages'    => array( 'php' ),
				'pattern'      => '/preg_replace\s*\(\s*["''][^"'']*\/e[^"'']*["'']/i',
				'case_insensitive' => true,
				'inspector'    => true,
				'sanitizer'    => true,
				'auto_remediation' => true,
				'manual_review' => false,
				'sanitizer_type' => 'php_preg_replace_e',
				'sanitizer_replacement' => '/* CB_PREG_E_REMOVED */ (',
				'profiles'     => array( 'standard', 'strict' ),
			),

			'php.dynamic_include' => array(
				'id'           => 'php.dynamic_include',
				'category'     => 'code_execution',
				'severity'     => 'high',
				'description'  => 'Dynamic include/require with variable — LFI/RFI risk.',
				'recommendation' => 'Use a fixed allowlist of file paths. Never include user-controlled input.',
				'languages'    => array( 'php' ),
				'pattern'      => '/(?:include|require|include_once|require_once)\s*\(\s*\$/i',
				'case_insensitive' => true,
				'inspector'    => true,
				'sanitizer'    => true,
				'auto_remediation' => false,
				'manual_review' => true,
				'sanitizer_type' => 'php_dynamic_include',
				'sanitizer_replacement' => null,
				'profiles'     => array( 'standard', 'strict' ),
			),

			'php.unserialize' => array(
				'id'           => 'php.unserialize',
				'category'     => 'code_execution',
				'severity'     => 'high',
				'description'  => 'unserialize() — object injection / POP chain risk.',
				'recommendation' => 'Use json_decode() instead. If unserialize is required, pass allowed_classes option.',
				'languages'    => array( 'php' ),
				'pattern'      => '/\bunserialize\s*\(/i',
				'case_insensitive' => true,
				'inspector'    => true,
				'sanitizer'    => true,
				'auto_remediation' => true,
				'manual_review' => false,
				'sanitizer_type' => 'php_unserialize',
				'sanitizer_replacement' => '/* CB_UNSERIALIZE_REMOVED */ (',
				'profiles'     => array( 'standard', 'strict' ),
			),

			'php.extract' => array(
				'id'           => 'php.extract',
				'category'     => 'code_execution',
				'severity'     => 'medium',
				'description'  => 'extract() — variable overwrite risk.',
				'recommendation' => 'Avoid extract() with user input. Use explicit variable assignment.',
				'languages'    => array( 'php' ),
				'pattern'      => '/\bextract\s*\(/i',
				'case_insensitive' => true,
				'inspector'    => true,
				'sanitizer'    => false,
				'auto_remediation' => false,
				'manual_review' => true,
				'sanitizer_type' => null,
				'sanitizer_replacement' => null,
				'profiles'     => array( 'standard', 'strict' ),
			),

			'php.assert' => array(
				'id'           => 'php.assert',
				'category'     => 'code_execution',
				'severity'     => 'medium',
				'description'  => 'assert() — code execution in PHP (evaluates string as code in PHP <8.0).',
				'recommendation' => 'Use if() for runtime checks. Disable assert.engine in production.',
				'languages'    => array( 'php' ),
				'pattern'      => '/\bassert\s*\(/i',
				'case_insensitive' => true,
				'inspector'    => true,
				'sanitizer'    => false,
				'auto_remediation' => false,
				'manual_review' => true,
				'sanitizer_type' => null,
				'sanitizer_replacement' => null,
				'profiles'     => array( 'standard', 'strict' ),
			),

			'php.backtick' => array(
				'id'           => 'php.backtick',
				'category'     => 'code_execution',
				'severity'     => 'medium',
				'description'  => 'Backtick operator — shell command execution.',
				'recommendation' => 'Replace backticks with explicit shell_exec() or safer alternatives.',
				'languages'    => array( 'php' ),
				'pattern'      => '/`[^`]+`/',
				'case_insensitive' => false,
				'inspector'    => true,
				'sanitizer'    => true,
				'auto_remediation' => true,
				'manual_review' => false,
				'sanitizer_type' => 'php_backtick',
				'sanitizer_replacement' => '/* CB_BACKTICK_REMOVED */',
				'profiles'     => array( 'standard', 'strict' ),
			),

			'php.file_operations' => array(
				'id'           => 'php.file_operations',
				'category'     => 'file_access',
				'severity'     => 'medium',
				'description'  => 'File operation with variable path — path traversal risk.',
				'recommendation' => 'Validate and sanitize file paths. Use realpath() to prevent traversal.',
				'languages'    => array( 'php' ),
				'pattern'      => '/\b(fopen|file_get_contents|file_put_contents|readfile|fread|fwrite|file|unlink|rename|copy|rmdir|mkdir)\s*\(\s*\$/i',
				'case_insensitive' => true,
				'inspector'    => true,
				'sanitizer'    => false,
				'auto_remediation' => false,
				'manual_review' => true,
				'sanitizer_type' => null,
				'sanitizer_replacement' => null,
				'profiles'     => array( 'standard', 'strict' ),
			),

			// ════════════════════════════════════════════════════════════════
			// JAVASCRIPT RULES
			// JS function names are case-sensitive, so patterns do NOT
			// use /i. EvAl() is not valid JS.
			// ════════════════════════════════════════════════════════════════

			'javascript.eval' => array(
				'id'           => 'javascript.eval',
				'category'     => 'code_execution',
				'severity'     => 'high',
				'description'  => 'eval() — arbitrary code execution.',
				'recommendation' => 'Avoid eval(). Use JSON.parse() for data, Function() for dynamic code (with caution).',
				'languages'    => array( 'javascript' ),
				'pattern'      => '/\beval\s*\(/',
				'case_insensitive' => false,
				'inspector'    => true,
				'sanitizer'    => true,
				'auto_remediation' => true,
				'manual_review' => false,
				'sanitizer_type' => 'js_eval',
				'sanitizer_replacement' => '/* CB_EVAL_REMOVED */ (',
				'profiles'     => array( 'standard', 'strict' ),
			),

			'javascript.document_write' => array(
				'id'           => 'javascript.document_write',
				'category'     => 'xss',
				'severity'     => 'high',
				'description'  => 'document.write() — XSS risk, can inject arbitrary HTML.',
				'recommendation' => 'Use DOM manipulation methods (createElement, textContent) instead.',
				'languages'    => array( 'javascript' ),
				'pattern'      => '/document\.write\s*\(/',
				'case_insensitive' => false,
				'inspector'    => true,
				'sanitizer'    => true,
				'auto_remediation' => true,
				'manual_review' => false,
				'sanitizer_type' => 'js_document_write',
				'sanitizer_replacement' => '/* CB_DOCWRITE_REMOVED */ (',
				'profiles'     => array( 'standard', 'strict' ),
			),

			'javascript.innerhtml' => array(
				'id'           => 'javascript.innerhtml',
				'category'     => 'xss',
				'severity'     => 'high',
				'description'  => '.innerHTML assignment — XSS risk if value contains HTML.',
				'recommendation' => 'Use textContent for plain text, or sanitize HTML before assignment.',
				'languages'    => array( 'javascript' ),
				'pattern'      => '/\.innerHTML\s*=/',
				'case_insensitive' => false,
				'inspector'    => true,
				'sanitizer'    => true,
				'auto_remediation' => false,
				'manual_review' => true,
				'sanitizer_type' => 'js_innerhtml',
				'sanitizer_replacement' => null,
				'profiles'     => array( 'standard', 'strict' ),
			),

			'javascript.function_constructor' => array(
				'id'           => 'javascript.function_constructor',
				'category'     => 'code_execution',
				'severity'     => 'high',
				'description'  => 'new Function() — dynamic code execution.',
				'recommendation' => 'Avoid new Function(). Pre-define functions instead of constructing from strings.',
				'languages'    => array( 'javascript' ),
				'pattern'      => '/(?:^|[=(:,\s])\s*new\s+Function\s*\(/',
				'case_insensitive' => false,
				'inspector'    => true,
				'sanitizer'    => true,
				'auto_remediation' => true,
				'manual_review' => false,
				'sanitizer_type' => 'js_function_constructor',
				'sanitizer_replacement' => '/* CB_NEWFUNC_REMOVED */ (',
				'profiles'     => array( 'standard', 'strict' ),
			),

			'javascript.prototype_pollution' => array(
				'id'           => 'javascript.prototype_pollution',
				'category'     => 'code_execution',
				'severity'     => 'high',
				'description'  => 'Prototype pollution pattern (__proto__/constructor.prototype).',
				'recommendation' => 'Never assign to __proto__ or constructor.prototype. Use Object.create().',
				'languages'    => array( 'javascript' ),
				'pattern'      => '/(?:__proto__|constructor\.prototype|\.prototype\[)/',
				'case_insensitive' => false,
				'inspector'    => true,
				'sanitizer'    => true,
				'auto_remediation' => true,
				'manual_review' => false,
				'sanitizer_type' => 'js_prototype_pollution',
				'sanitizer_replacement' => null,
				'profiles'     => array( 'standard', 'strict' ),
			),

			'javascript.string_timer' => array(
				'id'           => 'javascript.string_timer',
				'category'     => 'code_execution',
				'severity'     => 'medium',
				'description'  => 'setTimeout/setInterval with string argument — implicit eval.',
				'recommendation' => 'Pass a function reference, not a string, to setTimeout/setInterval.',
				'languages'    => array( 'javascript' ),
				'pattern'      => '/\b(?:setTimeout|setInterval)\s*\(\s*["'']',
				'case_insensitive' => false,
				'inspector'    => true,
				'sanitizer'    => false,
				'auto_remediation' => false,
				'manual_review' => true,
				'sanitizer_type' => null,
				'sanitizer_replacement' => null,
				'profiles'     => array( 'standard', 'strict' ),
			),

			'javascript.postmessage' => array(
				'id'           => 'javascript.postmessage',
				'category'     => 'security',
				'severity'     => 'medium',
				'description'  => 'postMessage() without origin check — cross-origin data leak.',
				'recommendation' => 'Always verify event.origin in the message handler. Avoid wildcard target origin.',
				'languages'    => array( 'javascript' ),
				'pattern'      => '/\.postMessage\s*\(/',
				'case_insensitive' => false,
				'inspector'    => true,
				'sanitizer'    => true,
				'auto_remediation' => false,
				'manual_review' => true,
				'sanitizer_type' => 'js_postmessage',
				'sanitizer_replacement' => null,
				'profiles'     => array( 'standard', 'strict' ),
			),

			'javascript.location_manipulation' => array(
				'id'           => 'javascript.location_manipulation',
				'category'     => 'security',
				'severity'     => 'medium',
				'description'  => 'Location manipulation (window.location / location.href assignment).',
				'recommendation' => 'Validate URLs before redirecting. Use location.replace() for redirects.',
				'languages'    => array( 'javascript' ),
				'pattern'      => '/(?:window\.location(?:\.href|\.assign|\.replace)?|location\.href|location\.assign|location\.replace)\s*=/',
				'case_insensitive' => false,
				'inspector'    => true,
				'sanitizer'    => false,
				'auto_remediation' => false,
				'manual_review' => true,
				'sanitizer_type' => null,
				'sanitizer_replacement' => null,
				'profiles'     => array( 'strict' ),
			),

			'javascript.dom_clobbering' => array(
				'id'           => 'javascript.dom_clobbering',
				'category'     => 'security',
				'severity'     => 'medium',
				'description'  => 'DOM clobbering via document.forms/images/links/anchors/applets collections.',
				'recommendation' => 'Use getElementById() or querySelector() instead of named collection access.',
				'languages'    => array( 'javascript' ),
				'pattern'      => '/(?:document\.forms\[|document\.images\[|document\.links\[|document\.anchors\[|document\.applets\[)/',
				'case_insensitive' => false,
				'inspector'    => true,
				'sanitizer'    => false,
				'auto_remediation' => false,
				'manual_review' => true,
				'sanitizer_type' => null,
				'sanitizer_replacement' => null,
				'profiles'     => array( 'strict' ),
			),

			// ════════════════════════════════════════════════════════════════
			// HTML RULES (case-insensitive — HTML attributes/tags are CI)
			// ════════════════════════════════════════════════════════════════

			'html.script_tag' => array(
				'id'           => 'html.script_tag',
				'category'     => 'xss',
				'severity'     => 'high',
				'description'  => '<script> tag — script injection vector.',
				'recommendation' => 'Remove <script> tags. Use safe DOM methods for dynamic content.',
				'languages'    => array( 'html', 'svg', 'markdown' ),
				'pattern'      => '/<script\b/i',
				'case_insensitive' => true,
				'inspector'    => true,
				'sanitizer'    => true,
				'auto_remediation' => true,
				'manual_review' => false,
				'sanitizer_type' => 'script_tag',
				'sanitizer_replacement' => null,
				'profiles'     => array( 'standard', 'strict' ),
			),

			'html.javascript_url' => array(
				'id'           => 'html.javascript_url',
				'category'     => 'xss',
				'severity'     => 'high',
				'description'  => 'javascript: URL scheme — XSS vector.',
				'recommendation' => 'Remove javascript: URLs. Use safe URL schemes (http, https, mailto).',
				'languages'    => array( 'html', 'svg' ),
				'pattern'      => '/javascript\s*:/i',
				'case_insensitive' => true,
				'inspector'    => true,
				'sanitizer'    => true,
				'auto_remediation' => true,
				'manual_review' => false,
				'sanitizer_type' => 'dangerous_url',
				'sanitizer_replacement' => null,
				'profiles'     => array( 'standard', 'strict' ),
			),

			'html.vbscript_url' => array(
				'id'           => 'html.vbscript_url',
				'category'     => 'xss',
				'severity'     => 'high',
				'description'  => 'vbscript: URL scheme — XSS vector (legacy IE).',
				'recommendation' => 'Remove vbscript: URLs.',
				'languages'    => array( 'html', 'svg' ),
				'pattern'      => '/vbscript\s*:/i',
				'case_insensitive' => true,
				'inspector'    => true,
				'sanitizer'    => true,
				'auto_remediation' => true,
				'manual_review' => false,
				'sanitizer_type' => 'dangerous_url',
				'sanitizer_replacement' => null,
				'profiles'     => array( 'standard', 'strict' ),
			),

			'html.embedded_content' => array(
				'id'           => 'html.embedded_content',
				'category'     => 'xss',
				'severity'     => 'medium',
				'description'  => 'Embedded content (iframe/embed/object) — third-party content risk.',
				'recommendation' => 'Remove embedded content or use sandbox attribute with strict allowlist.',
				'languages'    => array( 'html' ),
				'pattern'      => '/<(iframe|embed|object)\b/i',
				'case_insensitive' => true,
				'inspector'    => true,
				'sanitizer'    => true,
				'auto_remediation' => true,
				'manual_review' => false,
				'sanitizer_type' => 'embedded_content',
				'sanitizer_replacement' => null,
				'profiles'     => array( 'standard', 'strict' ),
			),

			// ════════════════════════════════════════════════════════════════
			// CSS RULES (case-insensitive — CSS is CI)
			// ════════════════════════════════════════════════════════════════

			'css.expression' => array(
				'id'           => 'css.expression',
				'category'     => 'xss',
				'severity'     => 'high',
				'description'  => 'CSS expression() — script execution in legacy IE.',
				'recommendation' => 'Remove CSS expressions. They are deprecated and unsupported in modern browsers.',
				'languages'    => array( 'css' ),
				'pattern'      => '/expression\s*\(/i',
				'case_insensitive' => true,
				'inspector'    => true,
				'sanitizer'    => true,
				'auto_remediation' => true,
				'manual_review' => false,
				'sanitizer_type' => 'css_expression',
				'sanitizer_replacement' => null,
				'profiles'     => array( 'standard', 'strict' ),
			),

			'css.moz_binding' => array(
				'id'           => 'css.moz_binding',
				'category'     => 'xss',
				'severity'     => 'high',
				'description'  => '-moz-binding — XBL binding (Firefox, deprecated) — script execution.',
				'recommendation' => 'Remove -moz-binding. It is deprecated and unsupported.',
				'languages'    => array( 'css' ),
				'pattern'      => '/\-moz\-binding\s*:/i',
				'case_insensitive' => true,
				'inspector'    => true,
				'sanitizer'    => true,
				'auto_remediation' => true,
				'manual_review' => false,
				'sanitizer_type' => 'css_moz_binding',
				'sanitizer_replacement' => null,
				'profiles'     => array( 'standard', 'strict' ),
			),

			'css.import' => array(
				'id'           => 'css.import',
				'category'     => 'security',
				'severity'     => 'medium',
				'description'  => '@import — external stylesheet loading (SSRF/performance risk).',
				'recommendation' => 'Inline critical CSS or use <link> with integrity attribute.',
				'languages'    => array( 'css' ),
				'pattern'      => '/@import\s/i',
				'case_insensitive' => true,
				'inspector'    => true,
				'sanitizer'    => false,
				'auto_remediation' => false,
				'manual_review' => true,
				'sanitizer_type' => null,
				'sanitizer_replacement' => null,
				'profiles'     => array( 'standard', 'strict' ),
			),

			'css.dangerous_url' => array(
				'id'           => 'css.dangerous_url',
				'category'     => 'xss',
				'severity'     => 'high',
				'description'  => 'CSS url() with javascript: or data: scheme — XSS vector.',
				'recommendation' => 'Remove dangerous URL schemes from url(). Use safe relative or https URLs.',
				'languages'    => array( 'css' ),
				'pattern'      => '/url\s*\(\s*["'']?\s*(?:javascript|data)\s*:/i',
				'case_insensitive' => true,
				'inspector'    => true,
				'sanitizer'    => true,
				'auto_remediation' => true,
				'manual_review' => false,
				'sanitizer_type' => 'css_dangerous_url',
				'sanitizer_replacement' => null,
				'profiles'     => array( 'standard', 'strict' ),
			),

			'css.behavior' => array(
				'id'           => 'css.behavior',
				'category'     => 'xss',
				'severity'     => 'medium',
				'description'  => 'CSS behavior: — HTC binding (IE, deprecated) — script execution.',
				'recommendation' => 'Remove CSS behavior. It is IE-only and deprecated.',
				'languages'    => array( 'css' ),
				'pattern'      => '/behavior\s*:/i',
				'case_insensitive' => true,
				'inspector'    => true,
				'sanitizer'    => true,
				'auto_remediation' => true,
				'manual_review' => false,
				'sanitizer_type' => 'css_behavior',
				'sanitizer_replacement' => null,
				'profiles'     => array( 'standard', 'strict' ),
			),

			// ════════════════════════════════════════════════════════════════
			// JSON RULES (case-SENSITIVE — JSON keys are CS)
			// ════════════════════════════════════════════════════════════════

			'json.prototype_key' => array(
				'id'           => 'json.prototype_key',
				'category'     => 'prototype_pollution',
				'severity'     => 'high',
				'description'  => 'Prototype pollution key (__proto__/constructor/prototype) in JSON.',
				'recommendation' => 'Remove prototype-pollution keys. The structural sanitizer handles this recursively.',
				'languages'    => array( 'json' ),
				'pattern'      => '/"(?:__proto__|constructor|prototype)"\s*:/',
				'case_insensitive' => false,
				'inspector'    => true,
				'sanitizer'    => true,
				'auto_remediation' => true,
				'manual_review' => false,
				'sanitizer_type' => 'json_prototype_key',
				'sanitizer_replacement' => null,
				'profiles'     => array( 'standard', 'strict' ),
			),

			// ════════════════════════════════════════════════════════════════
			// XML RULES (case-insensitive)
			// ════════════════════════════════════════════════════════════════

			'xml.entity' => array(
				'id'           => 'xml.entity',
				'category'     => 'xxe',
				'severity'     => 'high',
				'description'  => '<!ENTITY declaration — XXE risk.',
				'recommendation' => 'Remove ENTITY declarations. The DOM sanitizer blocks XXE via libxml options.',
				'languages'    => array( 'xml' ),
				'pattern'      => '/<!ENTITY\s/i',
				'case_insensitive' => true,
				'inspector'    => true,
				'sanitizer'    => true,
				'auto_remediation' => true,
				'manual_review' => false,
				'sanitizer_type' => 'xml_entity',
				'sanitizer_replacement' => null,
				'profiles'     => array( 'standard', 'strict' ),
			),

			'xml.external_dtd' => array(
				'id'           => 'xml.external_dtd',
				'category'     => 'xxe',
				'severity'     => 'medium',
				'description'  => 'DOCTYPE with SYSTEM — external DTD loading (XXE).',
				'recommendation' => 'Remove external DTD references.',
				'languages'    => array( 'xml' ),
				'pattern'      => '/<!DOCTYPE\s[^>]*\bSYSTEM\s/i',
				'case_insensitive' => true,
				'inspector'    => true,
				'sanitizer'    => true,
				'auto_remediation' => true,
				'manual_review' => false,
				'sanitizer_type' => 'xml_external_dtd',
				'sanitizer_replacement' => null,
				'profiles'     => array( 'standard', 'strict' ),
			),

			'xml.xslt_script' => array(
				'id'           => 'xml.xslt_script',
				'category'     => 'code_execution',
				'severity'     => 'high',
				'description'  => 'XSLT <script> element — code execution.',
				'recommendation' => 'Remove XSLT script elements.',
				'languages'    => array( 'xml' ),
				'pattern'      => '/<(?:xsl|msxsl):script\b/i',
				'case_insensitive' => true,
				'inspector'    => true,
				'sanitizer'    => true,
				'auto_remediation' => true,
				'manual_review' => false,
				'sanitizer_type' => 'xml_xslt_script',
				'sanitizer_replacement' => null,
				'profiles'     => array( 'standard', 'strict' ),
			),

			'xml.xinclude' => array(
				'id'           => 'xml.xinclude',
				'category'     => 'xxe',
				'severity'     => 'medium',
				'description'  => 'XInclude element — external resource inclusion.',
				'recommendation' => 'Remove XInclude elements.',
				'languages'    => array( 'xml' ),
				'pattern'      => '/<(?:xi|xi:)include\b/i',
				'case_insensitive' => true,
				'inspector'    => true,
				'sanitizer'    => true,
				'auto_remediation' => true,
				'manual_review' => false,
				'sanitizer_type' => 'xml_xinclude',
				'sanitizer_replacement' => null,
				'profiles'     => array( 'standard', 'strict' ),
			),
		);

		// Allow third-party rule registration via filter.
		$custom_rules = apply_filters( 'cb_codetizer_register_rules', array() );
		if ( is_array( $custom_rules ) ) {
			foreach ( $custom_rules as $rule_id => $rule ) {
				if ( is_array( $rule ) && ! isset( $rules[ $rule_id ] ) ) {
					$rules[ $rule_id ] = $rule;
				}
			}
		}

		self::$rules = $rules;
		self::$initialized = true;
	}

	/**
	 * Get a single rule by ID.
	 *
	 * @param string $rule_id The rule identifier (e.g., 'php.eval').
	 * @return array|null Rule definition or null if not found.
	 */
	public static function get_rule( string $rule_id ): ?array {
		self::init();
		return self::$rules[ $rule_id ] ?? null;
	}

	/**
	 * Get all rules applicable to a specific language and profile.
	 *
	 * @param string $language The language identifier (e.g., 'php', 'javascript').
	 * @param string $profile  The scan profile ('standard' or 'strict'). Strict includes all standard rules.
	 * @return array<string, array> Rules keyed by rule ID.
	 */
	public static function get_rules_for_language( string $language, string $profile = 'standard' ): array {
		self::init();
		$result = array();

		foreach ( self::$rules as $id => $rule ) {
			// Check language applicability.
			if ( ! in_array( $language, $rule['languages'] ?? array(), true ) ) {
				continue;
			}

			// Check profile membership.
			$profiles = $rule['profiles'] ?? array( 'standard', 'strict' );
			if ( 'strict' === $profile ) {
				// Strict profile includes ALL rules (standard + strict-only).
				if ( ! in_array( 'strict', $profiles, true ) && ! in_array( 'standard', $profiles, true ) ) {
					continue;
				}
			} else {
				// Standard profile includes only standard rules.
				if ( ! in_array( 'standard', $profiles, true ) ) {
					continue;
				}
			}

			// Check if inspector should use this rule.
			if ( empty( $rule['inspector'] ) ) {
				continue;
			}

			$result[ $id ] = $rule;
		}

		return $result;
	}

	/**
	 * Get all sanitizer rules applicable to a specific language.
	 *
	 * @param string $language The language identifier.
	 * @return array<string, array> Rules keyed by rule ID.
	 */
	public static function get_sanitizer_rules_for_language( string $language ): array {
		self::init();
		$result = array();

		foreach ( self::$rules as $id => $rule ) {
			if ( ! in_array( $language, $rule['languages'] ?? array(), true ) ) {
				continue;
			}
			if ( empty( $rule['sanitizer'] ) ) {
				continue;
			}
			$result[ $id ] = $rule;
		}

		return $result;
	}

	/**
	 * Get all rule IDs.
	 *
	 * @return string[] Array of rule IDs.
	 */
	public static function get_all_rule_ids(): array {
		self::init();
		return array_keys( self::$rules );
	}

	/**
	 * Register a custom rule at runtime.
	 *
	 * Allows third-party code to add rules without modifying the repository.
	 * The rule will be available for both Inspector and Sanitizer.
	 *
	 * @param array $rule The rule definition. Must include 'id' and 'pattern'.
	 * @return bool True on success, false if rule ID already exists or definition is invalid.
	 */
	public static function register_rule( array $rule ): bool {
		self::init();

		if ( empty( $rule['id'] ) || ! is_string( $rule['id'] ) ) {
			return false;
		}
		if ( isset( self::$rules[ $rule['id'] ] ) ) {
			return false; // Cannot overwrite existing rules.
		}
		if ( empty( $rule['pattern'] ) || ! is_string( $rule['pattern'] ) ) {
			return false;
		}

		// Validate pattern is a valid regex.
		$prev = set_error_handler( static function () { return true; } );
		$valid = false !== @preg_match( $rule['pattern'], '' );
		restore_error_handler();

		if ( ! $valid ) {
			return false;
		}

		self::$rules[ $rule['id'] ] = $rule;
		return true;
	}

	/**
	 * Get a summary of all rules (for display/debugging).
	 *
	 * @return array Summary data: id, category, severity, languages, auto_remediation.
	 */
	public static function get_rules_summary(): array {
		self::init();
		$summary = array();

		foreach ( self::$rules as $id => $rule ) {
			$summary[ $id ] = array(
				'category'         => $rule['category'] ?? 'unknown',
				'severity'         => $rule['severity'] ?? 'info',
				'languages'        => $rule['languages'] ?? array(),
				'auto_remediation' => $rule['auto_remediation'] ?? false,
				'manual_review'    => $rule['manual_review'] ?? false,
			);
		}

		return $summary;
	}
}
