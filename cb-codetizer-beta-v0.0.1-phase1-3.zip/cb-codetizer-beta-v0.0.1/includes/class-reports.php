<?php
/**
 * CB CODETIZER - Reports
 *
 * Handles persistence and retrieval of scan reports stored in the
 * custom database table `{prefix}cb_codetizer_reports`.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CB_Codetizer_Reports
 *
 * Provides CRUD operations and aggregate statistics for scan reports.
 * All database queries use prepared statements via $wpdb.
 */
class CB_Codetizer_Reports {

	/**
	 * WordPress database instance.
	 *
	 * @var wpdb
	 */
	private wpdb $db;

	/**
	 * Full table name including prefix.
	 *
	 * @var string
	 */
	private string $table_name;

	/**
	 * Constructor.
	 */
	public function __construct() {
		global $wpdb;
		$this->db         = $wpdb;
		$this->table_name = $wpdb->prefix . 'cb_codetizer_reports';
	}

	/**
	 * Save a new scan report to the database.
	 *
	 * @param array $data Report data array. Keys:
	 *   - scan_type        (string)
	 *   - language         (string)
	 *   - input_summary    (string)
	 *   - output_summary   (string)
	 *   - results          (array|string — array is JSON-encoded automatically)
	 *   - threats_found    (int)
	 *   - severity_summary (string)
	 *   - score            (int, 0-100)
	 * @return int|false The insert ID on success, or false on failure.
	 */
	public function save( array $data ): int|false {
		$results_value = $data['results'] ?? array();
		if ( is_array( $results_value ) ) {
			$results_json = wp_json_encode( $results_value );
		} else {
			$results_json = is_string( $results_value ) ? $results_value : '{}';
		}

		$score = isset( $data['score'] ) ? max( 0, min( 100, absint( $data['score'] ) ) ) : 100;

		$inserted = $this->db->insert(
			$this->table_name,
			array(
				'scan_type'        => sanitize_text_field( $data['scan_type']        ?? 'inspector' ),
				'language'         => sanitize_text_field( $data['language']         ?? 'html' ),
				'input_summary'    => sanitize_textarea_field( $data['input_summary']  ?? '' ),
				'output_summary'   => sanitize_textarea_field( $data['output_summary'] ?? '' ),
				'results'          => $results_json,
				'threats_found'    => absint( $data['threats_found']    ?? 0 ),
				'severity_summary' => sanitize_text_field( $data['severity_summary'] ?? '' ),
				'score'            => $score,
				'created_at'       => current_time( 'mysql' ),
				'user_id'          => get_current_user_id(),
			),
			array( '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%d', '%s', '%d' )
		);

		if ( false === $inserted ) {
			return false;
		}

		return (int) $this->db->insert_id;
	}

	/**
	 * Allowed scan_type values for filtering.
	 *
	 * Used as an explicit allowlist so that even if a caller passes an
	 * arbitrary string, it is rejected before reaching the database layer.
	 * This is defense-in-depth: the value is also prepared, but validating
	 * against an allowlist prevents the query from scanning for a
	 * non-existent scan_type and provides a single source of truth.
	 */
	const ALLOWED_SCAN_TYPES = array( 'inspector', 'sanitizer', 'beautifier' );

	/**
	 * Allowed ORDER BY columns for get_all().
	 *
	 * Identifiers (column names) cannot be parameterized with $wpdb->prepare().
	 * We use an explicit allowlist to prevent SQL injection via the orderby
	 * argument. Any value not in this list falls back to the default.
	 */
	const ALLOWED_ORDER_COLUMNS = array( 'created_at', 'id', 'score', 'threats_found' );

	/**
	 * Retrieve reports with optional filtering, search, and pagination.
	 *
	 * All user-controlled values are either parameterized via $wpdb->prepare()
	 * or validated against an explicit allowlist before being interpolated
	 * into the SQL string. The table name is built from $wpdb->prefix (a
	 * trusted WordPress core value) and is safe to interpolate.
	 *
	 * @param array $args {
	 *   @type int    $per_page  Number of items per page. Default 20. Max 100.
	 *   @type int    $page      Current page number. Default 1.
	 *   @type string $search    Search string against input_summary.
	 *   @type string $scan_type Filter by scan type. Must be one of ALLOWED_SCAN_TYPES.
	 *   @type string $orderby   Order column. Must be one of ALLOWED_ORDER_COLUMNS. Default 'created_at'.
	 *   @type string $order     'ASC' or 'DESC'. Default 'DESC'.
	 * }
	 * @return array{ reports: array, total: int, pages: int, current_page: int }
	 */
	public function get_all( array $args = array() ): array {
		$per_page  = isset( $args['per_page'] ) ? max( 1, min( 100, absint( $args['per_page'] ) ) ) : 20;
		$page      = isset( $args['page'] )     ? max( 1, absint( $args['page'] ) )     : 1;
		$offset    = ( $page - 1 ) * $per_page;
		$search    = isset( $args['search'] )   ? sanitize_text_field( wp_unslash( $args['search'] ) ) : '';
		$scan_type = isset( $args['scan_type'] ) ? sanitize_text_field( $args['scan_type'] ) : '';

		// Validate scan_type against the allowlist. An invalid value
		// is silently ignored (no filter applied) rather than causing
		// a database error or scanning for a non-existent type.
		if ( ! empty( $scan_type ) && ! in_array( $scan_type, self::ALLOWED_SCAN_TYPES, true ) ) {
			$scan_type = '';
		}

		// Build WHERE clause. Each condition is individually prepared;
		// the assembled $where string contains only prepared fragments
		// joined by ' AND ', which is safe to interpolate.
		$conditions = array();

		if ( ! empty( $search ) ) {
			$like         = '%' . $this->db->esc_like( $search ) . '%';
			$conditions[] = $this->db->prepare( 'input_summary LIKE %s', $like );
		}

		if ( ! empty( $scan_type ) ) {
			$conditions[] = $this->db->prepare( 'scan_type = %s', $scan_type );
		}

		$where = empty( $conditions ) ? '1=1' : implode( ' AND ', $conditions );

		// Validate orderby/order against allowlists. Column names and
		// ASC/DESC keywords cannot be parameterized, so they MUST be
		// validated before interpolation.
		$orderby_raw = isset( $args['orderby'] ) ? sanitize_text_field( $args['orderby'] ) : 'created_at';
		$order_raw   = isset( $args['order'] )   ? strtoupper( sanitize_text_field( $args['order'] ) ) : 'DESC';

		$orderby = in_array( $orderby_raw, self::ALLOWED_ORDER_COLUMNS, true ) ? $orderby_raw : 'created_at';
		$order   = in_array( $order_raw, array( 'ASC', 'DESC' ), true ) ? $order_raw : 'DESC';

		// Total count.
		// The $where string is composed solely of prepared fragments
		// (or the literal '1=1'), so interpolation is safe.
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$total = (int) $this->db->get_var( "SELECT COUNT(*) FROM {$this->table_name} WHERE {$where}" );

		// Data query. $orderby and $order are allowlist-validated,
		// $where is prepared-fragments-only, LIMIT/OFFSET are parameterized.
		$sql = $this->db->prepare(
			// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			"SELECT * FROM {$this->table_name} WHERE {$where} ORDER BY {$orderby} {$order} LIMIT %d OFFSET %d",
			$per_page,
			$offset
		);

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$reports = $this->db->get_results( $sql );

		$pages = $per_page > 0 ? (int) ceil( $total / $per_page ) : 1;

		return array(
			'reports'      => is_array( $reports ) ? $reports : array(),
			'total'        => $total,
			'pages'        => max( 1, $pages ),
			'current_page' => $page,
		);
	}

	/**
	 * Calculate the average security score across all inspector reports.
	 *
	 * Uses the persisted `score` column (added in v1.0.0) rather than
	 * JSON_EXTRACT() on the `results` blob, for portability across
	 * MySQL/MariaDB versions and to avoid the performance cost of
	 * parsing JSON in every row.
	 *
	 * @return int Average score (0-100), or 100 if no inspector reports exist.
	 */
	public function get_average_score(): int {
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$avg = $this->db->get_var(
			"SELECT AVG(score) FROM {$this->table_name} WHERE scan_type = 'inspector'"
		);

		if ( null === $avg || false === $avg ) {
			return 100;
		}

		$rounded = round( (float) $avg );

		return (int) max( 0, min( 100, $rounded ) );
	}

	/**
	 * Delete a single report by ID.
	 *
	 * @param int $id Report ID.
	 * @return bool True on success.
	 */
	public function delete( int $id ): bool {
		$result = $this->db->delete(
			$this->table_name,
			array( 'id' => $id ),
			array( '%d' )
		);

		return false !== $result;
	}

	/**
	 * Delete all reports (TRUNCATE).
	 *
	 * @return bool True on success.
	 */
	public function delete_all(): bool {
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$result = $this->db->query( "TRUNCATE TABLE {$this->table_name}" );

		if ( false !== $result ) {
			CB_Codetizer_Helpers::log_activity(
				esc_html__( 'All reports cleared.', 'cb-codetizer' )
			);
			return true;
		}

		return false;
	}

	/**
	 * Retrieve aggregate statistics across all reports.
	 *
	 * @return array{ total_scans: int, total_threats: int, most_scanned_language: string, recent_scans: array }
	 */
	public function get_stats(): array {
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$total_scans = (int) $this->db->get_var( "SELECT COUNT(*) FROM {$this->table_name}" );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$total_threats = (int) $this->db->get_var( "SELECT COALESCE(SUM(threats_found), 0) FROM {$this->table_name}" );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$most_scanned = $this->db->get_row(
			"SELECT language, COUNT(*) AS cnt FROM {$this->table_name} GROUP BY language ORDER BY cnt DESC LIMIT 1"
		);
		$most_scanned_language = ( $most_scanned && ! empty( $most_scanned->language ) )
			? $most_scanned->language
			: 'html';

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$recent = $this->db->get_results(
			"SELECT id, scan_type, language, threats_found, severity_summary, score, created_at FROM {$this->table_name} ORDER BY created_at DESC LIMIT 5"
		);

		return array(
			'total_scans'           => $total_scans,
			'total_threats'         => $total_threats,
			'most_scanned_language' => $most_scanned_language,
			'recent_scans'          => is_array( $recent ) ? $recent : array(),
		);
	}
}
