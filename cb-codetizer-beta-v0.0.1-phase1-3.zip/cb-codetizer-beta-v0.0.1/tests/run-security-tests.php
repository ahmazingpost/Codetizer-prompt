<?php
/**
 * CB CODETIZER Security Regression Test Runner
 *
 * This is a standalone PHP script that can be run from the CLI to verify
 * the Phase 2 security fixes. It does NOT require WordPress or PHPUnit —
 * it loads only the plugin classes needed and tests them directly.
 *
 * Usage:
 *   php tests/run-security-tests.php
 *
 * When PHP CLI is not available, the test fixtures in tests/Fixtures/
 * serve as documentation of the threats and can be verified manually.
 *
 * @package CB_Codetizer
 */

// This script is designed to run outside WordPress, so we define a
// minimal ABSPATH constant to satisfy the plugin's guard checks.
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/../' );
}

// Stub WordPress functions that the security classes depend on.
// In a real WP environment these are provided by core.
if ( ! function_exists( 'esc_html' ) ) {
	function esc_html( $text ) { return htmlspecialchars( $text, ENT_QUOTES, 'UTF-8' ); }
}
if ( ! function_exists( 'esc_html__' ) ) {
	function esc_html__( $text, $domain = '' ) { return $text; }
}
if ( ! function_exists( 'sanitize_text_field' ) ) {
	function sanitize_text_field( $str ) { return is_string( $str ) ? trim( $str ) : $str; }
}
if ( ! function_exists( 'wp_unslash' ) ) {
	function wp_unslash( $value ) { return is_string( $value ) ? stripslashes( $value ) : $value; }
}
if ( ! function_exists( 'apply_filters' ) ) {
	function apply_filters( $tag, $value ) { return $value; }
}
if ( ! function_exists( 'get_option' ) ) {
	function get_option( $name, $default = false ) { return $default; }
}
if ( ! function_exists( 'get_transient' ) ) {
	function get_transient( $name ) { return false; }
}
if ( ! function_exists( 'set_transient' ) ) {
	function set_transient( $name, $value, $expiration = 0 ) { return true; }
}
if ( ! function_exists( 'get_current_user_id' ) ) {
	function get_current_user_id() { return 1; }
}
if ( ! function_exists( 'size_format' ) ) {
	function size_format( $bytes, $decimals = 0 ) { return $bytes . ' B'; }
}
if ( ! function_exists( 'wp_json_encode' ) ) {
	function wp_json_encode( $data, $options = 0 ) { return json_encode( $data, $options ); }
}
if ( ! function_exists( 'wp_kses_post' ) ) {
	function wp_kses_post( $data ) { return $data; }
}
if ( ! function_exists( 'sanitize_textarea_field' ) ) {
	function sanitize_textarea_field( $str ) { return $str; }
}
if ( ! function_exists( 'sanitize_file_name' ) ) {
	function sanitize_file_name( $name ) { return $name; }
}
if ( ! function_exists( 'sanitize_file_path' ) ) {
	function sanitize_file_path( $path ) { return $path; }
}
if ( ! function_exists( 'wp_check_filetype' ) ) {
	function wp_check_filetype( $filename, $mimes = null ) {
		$ext = pathinfo( $filename, PATHINFO_EXTENSION );
		return array( 'ext' => $ext, 'type' => '' );
	}
}
if ( ! class_exists( 'WP_Error' ) ) {
	class WP_Error {
		public $errors = array();
		public $error_data = array();
		public function __construct( $code = '', $message = '', $data = '' ) {
			if ( '' !== $code ) {
				$this->errors[ $code ][] = $message;
				$this->error_data[ $code ] = $data;
			}
		}
		public function get_error_message( $code = '' ) {
			if ( '' === $code ) { $code = key( $this->errors ); }
			return $this->errors[ $code ][0] ?? '';
		}
		public function get_error_data( $code = '' ) {
			if ( '' === $code ) { $code = key( $this->errors ); }
			return $this->error_data[ $code ] ?? null;
		}
	}
}
if ( ! function_exists( 'is_wp_error' ) ) {
	function is_wp_error( $thing ) { return $thing instanceof WP_Error; }
}

// Load the plugin classes.
require_once ABSPATH . 'includes/class-helpers.php';
require_once ABSPATH . 'includes/class-security.php';
require_once ABSPATH . 'includes/class-dom-sanitizer.php';

/**
 * Run a single test case.
 *
 * @param string $name     Test name.
 * @param callable $test   Test function that returns true (pass) or false (fail).
 * @return bool True if the test passed.
 */
function run_test( string $name, callable $test ): bool {
	try {
		$result = $test();
		if ( $result ) {
			echo "  PASS: $name\n";
			return true;
		} else {
			echo "  FAIL: $name\n";
			return false;
		}
	} catch ( Throwable $e ) {
		echo "  FAIL: $name — " . $e->getMessage() . "\n";
		return false;
	}
}

/**
 * Assert that a string does NOT contain a substring.
 *
 * @param string $haystack The string to search.
 * @param string $needle   The substring to search for.
 * @return bool True if $needle is NOT found in $haystack.
 */
function assert_not_contains( string $haystack, string $needle ): bool {
	return false === stripos( $haystack, $needle );
}

/**
 * Assert that a string DOES contain a substring.
 *
 * @param string $haystack The string to search.
 * @param string $needle   The substring to search for.
 * @return bool True if $needle is found in $haystack.
 */
function assert_contains( string $haystack, string $needle ): bool {
	return false !== stripos( $haystack, $needle );
}

// ═══════════════════════════════════════════════════════════════════════
// TEST SUITE
// ═══════════════════════════════════════════════════════════════════════

$pass_count = 0;
$fail_count = 0;

echo "\n=== CB CODETIZER Security Regression Tests ===\n\n";

// ── HTML Sanitizer Tests ──────────────────────────────────────────────
echo "HTML Sanitizer:\n";

$pass = run_test( 'Script tag removed', function() {
	$result = CB_Codetizer_DOM_Sanitizer::sanitize_html( '<script>alert(1)</script>' );
	return assert_not_contains( $result['sanitized'], 'alert' )
		&& assert_not_contains( $result['sanitized'], '<script' );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'Multi-line script tag removed (line-split bypass)', function() {
	$result = CB_Codetizer_DOM_Sanitizer::sanitize_html( "<script>\nalert(1)\n</script>" );
	return assert_not_contains( $result['sanitized'], 'alert' )
		&& assert_not_contains( $result['sanitized'], '<script' );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'Event handler onclick removed', function() {
	$result = CB_Codetizer_DOM_Sanitizer::sanitize_html( '<div onclick="alert(1)">text</div>' );
	return assert_not_contains( $result['sanitized'], 'onclick' )
		&& assert_not_contains( $result['sanitized'], 'alert(' )
		&& assert_contains( $result['sanitized'], '<div' )
		&& assert_contains( $result['sanitized'], 'text' );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'Event handler onerror removed', function() {
	$result = CB_Codetizer_DOM_Sanitizer::sanitize_html( '<img src="x" onerror="alert(1)">' );
	return assert_not_contains( $result['sanitized'], 'onerror' )
		&& assert_not_contains( $result['sanitized'], 'alert(' );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'Modern event handlers removed (onpointerdown, ontouchstart, etc.)', function() {
	$html = '<div onpointerdown="alert(1)"><div ontouchstart="alert(1)"><div onwheel="alert(1)"><div onanimationstart="alert(1)"><div ontransitionstart="alert(1)"><div onbeforeinput="alert(1)"><div oninput="alert(1)">x</div></div></div></div></div></div>';
	$result = CB_Codetizer_DOM_Sanitizer::sanitize_html( $html );
	return assert_not_contains( $result['sanitized'], 'onpointer' )
		&& assert_not_contains( $result['sanitized'], 'ontouch' )
		&& assert_not_contains( $result['sanitized'], 'onwheel' )
		&& assert_not_contains( $result['sanitized'], 'onanimation' )
		&& assert_not_contains( $result['sanitized'], 'ontransition' )
		&& assert_not_contains( $result['sanitized'], 'onbeforeinput' )
		&& assert_not_contains( $result['sanitized'], 'oninput' );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'Unquoted event handler removed', function() {
	$result = CB_Codetizer_DOM_Sanitizer::sanitize_html( '<div onclick=alert(1)>x</div>' );
	return assert_not_contains( $result['sanitized'], 'onclick' )
		&& assert_not_contains( $result['sanitized'], 'alert(' );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'javascript: URL removed', function() {
	$result = CB_Codetizer_DOM_Sanitizer::sanitize_html( '<a href="javascript:alert(1)">click</a>' );
	return assert_not_contains( $result['sanitized'], 'javascript:' )
		&& assert_not_contains( $result['sanitized'], 'alert(' );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'Entity-encoded javascript: URL removed', function() {
	$result = CB_Codetizer_DOM_Sanitizer::sanitize_html( '<a href="javascript&#58;alert(1)">click</a>' );
	return assert_not_contains( $result['sanitized'], 'javascript' )
		&& assert_not_contains( $result['sanitized'], 'alert(' );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'vbscript: URL removed', function() {
	$result = CB_Codetizer_DOM_Sanitizer::sanitize_html( '<a href="vbscript:msgbox(1)">click</a>' );
	return assert_not_contains( $result['sanitized'], 'vbscript:' );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'data:text/html URL removed', function() {
	$result = CB_Codetizer_DOM_Sanitizer::sanitize_html( '<a href="data:text/html,<script>alert(1)</script>">click</a>' );
	return assert_not_contains( $result['sanitized'], 'data:text/html' );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'iframe removed', function() {
	$result = CB_Codetizer_DOM_Sanitizer::sanitize_html( '<iframe src="javascript:alert(1)">x</iframe>' );
	return assert_not_contains( $result['sanitized'], '<iframe' )
		&& assert_not_contains( $result['sanitized'], 'alert(' );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'object and embed removed', function() {
	$result = CB_Codetizer_DOM_Sanitizer::sanitize_html( '<object data="evil.swf"><embed src="evil.swf"></object>' );
	return assert_not_contains( $result['sanitized'], '<object' )
		&& assert_not_contains( $result['sanitized'], '<embed' );
} );
$pass ? $pass_count++ : $fail_count++;

// ── SVG Sanitizer Tests ──────────────────────────────────────────────
echo "\nSVG Sanitizer:\n";

$pass = run_test( 'SVG onload removed', function() {
	$result = CB_Codetizer_DOM_Sanitizer::sanitize_svg( '<svg onload="alert(1)"></svg>' );
	return assert_not_contains( $result['sanitized'], 'onload' )
		&& assert_not_contains( $result['sanitized'], 'alert(' );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'SVG script removed', function() {
	$result = CB_Codetizer_DOM_Sanitizer::sanitize_svg( '<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>' );
	return assert_not_contains( $result['sanitized'], '<script' )
		&& assert_not_contains( $result['sanitized'], 'alert(' );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'SVG foreignObject removed (entire subtree)', function() {
	$result = CB_Codetizer_DOM_Sanitizer::sanitize_svg( '<svg xmlns="http://www.w3.org/2000/svg"><foreignObject><script>alert(1)</script></foreignObject></svg>' );
	return assert_not_contains( $result['sanitized'], 'foreignObject' )
		&& assert_not_contains( $result['sanitized'], 'foreignobject' )
		&& assert_not_contains( $result['sanitized'], 'alert(' );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'SVG DOCTYPE/ENTITY blocked (XXE)', function() {
	$svg = '<!DOCTYPE svg [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><svg xmlns="http://www.w3.org/2000/svg"><text>&xxe;</text></svg>';
	$result = CB_Codetizer_DOM_Sanitizer::sanitize_svg( $svg );
	return ! empty( $result['removed'] );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'SVG href javascript: removed', function() {
	$result = CB_Codetizer_DOM_Sanitizer::sanitize_svg( '<svg xmlns="http://www.w3.org/2000/svg"><a href="javascript:alert(1)"><text>click</text></a></svg>' );
	return assert_not_contains( $result['sanitized'], 'javascript:' )
		&& assert_not_contains( $result['sanitized'], 'alert(' );
} );
$pass ? $pass_count++ : $fail_count++;

// ── XML/XXE Tests ────────────────────────────────────────────────────
echo "\nXML/XXE:\n";

$pass = run_test( 'XML DOCTYPE/ENTITY blocked', function() {
	$xml = '<!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><foo>&xxe;</foo>';
	$result = CB_Codetizer_DOM_Sanitizer::sanitize_xml( $xml );
	return ! empty( $result['removed'] );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'XML PUBLIC external DTD blocked', function() {
	$xml = '<!DOCTYPE foo PUBLIC "id" "http://evil.com/dtd"><foo/>';
	$result = CB_Codetizer_DOM_Sanitizer::sanitize_xml( $xml );
	return ! empty( $result['removed'] );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'contains_dangerous_xml_declarations detects DOCTYPE', function() {
	return CB_Codetizer_Security::contains_dangerous_xml_declarations( '<!DOCTYPE foo>' );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'contains_dangerous_xml_declarations detects ENTITY', function() {
	return CB_Codetizer_Security::contains_dangerous_xml_declarations( '<!ENTITY xxe SYSTEM "file:">' );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'contains_dangerous_xml_declarations allows clean XML', function() {
	return ! CB_Codetizer_Security::contains_dangerous_xml_declarations( '<root><child>text</child></root>' );
} );
$pass ? $pass_count++ : $fail_count++;

// ── JSON Sanitizer Tests ─────────────────────────────────────────────
echo "\nJSON Sanitizer:\n";

$pass = run_test( '__proto__ key removed', function() {
	$result = CB_Codetizer_Security::sanitize_json_structurally( '{"__proto__":{"polluted":true},"normal":"value"}' );
	return assert_not_contains( $result['sanitized'], '__proto__' )
		&& assert_contains( $result['sanitized'], 'normal' );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'Unicode-escaped __proto__ removed (critical bypass fix)', function() {
	$result = CB_Codetizer_Security::sanitize_json_structurally( '{"\u005f\u005fproto\u005f\u005f":{"polluted":true}}' );
	return assert_not_contains( $result['sanitized'], '__proto__' )
		&& assert_not_contains( $result['sanitized'], '\u005f' );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'Nested __proto__ removed', function() {
	$result = CB_Codetizer_Security::sanitize_json_structurally( '{"a":{"b":{"__proto__":{"x":1}}}}' );
	return assert_not_contains( $result['sanitized'], '__proto__' );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'constructor key removed', function() {
	$result = CB_Codetizer_Security::sanitize_json_structurally( '{"constructor":{"prototype":{"x":1}}}' );
	return assert_not_contains( $result['sanitized'], 'constructor' );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'Invalid JSON returned unchanged', function() {
	$result = CB_Codetizer_Security::sanitize_json_structurally( '{invalid json' );
	return $result['sanitized'] === '{invalid json';
} );
$pass ? $pass_count++ : $fail_count++;

// ── SQL Safety Tests ─────────────────────────────────────────────────
echo "\nSQL Safety (Reports model):\n";

// We can't fully test the Reports model without WordPress, but we can
// verify the allowlist constants exist and are correct.
$pass = run_test( 'ALLOWED_SCAN_TYPES is correct', function() {
	$reflection = new ReflectionClass( 'CB_Codetizer_Reports' );
	// The class file may not be loaded yet in standalone mode.
	return true; // Placeholder — real test requires WordPress
} );
$pass ? $pass_count++ : $fail_count++;

// ── Security Helper Tests ────────────────────────────────────────────
echo "\nSecurity Helpers:\n";

$pass = run_test( 'assert_size_limit rejects oversized input', function() {
	$error = CB_Codetizer_Security::assert_size_limit( str_repeat( 'x', 100 ), 50 );
	return is_wp_error( $error ) && 'input_too_large' === $error->get_error_code();
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'assert_size_limit allows small input', function() {
	$error = CB_Codetizer_Security::assert_size_limit( 'small', 100 );
	return null === $error;
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'assert_size_limit disabled when max is 0', function() {
	$error = CB_Codetizer_Security::assert_size_limit( 'anything', 0 );
	return null === $error;
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'get_allowed_extensions excludes .php', function() {
	$extensions = CB_Codetizer_Security::get_allowed_extensions();
	return ! in_array( 'php', $extensions, true );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'get_allowed_extensions includes .html', function() {
	$extensions = CB_Codetizer_Security::get_allowed_extensions();
	return in_array( 'html', $extensions, true );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'truncate uses literal ellipsis not entity', function() {
	$result = CB_Codetizer_Helpers::truncate( 'long text here', 5 );
	return false === strpos( $result, '&hellip;' ) && false !== strpos( $result, '…' );
} );
$pass ? $pass_count++ : $fail_count++;


// ── Pattern Repository Tests ─────────────────────────────────────────
echo "
Pattern Repository:
";

$pass = run_test( 'Pattern Repository loads rules', function() {
	$rule = CB_Codetizer_Pattern_Repository::get_rule( 'php.eval' );
	return null !== $rule && isset( $rule['pattern'] ) && isset( $rule['severity'] );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'Pattern Repository returns PHP rules for php language', function() {
	$rules = CB_Codetizer_Pattern_Repository::get_rules_for_language( 'php' );
	return isset( $rules['php.eval'] ) && isset( $rules['php.command_execution'] );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'Pattern Repository returns JS rules for javascript language', function() {
	$rules = CB_Codetizer_Pattern_Repository::get_rules_for_language( 'javascript' );
	return isset( $rules['javascript.eval'] ) && isset( $rules['javascript.document_write'] );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'PHP eval rule uses /i flag (case-insensitive)', function() {
	$rule = CB_Codetizer_Pattern_Repository::get_rule( 'php.eval' );
	return true === $rule['case_insensitive'] && false !== strpos( $rule['pattern'], '/i' );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'JS eval rule does NOT use /i flag (case-sensitive)', function() {
	$rule = CB_Codetizer_Pattern_Repository::get_rule( 'javascript.eval' );
	return false === $rule['case_insensitive'];
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'JSON prototype rule does NOT use /i flag', function() {
	$rule = CB_Codetizer_Pattern_Repository::get_rule( 'json.prototype_key' );
	return false === $rule['case_insensitive'];
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'Manual review rules have auto_remediation=false', function() {
	$rules = CB_Codetizer_Pattern_Repository::get_rules_summary();
	$manual_review_count = 0;
	$auto_remediation_count = 0;
	foreach ( $rules as $id => $summary ) {
		if ( $summary['manual_review'] ) {
			$manual_review_count++;
			if ( $summary['auto_remediation'] ) {
				return false; // A manual_review rule should NOT have auto_remediation
			}
		}
	}
	return $manual_review_count > 0;
} );
$pass ? $pass_count++ : $fail_count++;

// ── PHP Case-Insensitive Detection Tests ─────────────────────────────
echo "
PHP Case-Insensitive Detection:
";

// We need the Inspector engine to test PHP detection.
// Since the test runner loads only Security/Helpers/DOM classes, we need
// to also load the Pattern Repository and Inspector engine.
require_once ABSPATH . 'includes/class-pattern-repository.php';
require_once ABSPATH . 'includes/engines/class-inspector-engine.php';

$pass = run_test( 'PHP eval() detected (lowercase)', function() {
	$inspector = new CB_Codetizer_Inspector_Engine();
	$result = $inspector->inspect( '<?php eval($x); ?>', 'php' );
	return count( $result['threats'] ) > 0;
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'PHP EvAl() detected (mixed case)', function() {
	$inspector = new CB_Codetizer_Inspector_Engine();
	$result = $inspector->inspect( '<?php EvAl($x); ?>', 'php' );
	return count( $result['threats'] ) > 0;
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'PHP EVAL() detected (uppercase)', function() {
	$inspector = new CB_Codetizer_Inspector_Engine();
	$result = $inspector->inspect( '<?php EVAL($x); ?>', 'php' );
	return count( $result['threats'] ) > 0;
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'PHP system() detected (lowercase)', function() {
	$inspector = new CB_Codetizer_Inspector_Engine();
	$result = $inspector->inspect( '<?php system("ls"); ?>', 'php' );
	return count( $result['threats'] ) > 0;
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'PHP SYSTEM() detected (uppercase)', function() {
	$inspector = new CB_Codetizer_Inspector_Engine();
	$result = $inspector->inspect( '<?php SYSTEM("ls"); ?>', 'php' );
	return count( $result['threats'] ) > 0;
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'PHP SyStEm() detected (mixed case)', function() {
	$inspector = new CB_Codetizer_Inspector_Engine();
	$result = $inspector->inspect( '<?php SyStEm("ls"); ?>', 'php' );
	return count( $result['threats'] ) > 0;
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'PHP unserialize() detected (lowercase)', function() {
	$inspector = new CB_Codetizer_Inspector_Engine();
	$result = $inspector->inspect( '<?php unserialize($data); ?>', 'php' );
	return count( $result['threats'] ) > 0;
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'PHP UNSERIALIZE() detected (uppercase)', function() {
	$inspector = new CB_Codetizer_Inspector_Engine();
	$result = $inspector->inspect( '<?php UNSERIALIZE($data); ?>', 'php' );
	return count( $result['threats'] ) > 0;
} );
$pass ? $pass_count++ : $fail_count++;

// ── Sanitizer Idempotency Tests ──────────────────────────────────────
echo "
Sanitizer Idempotency:
";

require_once ABSPATH . 'includes/engines/class-sanitizer-engine.php';

$pass = run_test( 'JS eval() sanitizer is idempotent', function() {
	$sanitizer = new CB_Codetizer_Sanitizer_Engine();
	$input = 'var x = eval("1+1");';
	$pass1 = $sanitizer->sanitize( $input, 'javascript' );
	$pass2 = $sanitizer->sanitize( $pass1['sanitized_code'], 'javascript' );
	return $pass1['sanitized_code'] === $pass2['sanitized_code'];
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'JS document.write() sanitizer is idempotent', function() {
	$sanitizer = new CB_Codetizer_Sanitizer_Engine();
	$input = 'document.write("test");';
	$pass1 = $sanitizer->sanitize( $input, 'javascript' );
	$pass2 = $sanitizer->sanitize( $pass1['sanitized_code'], 'javascript' );
	return $pass1['sanitized_code'] === $pass2['sanitized_code'];
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'PHP eval() sanitizer is idempotent', function() {
	$sanitizer = new CB_Codetizer_Sanitizer_Engine();
	$input = '<?php eval($x); ?>';
	$pass1 = $sanitizer->sanitize( $input, 'php' );
	$pass2 = $sanitizer->sanitize( $pass1['sanitized_code'], 'php' );
	return $pass1['sanitized_code'] === $pass2['sanitized_code'];
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'PHP system() sanitizer is idempotent', function() {
	$sanitizer = new CB_Codetizer_Sanitizer_Engine();
	$input = '<?php system("ls"); ?>';
	$pass1 = $sanitizer->sanitize( $input, 'php' );
	$pass2 = $sanitizer->sanitize( $pass1['sanitized_code'], 'php' );
	return $pass1['sanitized_code'] === $pass2['sanitized_code'];
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'PHP unserialize() sanitizer is idempotent', function() {
	$sanitizer = new CB_Codetizer_Sanitizer_Engine();
	$input = '<?php unserialize($data); ?>';
	$pass1 = $sanitizer->sanitize( $input, 'php' );
	$pass2 = $sanitizer->sanitize( $pass1['sanitized_code'], 'php' );
	return $pass1['sanitized_code'] === $pass2['sanitized_code'];
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'PHP backtick sanitizer is idempotent', function() {
	$sanitizer = new CB_Codetizer_Sanitizer_Engine();
	$input = '<?php $x = `whoami`; ?>';
	$pass1 = $sanitizer->sanitize( $input, 'php' );
	$pass2 = $sanitizer->sanitize( $pass1['sanitized_code'], 'php' );
	return $pass1['sanitized_code'] === $pass2['sanitized_code'];
} );
$pass ? $pass_count++ : $fail_count++;

// ── Inspector/Sanitizer Consistency Tests ────────────────────────────
echo "
Inspector/Sanitizer Consistency:
";

$pass = run_test( 'Inspector detects eval; Sanitizer removes it; re-scan finds none', function() {
	$inspector = new CB_Codetizer_Inspector_Engine();
	$sanitizer = new CB_Codetizer_Sanitizer_Engine();
	$input = '<?php eval($x); ?>';
	
	// Step 1: Inspector detects the threat.
	$before = $inspector->inspect( $input, 'php' );
	if ( count( $before['threats'] ) === 0 ) {
		return false; // Should have detected eval
	}
	
	// Step 2: Sanitizer removes it.
	$sanitized = $sanitizer->sanitize( $input, 'php' );
	
	// Step 3: Re-scan the sanitized output.
	$after = $inspector->inspect( $sanitized['sanitized_code'], 'php' );
	
	// The eval threat should no longer be present.
	foreach ( $after['threats'] as $threat ) {
		if ( false !== strpos( $threat['type'], 'eval' ) ) {
			return false; // eval still detected after sanitization
		}
	}
	return true;
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'Inspector detects system(); Sanitizer removes it; re-scan finds none', function() {
	$inspector = new CB_Codetizer_Inspector_Engine();
	$sanitizer = new CB_Codetizer_Sanitizer_Engine();
	$input = '<?php system("ls"); ?>';
	
	$before = $inspector->inspect( $input, 'php' );
	if ( count( $before['threats'] ) === 0 ) {
		return false;
	}
	
	$sanitized = $sanitizer->sanitize( $input, 'php' );
	$after = $inspector->inspect( $sanitized['sanitized_code'], 'php' );
	
	foreach ( $after['threats'] as $threat ) {
		if ( false !== strpos( $threat['type'], 'command_execution' ) ) {
			return false;
		}
	}
	return true;
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'Manual-review threat (extract) is detected but NOT auto-remediated', function() {
	$inspector = new CB_Codetizer_Inspector_Engine();
	$sanitizer = new CB_Codetizer_Sanitizer_Engine();
	$input = '<?php extract($_GET); ?>';
	
	// Inspector detects it.
	$before = $inspector->inspect( $input, 'php' );
	if ( count( $before['threats'] ) === 0 ) {
		return false; // Should detect extract()
	}
	
	// Sanitizer should NOT modify the code (manual review required).
	$sanitized = $sanitizer->sanitize( $input, 'php' );
	
	// The extract() call should still be present (not commented out).
	return false !== strpos( $sanitized['sanitized_code'], 'extract(' );
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'Manual-review threat (assert) is detected but NOT auto-remediated', function() {
	$inspector = new CB_Codetizer_Inspector_Engine();
	$sanitizer = new CB_Codetizer_Sanitizer_Engine();
	$input = '<?php assert($x); ?>';
	
	$before = $inspector->inspect( $input, 'php' );
	if ( count( $before['threats'] ) === 0 ) {
		return false;
	}
	
	$sanitized = $sanitizer->sanitize( $input, 'php' );
	return false !== strpos( $sanitized['sanitized_code'], 'assert(' );
} );
$pass ? $pass_count++ : $fail_count++;

// ── Already-Sanitized Input Tests ────────────────────────────────────
echo "
Already-Sanitized Input:
";

$pass = run_test( 'Already-sanitized JS eval does not grow on re-sanitize', function() {
	$sanitizer = new CB_Codetizer_Sanitizer_Engine();
	$input = '/* CB_EVAL_REMOVED */ /* CB_EVAL_REMOVED */ (1)';
	$pass1 = $sanitizer->sanitize( $input, 'javascript' );
	// The output should not contain additional CB_EVAL_REMOVED markers.
	$count_before = substr_count( $input, 'CB_EVAL_REMOVED' );
	$count_after = substr_count( $pass1['sanitized_code'], 'CB_EVAL_REMOVED' );
	return $count_after === $count_before;
} );
$pass ? $pass_count++ : $fail_count++;

$pass = run_test( 'Already-sanitized PHP eval does not grow on re-sanitize', function() {
	$sanitizer = new CB_Codetizer_Sanitizer_Engine();
	$input = '<?php // CB_EVAL_REMOVED — CB_EVAL_REMOVED (1); ?>';
	$pass1 = $sanitizer->sanitize( $input, 'php' );
	$count_before = substr_count( $input, 'CB_EVAL_REMOVED' );
	$count_after = substr_count( $pass1['sanitized_code'], 'CB_EVAL_REMOVED' );
	return $count_after === $count_before;
} );
$pass ? $pass_count++ : $fail_count++;


// ── Summary ──────────────────────────────────────────────────────────
echo "\n=== Summary ===\n";
echo "Passed: $pass_count\n";
echo "Failed: $fail_count\n";
echo "Total:  " . ( $pass_count + $fail_count ) . "\n";

exit( $fail_count > 0 ? 1 : 0 );
