# CB CODETIZER Security Test Fixtures

This directory contains adversarial test fixtures for every bypass category
identified in the Phase 2 security audit. Each fixture is an `.in` file
containing a malicious payload, and a corresponding `.expected` file
describing the expected sanitization outcome.

## Directory structure

```
tests/Fixtures/
  html/       — HTML sanitization bypass attempts
  svg/        — SVG sanitization bypass attempts
  xml/        — XML/XXE bypass attempts
  json/       — JSON prototype pollution bypass attempts
  javascript/ — JavaScript dangerous pattern detection
  php/        — PHP dangerous pattern detection
  sql/        — SQL injection test values
  uploads/    — File upload validation test descriptions
```

## Fixture naming convention

```
<category>_<bypass-class>_<description>.in
<category>_<bypass-class>_<description>.expected
```

## Usage

These fixtures are designed to be consumed by the PHPUnit test suite that
will be set up in Phase 3. Each test reads the `.in` file, runs it through
the appropriate engine (Inspector/Sanitizer/Beautifier), and asserts that
the output matches the `.expected` description.

Until PHPUnit is available, these fixtures serve as documentation of the
threats the engines must defend against, and can be verified manually.

## Categories covered

### HTML (tests/Fixtures/html/)
- script_tag_basic.in — `<script>alert(1)</script>`
- script_tag_self_closing.in — `<script/>`
- script_tag_line_split.in — `<script>\nalert(1)\n</script>`
- script_tag_attribute_split.in — `<script\n>alert(1)</script>`
- iframe_basic.in — `<iframe src="javascript:alert(1)">`
- object_embed.in — `<object data="evil.swf"><embed src="evil.swf">`
- event_handler_onclick.in — `<div onclick="alert(1)">`
- event_handler_onerror.in — `<img src=x onerror="alert(1)">`
- event_handler_onload.in — `<body onload="alert(1)">`
- event_handler_onpointerdown.in — `<div onpointerdown="alert(1)">`
- event_handler_ontouchstart.in — `<div ontouchstart="alert(1)">`
- event_handler_onwheel.in — `<div onwheel="alert(1)">`
- event_handler_onanimationstart.in — `<div onanimationstart="alert(1)">`
- event_handler_ontransitionstart.in — `<div ontransitionstart="alert(1)">`
- event_handler_onbeforeinput.in — `<div onbeforeinput="alert(1)">`
- event_handler_oninput.in — `<div oninput="alert(1)">`
- event_handler_unquoted.in — `<div onclick=alert(1)>`
- event_handler_mixed_case.in — `<div OnClick="alert(1)">`
- event_handler_whitespace.in — `<div onclick ="alert(1)">`
- url_javascript_basic.in — `<a href="javascript:alert(1)">`
- url_javascript_entity_encoded.in — `<a href="javascript&#58;alert(1)">`
- url_vbscript.in — `<a href="vbscript:msgbox(1)">`
- url_data_text_html.in — `<a href="data:text/html,<script>alert(1)</script>">`
- url_data_image_svg.in — `<img src="data:image/svg+xml,<svg onload=alert(1)>">`
- url_whitespace_obfuscated.in — `<a href="java\tscript:alert(1)">`

### SVG (tests/Fixtures/svg/)
- script_tag.in — `<svg><script>alert(1)</script></svg>`
- foreign_object.in — `<svg><foreignObject><script>alert(1)</script></foreignObject></svg>`
- use_external.in — `<svg><use href="http://evil.com/x.svg#x"/></svg>`
- use_xlink_external.in — `<svg><use xlink:href="http://evil.com/x.svg#x"/></svg>`
- doctype_entity.in — `<!DOCTYPE svg [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><svg>&xxe;</svg>`
- doctype_external_dtd.in — `<!DOCTYPE svg SYSTEM "http://evil.com/evil.dtd"><svg/>`
- entity_multiline.in — multi-line DOCTYPE with ENTITY
- onload_handler.in — `<svg onload="alert(1)">`
- href_javascript.in — `<svg><a href="javascript:alert(1)">click</a></svg>`
- xlink_href_javascript.in — `<svg><a xlink:href="javascript:alert(1)">click</a></svg>`
- animate_begin_event.in — `<svg><animate begin="click" .../></svg>`

### XML (tests/Fixtures/xml/)
- doctype_entity_basic.in — `<!DOCTYPE foo [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><foo>&xxe;</foo>`
- doctype_entity_public.in — `<!DOCTYPE foo PUBLIC "id" "http://evil.com/dtd"><foo/>`
- doctype_multiline.in — multi-line DOCTYPE
- xinclude.in — `<root xmlns:xi="http://www.w3.org/2001/XInclude"><xi:include href="http://evil.com"/></root>`
- xslt_script.in — `<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform"><xsl:script/></xsl:stylesheet>`
- php_processing_instruction.in — `<?php echo 1; ?><root/>`
- parameter_entity.in — `<!DOCTYPE foo [<!ENTITY % ext SYSTEM "http://evil.com">%ext;</foo>]><foo/>`

### JSON (tests/Fixtures/json/)
- proto_key_basic.in — `{"__proto__":{"polluted":true}}`
- proto_key_unicode_escaped.in — `{"\u005f\u005fproto\u005f\u005f":{"polluted":true}}`
- constructor_key.in — `{"constructor":{"prototype":{"polluted":true}}}`
- prototype_key.in — `{"prototype":{"polluted":true}}`
- nested_proto.in — `{"a":{"b":{"c":{"__proto__":{"polluted":true}}}}}`
- proto_in_array.in — `[{"__proto__":"x"}]`

### JavaScript (tests/Fixtures/javascript/)
- eval_basic.in — `eval("alert(1)")`
- eval_case_insensitive.in — `EvAl("alert(1)")` (PHP, not JS — for PHP detection)
- window_eval.in — `window.eval("alert(1)")`
- globalThis_eval.in — `globalThis.eval("alert(1)")`
- self_eval.in — `self.eval("alert(1)")`
- indirect_eval.in — `(0, eval)("alert(1)")`
- innerHTML.in — `el.innerHTML = "<script>alert(1)</script>"`
- innerHTML_bracket.in — `el['innerHTML'] = "x"`
- reflect_set.in — `Reflect.set(obj, '__proto__', {polluted:true})`

### PHP (tests/Fixtures/php/)
- eval_basic.in — `eval($_GET['x'])`
- eval_case_insensitive.in — `EvAl($_GET['x'])`
- system_exec.in — `system("ls")`
- passthru_exec.in — `passthru("ls")`
- unserialize.in — `unserialize($_GET['data'])`
- preg_replace_e.in — `preg_replace('/.*/e', 'eval($_GET["x"])', $input)`
- dynamic_include.in — `include($_GET['file'])`
- backtick.in — `$x = `whoami`;`
- file_get_contents_var.in — `file_get_contents($_GET['file'])`
- extract.in — `extract($_GET)`
- assert.in — `assert($_GET['x'])`

### SQL (tests/Fixtures/sql/)
- malicious_id.in — `1 OR 1=1`
- quote_injection.in — `' OR '1'='1`
- union_injection.in — `1 UNION SELECT * FROM wp_users`
- json_path_injection.in — `$.score) AS SIGNED) FROM wp_users--`
- search_value.in — `'; DROP TABLE wp_cb_codetizer_reports;--`
- orderby_injection.in — `created_at; DROP TABLE wp_users--`
- order_injection.in — `ASC; DROP TABLE wp_users--`

### Uploads (tests/Fixtures/uploads/)
- wrong_mime.in — description of .php renamed to .txt
- double_extension.in — description of file.php.txt
- oversized.in — description of >2MB file
- empty_file.in — description of 0-byte file
- php_payload_renamed.in — description of PHP script with .html extension
