<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

$arena = new CB_Codetizer_JS_Arena();
$items = $arena->get_items();
$item_param = isset( $_GET['item'] ) ? sanitize_text_field( wp_unslash( $_GET['item'] ) ) : '';
$item_id = ( '' !== $item_param && 'new' !== $item_param ) ? absint( $item_param ) : 0;
$is_editor = $item_id > 0 || 'new' === $item_param;
$item = $item_id ? $arena->get_item( $item_id ) : null;
$pages = get_pages( array( 'sort_column' => 'post_title', 'post_status' => array( 'publish', 'draft', 'pending', 'private' ) ) );
$elementor_pages = array();
if ( class_exists( '\Elementor\Plugin' ) ) {
    foreach ( $pages as $page ) {
        if ( get_post_meta( $page->ID, '_elementor_edit_mode', true ) || get_post_meta( $page->ID, '_elementor_data', true ) ) { $elementor_pages[] = $page; }
    }
}
if ( ! $item ) {
    $item = array( 'id' => 0, 'name' => '', 'language' => 'javascript', 'html' => '', 'css' => '', 'javascript' => '', 'target' => 'global', 'target_page' => 0, 'elementor_post' => 0, 'enabled' => '1' );
}

$language_labels = array( 'html' => 'HTML', 'css' => 'CSS', 'javascript' => 'JS', 'bundle' => 'HTML + CSS + JS' );
?>
<div class="wrap cb-codetizer-wrap cb-arena-screen">
<?php if ( ! $is_editor ) : ?>
    <div class="cb-wp-page-heading">
        <h1>JS Arena</h1>
        <a class="page-title-action" href="<?php echo esc_url( admin_url( 'admin.php?page=cb-codetizer-js-arena&item=new' ) ); ?>">Add Code</a>
    </div>
    <div class="cb-wp-filterbar">
        <div class="cb-wp-views"><a class="current" href="#">All (<?php echo count( $items ); ?>)</a><a href="#">JS (<?php echo count( array_filter( $items, static fn( $r ) => 'javascript' === $r['language'] ) ); ?>)</a><a href="#">CSS (<?php echo count( array_filter( $items, static fn( $r ) => 'css' === $r['language'] ) ); ?>)</a><a href="#">PHP (<?php echo count( array_filter( $items, static fn( $r ) => 'php' === $r['language'] ) ); ?>)</a><a href="#">HTML (<?php echo count( array_filter( $items, static fn( $r ) => 'html' === $r['language'] ) ); ?>)</a></div>
        <div class="cb-wp-search"><label class="screen-reader-text" for="cb-arena-search-list">Search Code Files:</label><input id="cb-arena-search-list" type="search" placeholder="Search Code Files"><button class="button">Search</button></div>
    </div>
    <div class="tablenav top"><div class="alignleft actions bulkactions"><select><option>Bulk actions</option><option>Delete</option><option>Disable</option></select><button class="button">Apply</button></div><div class="alignleft actions"><select><option>All dates</option><option>August 2026</option></select><button class="button">Filter</button></div><div class="tablenav-pages"><span class="displaying-num"><?php echo count( $items ); ?> items</span></div></div>
    <table class="wp-list-table widefat fixed striped cb-arena-list-table">
        <thead><tr><td class="manage-column check-column"><input type="checkbox" aria-label="Select All"></td><th>Name</th><th>Language</th><th>Area / Target</th><th>Status (Sent / Saved)</th><th>Date</th></tr></thead>
        <tbody>
        <?php foreach ( $items as $row ) : $post = get_post( $row['id'] ); $sent = get_post_meta( $row['id'], '_cb_arena_last_sync', true ); $status = $sent ? 'Sent' : 'Saved'; $area = 'page' === $row['target'] ? ( get_the_title( (int) $row['target_page'] ) ?: 'Specific page' ) : ucfirst( $row['target'] ); ?>
            <tr data-search="<?php echo esc_attr( strtolower( $row['name'] . ' ' . $row['language'] . ' ' . $area ) ); ?>">
                <th class="check-column"><input type="checkbox" aria-label="Select <?php echo esc_attr( $row['name'] ); ?>"></th>
                <td class="column-primary"><strong><a href="<?php echo esc_url( admin_url( 'admin.php?page=cb-codetizer-js-arena&item=' . $row['id'] ) ); ?>"><?php echo esc_html( $row['name'] ); ?></a></strong><div class="row-actions"><span><a href="<?php echo esc_url( admin_url( 'admin.php?page=cb-codetizer-js-arena&item=' . $row['id'] ) ); ?>">Edit</a> | </span><span><a href="<?php echo esc_url( admin_url( 'admin.php?page=cb-codetizer-js-arena&item=' . $row['id'] ) ); ?>">Open</a></span></div></td>
                <td><span class="cb-language-pill cb-language-<?php echo esc_attr( sanitize_html_class( $row['language'] ) ); ?>"><?php echo esc_html( $language_labels[ $row['language'] ] ?? strtoupper( $row['language'] ) ); ?></span></td>
                <td><?php echo esc_html( $area ); ?></td>
                <td><span class="cb-status-pill <?php echo 'Sent' === $status ? 'is-sent' : ''; ?>"><?php echo esc_html( $status ); ?></span></td>
                <td><?php echo $post ? esc_html( wp_date( 'Y/m/d \a\t g:i a', strtotime( $post->post_modified ) ) ) : ''; ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
        <tfoot><tr><td class="manage-column check-column"><input type="checkbox" aria-label="Select All"></td><th>Name</th><th>Language</th><th>Area / Target</th><th>Status (Sent / Saved)</th><th>Date</th></tr></tfoot>
    </table>
<?php else : ?>
    <div class="cb-arena-editor-heading"><div><a href="<?php echo esc_url( admin_url( 'admin.php?page=cb-codetizer-js-arena' ) ); ?>" class="cb-arena-back">← JS Arena</a><h1><?php echo esc_html( $item['name'] ?: 'New Code File' ); ?> <span class="cb-status-pill">Saved</span></h1></div><a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=cb-codetizer-js-arena' ) ); ?>">All Files</a></div>
    <?php if ( isset( $_GET['saved'] ) ) : ?><div class="notice notice-success is-dismissible"><p>Code file saved successfully.</p></div><?php endif; ?>
    <?php if ( isset( $_GET['synced'] ) ) : ?><div class="notice notice-success is-dismissible"><p>Code sent to Elementor successfully.</p></div><?php endif; ?>
    <div class="cb-arena-editor-layout">
        <aside class="cb-arena-file-sidebar">
            <div class="cb-arena-file-sidebar-head"><strong>FILES</strong><a class="button button-small" href="<?php echo esc_url( admin_url( 'admin.php?page=cb-codetizer-js-arena&item=new' ) ); ?>">+ Add Code</a></div>
            <?php foreach ( $items as $row ) : ?><a class="cb-arena-file <?php echo $row['id'] === $item['id'] ? 'is-active' : ''; ?>" href="<?php echo esc_url( admin_url( 'admin.php?page=cb-codetizer-js-arena&item=' . $row['id'] ) ); ?>"><span class="dashicons dashicons-media-code"></span><strong><?php echo esc_html( $row['name'] ); ?></strong><em><?php echo esc_html( strtoupper( $row['language'] ) ); ?></em></a><?php endforeach; ?>
        </aside>
        <main class="cb-arena-editor-main">
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="cb-arena-form">
                <input type="hidden" name="action" value="cb_codetizer_arena_save"><input type="hidden" name="item_id" value="<?php echo (int) $item['id']; ?>"><?php wp_nonce_field( 'cb_codetizer_arena_save', 'cb_codetizer_arena_nonce' ); ?>
                <div class="cb-arena-file-title"><label class="screen-reader-text">File name</label><input name="name" value="<?php echo esc_attr( $item['name'] ); ?>" placeholder="settings.js"><span class="cb-file-extension">.code</span><span class="cb-arena-saved-badge">Saved</span><button class="button button-primary" type="submit">Save</button></div>
                <div class="cb-arena-meta-row"><label>Name / file extension is kept exactly as entered.</label><label>Language <select name="language"><option value="html" <?php selected( $item['language'], 'html' ); ?>>HTML</option><option value="css" <?php selected( $item['language'], 'css' ); ?>>CSS</option><option value="javascript" <?php selected( $item['language'], 'javascript' ); ?>>JavaScript</option><option value="bundle" <?php selected( $item['language'], 'bundle' ); ?>>HTML + CSS + JS</option></select></label></div>
                <div class="cb-arena-editor-toolbar"><div class="cb-pb-mode-pills"><button type="button" class="cb-pb-mode is-active" data-arena-mode="code">Code Editor</button><button type="button" class="cb-pb-mode" data-arena-mode="block">Block Editor</button></div><span>Lines <b id="cb-arena-lines">0</b> · Words <b id="cb-arena-words">0</b> · Chars <b id="cb-arena-chars">0</b></span></div>
                <div class="cb-arena-code-shell"><div class="cb-pb-gutter" id="cb-arena-gutter" aria-hidden="true"></div><textarea class="cb-arena-big-code" name="javascript" id="cb-arena-code" spellcheck="false" placeholder="Paste code here..."><?php echo esc_textarea( $item['javascript'] ); ?></textarea></div>
                <details class="cb-arena-code-sections"><summary>HTML</summary><textarea name="html" class="cb-arena-secondary-code" spellcheck="false"><?php echo esc_textarea( $item['html'] ); ?></textarea></details>
                <details class="cb-arena-code-sections"><summary>CSS</summary><textarea name="css" class="cb-arena-secondary-code" spellcheck="false"><?php echo esc_textarea( $item['css'] ); ?></textarea></details>
                <div class="cb-arena-count-footer"><span>Code size: <b id="cb-arena-size">0 KB</b></span><span>Every necessary code count is calculated live.</span></div>
                <div class="cb-arena-target-card"><h2>Where is it needed?</h2><div class="cb-arena-target-grid"><label>Area <select name="target" id="cb-arena-target"><option value="global" <?php selected( $item['target'], 'global' ); ?>>Global</option><option value="header" <?php selected( $item['target'], 'header' ); ?>>Header</option><option value="footer" <?php selected( $item['target'], 'footer' ); ?>>Footer</option><option value="page" <?php selected( $item['target'], 'page' ); ?>>Specific WordPress page</option><option value="elementor" <?php selected( $item['target'], 'elementor' ); ?>>Elementor page</option></select></label><label>Specific page <select name="target_page"><option value="0">Select page</option><?php foreach ( $pages as $page ) : ?><option value="<?php echo (int) $page->ID; ?>" <?php selected( (int) $item['target_page'], $page->ID ); ?>><?php echo esc_html( $page->post_title . ' (#' . $page->ID . ')' ); ?></option><?php endforeach; ?></select></label><label>Elementor page <select name="elementor_post"><option value="0">Select Elementor page</option><?php foreach ( $elementor_pages as $page ) : ?><option value="<?php echo (int) $page->ID; ?>" <?php selected( (int) $item['elementor_post'], $page->ID ); ?>><?php echo esc_html( $page->post_title . ' (#' . $page->ID . ')' ); ?></option><?php endforeach; ?></select></label><label class="cb-arena-active"><input type="checkbox" name="enabled" value="1" <?php checked( $item['enabled'], '1' ); ?>> Active on site</label></div></div>
            </form>
            <?php if ( $item['id'] && class_exists( '\Elementor\Plugin' ) ) : ?><div class="cb-arena-send-card"><div><strong>Send this file to Elementor</strong><span>The existing Elementor document will be backed up before changes are written.</span></div><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="cb_codetizer_arena_sync_elementor"><input type="hidden" name="item_id" value="<?php echo (int) $item['id']; ?>"><input type="hidden" name="elementor_post" value="<?php echo (int) $item['elementor_post']; ?>"><?php wp_nonce_field( 'cb_codetizer_arena_sync_elementor', 'cb_codetizer_arena_nonce' ); ?><button class="button button-primary" type="submit" <?php disabled( ! $item['elementor_post'] ); ?>>Send to Elementor</button></form></div><?php endif; ?>
        </main>
    </div>
<?php endif; ?>
</div>
