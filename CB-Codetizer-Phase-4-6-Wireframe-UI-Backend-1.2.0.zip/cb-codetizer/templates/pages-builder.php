<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

$builder = new CB_Codetizer_Pages_Builder();
$pages   = $builder->get_pages();
$page_id = isset( $_GET['page_id'] ) ? absint( $_GET['page_id'] ) : 0;
$selected_page = $page_id ? get_post( $page_id ) : null;
$draft = $page_id ? $builder->get_draft( $page_id ) : array( 'page_id' => 0, 'blocks' => array() );
$blocks = is_array( $draft['blocks'] ?? null ) ? $draft['blocks'] : array();

$elementor_available = false;
$elements = array();
if ( class_exists( 'CB_Codetizer_Elementor_Integration' ) ) {
    $elementor_service = new CB_Codetizer_Elementor_Integration( new CB_Codetizer_Backups() );
    $elementor_available = $elementor_service->available();
    if ( $selected_page && $elementor_available ) {
        $found = $elementor_service->discover_elements( $page_id );
        if ( ! is_wp_error( $found ) ) { $elements = $found; }
    }
}

$block_by_element = array();
foreach ( $blocks as $block ) {
    if ( isset( $block['element_id'] ) ) { $block_by_element[ (string) $block['element_id'] ] = $block; }
}

$status_object = $selected_page ? get_post_status_object( $selected_page->post_status ) : null;
$builder_status = $selected_page ? ( get_post_meta( $selected_page->ID, CB_Codetizer_Pages_Builder::STATUS_META_KEY, true ) ?: ( 'publish' === $selected_page->post_status ? 'publish' : 'saved' ) ) : 'publish';
$editor_status = 'publish' === $builder_status ? 'Published' : ( 'draft' === $builder_status ? 'Draft' : 'Saved' );
?>
<div class="wrap cb-codetizer-wrap cb-pb-screen">
    <?php if ( ! $selected_page ) : ?>
        <div class="cb-wp-page-heading">
            <h1>Pages Builder <span class="cb-pb-elementor-pill">Elementor</span></h1>
            <a class="page-title-action" href="<?php echo esc_url( admin_url( 'post-new.php?post_type=page' ) ); ?>">Add Page</a>
        </div>

        <div class="cb-wp-filterbar">
            <div class="cb-wp-views">
                <a class="current" href="#">All (<?php echo count( $pages ); ?>)</a>
                <a href="#">Published (<?php echo count( array_filter( $pages, static fn( $p ) => 'publish' === $p['status'] ) ); ?>)</a>
                <a href="#">Draft (<?php echo count( array_filter( $pages, static fn( $p ) => 'draft' === $p['status'] ) ); ?>)</a>
            </div>
            <form method="get" class="cb-wp-search">
                <input type="hidden" name="page" value="cb-codetizer-pages-builder">
                <label class="screen-reader-text" for="cb-pb-search-list">Search Pages:</label>
                <input id="cb-pb-search-list" type="search" name="s" value="<?php echo esc_attr( $_GET['s'] ?? '' ); ?>" placeholder="Search Pages">
                <button class="button">Search Pages</button>
            </form>
        </div>

        <div class="tablenav top">
            <div class="alignleft actions bulkactions">
                <select><option>Bulk actions</option><option>Bulk edit</option><option>Move to Trash</option></select>
                <button class="button">Apply</button>
            </div>
            <div class="alignleft actions">
                <select><option>All dates</option><option>August 2026</option></select>
                <button class="button">Filter</button>
            </div>
            <div class="tablenav-pages"><span class="displaying-num"><?php echo count( $pages ); ?> items</span></div>
        </div>

        <table class="wp-list-table widefat fixed striped cb-pb-list-table">
            <thead><tr>
                <td class="manage-column check-column"><input type="checkbox" aria-label="Select All"></td>
                <th>Title</th><th>Language</th><th>Status (Sent / Saved)</th><th>Comments</th><th>Date</th>
            </tr></thead>
            <tbody>
            <?php foreach ( $pages as $page ) :
                $search = strtolower( $page['name'] . ' ' . $page['language'] . ' ' . $page['status'] );
                $sent = get_post_meta( $page['id'], '_cb_codetizer_pages_builder_last_send', true );
                $saved = ! empty( $page['blocks'] );
                $status_text = $sent ? 'Sent' : ( $saved ? 'Saved' : 'Saved' );
                ?>
                <tr data-search="<?php echo esc_attr( $search ); ?>">
                    <th class="check-column"><input type="checkbox" aria-label="Select <?php echo esc_attr( $page['name'] ); ?>"></th>
                    <td class="column-primary">
                        <strong><a href="<?php echo esc_url( admin_url( 'admin.php?page=cb-codetizer-pages-builder&page_id=' . $page['id'] ) ); ?>"><?php echo esc_html( $page['name'] ); ?></a></strong>
                        <div class="row-actions"><span><a href="<?php echo esc_url( admin_url( 'post.php?post=' . $page['id'] . '&action=edit' ) ); ?>">Edit</a> | </span><span><a href="<?php echo esc_url( admin_url( 'admin.php?page=cb-codetizer-pages-builder&page_id=' . $page['id'] ) ); ?>">Build</a> | </span><span><a href="<?php echo esc_url( get_permalink( $page['id'] ) ); ?>" target="_blank">View</a></span></div>
                    </td>
                    <td><?php echo esc_html( $page['language'] ); ?></td>
                    <td><span class="cb-status-pill <?php echo 'Sent' === $status_text ? 'is-sent' : ''; ?>"><?php echo esc_html( $status_text ); ?></span></td>
                    <td>—</td>
                    <td><?php echo esc_html( 'publish' === $page['status'] ? 'Published' : ucfirst( $page['status'] ) ); ?><br><span class="description"><?php echo esc_html( wp_date( 'Y/m/d \a\t g:i a', strtotime( $page['updated'] ) ) ); ?></span></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
            <tfoot><tr>
                <td class="manage-column check-column"><input type="checkbox" aria-label="Select All"></td>
                <th>Title</th><th>Language</th><th>Status (Sent / Saved)</th><th>Comments</th><th>Date</th>
            </tr></tfoot>
        </table>
    <?php else : ?>
        <div class="cb-pb-builder-heading">
            <div class="cb-pb-heading-left">
                <h1>Pages Builder <span class="cb-pb-elementor-pill">Elementor</span></h1>
                <span class="cb-pb-page-history">Page: <?php echo esc_html( $selected_page->post_title ?: '(Untitled)' ); ?></span>
                <a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=cb-codetizer-pages-builder' ) ); ?>">History</a>
            </div>
            <div class="cb-pb-heading-right">
                <button type="button" class="button cb-pb-status-button" id="cb-pb-status-button"><span><?php echo esc_html( $editor_status ); ?></span><span class="dashicons dashicons-arrow-down-alt2"></span></button>
                <div class="cb-pb-status-menu" id="cb-pb-status-menu"><button type="button" data-status="publish">Published</button><button type="button" data-status="draft">Draft</button><button type="button" data-status="saved">Saved</button></div>
            </div>
        </div>

        <?php if ( isset( $_GET['saved'] ) ) : ?><div class="notice notice-success is-dismissible"><p>Pages Builder saved.</p></div><?php endif; ?>
        <?php if ( isset( $_GET['sent'] ) ) : ?><div class="notice notice-success is-dismissible"><p>Sent to Elementor. Updated <?php echo absint( $_GET['updated'] ?? 0 ); ?> real HTML element(s).</p></div><?php endif; ?>
        <?php if ( ! $elementor_available ) : ?><div class="notice notice-warning"><p>Elementor is not loaded. Page Builder will still retain its draft, but real Elementor element discovery and sending are unavailable.</p></div><?php endif; ?>
        <?php if ( $elementor_available && ! $elements ) : ?><div class="notice notice-info"><p>No existing Elementor HTML widgets were found. Add an actual <strong>HTML</strong> widget inside the Elementor container, save the page, and return here. Codetizer never invents fake Elementor containers.</p></div><?php endif; ?>

        <div class="cb-pb-workspace">
            <aside class="cb-pb-sidebar">
                <div class="cb-pb-sidebar-tools">
                    <input id="cb-pb-element-search" type="search" placeholder="Search containers..." aria-label="Search containers">
                    <button type="button" class="button button-primary" id="cb-pb-select-toggle">Select Container <span class="dashicons dashicons-arrow-down-alt2"></span></button>
                </div>
                <div class="cb-pb-tree" id="cb-pb-tree">
                    <?php
                    $section_index = 0;
                    $last_section = '';
                    $container_index = 0;
                    foreach ( $elements as $element ) :
                        $section = $element['section_label'] ?? 'Section';
                        if ( $section !== $last_section ) {
                            $section_index++;
                            $container_index = 0;
                            $last_section = $section;
                            echo '<div class="cb-pb-tree-section" data-section="' . esc_attr( strtolower( $section ) ) . '"><button type="button" class="cb-pb-section-toggle" aria-expanded="true"><span class="dashicons dashicons-arrow-down-alt2"></span></button><input class="cb-pb-section-name" value="' . esc_attr( $section ) . '" aria-label="Section name"><span class="cb-pb-eye">◉</span></div>';
                        }
                        $container_index++;
                        $block = $block_by_element[ $element['id'] ] ?? array();
                        $manual_name = $block['container_name'] ?? ( $element['container_label'] ?? 'HTML Container' );
                        $active = isset( $block_by_element[ $element['id'] ] );
                        ?>
                        <button type="button" class="cb-pb-tree-item <?php echo $active ? 'is-selected' : ''; ?>" data-element-id="<?php echo esc_attr( $element['id'] ); ?>" data-section="<?php echo esc_attr( $section ); ?>" data-container="<?php echo esc_attr( $manual_name ); ?>" data-label="<?php echo esc_attr( $element['label'] ); ?>">
                            <span class="cb-pb-tree-branch">└─</span><span class="cb-pb-container-number">Container <?php echo (int) $container_index; ?></span><span class="cb-pb-tree-label"><?php echo esc_html( $manual_name ); ?></span><span class="cb-pb-eye">◉</span>
                        </button>
                    <?php endforeach; ?>
                    <?php if ( ! $elements ) : ?><div class="cb-pb-tree-empty">No real HTML widgets discovered yet.</div><?php endif; ?>
                </div>
                <button type="button" class="cb-pb-add-section" id="cb-pb-add-section"><span class="dashicons dashicons-plus-alt2"></span> Add Section</button>
            </aside>

            <main class="cb-pb-main">
                <form id="cb-pb-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                    <input type="hidden" name="action" value="cb_codetizer_pages_builder_save">
                    <input type="hidden" name="page_id" value="<?php echo (int) $page_id; ?>"><input type="hidden" name="builder_status" id="cb-pb-builder-status" value="<?php echo esc_attr( $builder_status ); ?>">
                    <?php wp_nonce_field( 'cb_codetizer_pages_builder_save', 'cb_codetizer_pages_builder_nonce' ); ?>
                    <div id="cb-pb-blocks">
                    <?php foreach ( $blocks as $index => $block ) :
                        $section_name = $block['section_name'] ?? 'Section';
                        $container_name = $block['container_name'] ?? $block['name'];
                        $mode = $block['editor_mode'] ?? 'code';
                        ?>
                        <section class="cb-pb-code-card" data-element-id="<?php echo esc_attr( $block['element_id'] ); ?>">
                            <div class="cb-pb-code-card-head">
                                <div class="cb-pb-breadcrumb"><span><?php echo esc_html( $section_name ); ?></span><span>/</span><strong><?php echo esc_html( $container_name ); ?></strong></div>
                                <button type="button" class="button-link cb-pb-collapse" aria-expanded="true"><span class="dashicons dashicons-arrow-down-alt2"></span><span>Collapse</span></button>
                            </div>
                            <div class="cb-pb-code-card-body">
                                <input type="hidden" name="blocks[<?php echo $index; ?>][id]" value="<?php echo esc_attr( $block['id'] ); ?>">
                                <input type="hidden" name="blocks[<?php echo $index; ?>][element_id]" value="<?php echo esc_attr( $block['element_id'] ); ?>">
                                <input type="hidden" name="blocks[<?php echo $index; ?>][element_type]" value="widget:html">
                                <input type="hidden" name="blocks[<?php echo $index; ?>][section_name]" class="cb-pb-section-hidden" value="<?php echo esc_attr( $section_name ); ?>">
                                <input type="hidden" name="blocks[<?php echo $index; ?>][container_name]" class="cb-pb-container-hidden" value="<?php echo esc_attr( $container_name ); ?>">
                                <div class="cb-pb-card-meta">
                                    <label>Name <input name="blocks[<?php echo $index; ?>][name]" class="regular-text cb-pb-name" value="<?php echo esc_attr( $block['name'] ); ?>"></label>
                                    <label>Language <select name="blocks[<?php echo $index; ?>][language]"><option value="html" <?php selected( $block['language'], 'html' ); ?>>HTML</option><option value="css" <?php selected( $block['language'], 'css' ); ?>>CSS</option><option value="javascript" <?php selected( $block['language'], 'javascript' ); ?>>JavaScript</option></select></label>
                                    <label>Actual Elementor HTML ID <code><?php echo esc_html( $block['element_id'] ); ?></code></label>
                                </div>
                                <div class="cb-pb-editor-toolbar"><div class="cb-pb-mode-pills"><button type="button" class="cb-pb-mode <?php echo 'code' === $mode ? 'is-active' : ''; ?>" data-mode="code">Code Editor</button><button type="button" class="cb-pb-mode <?php echo 'block' === $mode ? 'is-active' : ''; ?>" data-mode="block">Block Editor</button></div><span class="cb-pb-live-status">Saved locally in this draft</span></div>
                                <input type="hidden" name="blocks[<?php echo $index; ?>][editor_mode]" class="cb-pb-mode-value" value="<?php echo esc_attr( $mode ); ?>">
                                <div class="cb-pb-code-editor" data-editor-mode="<?php echo esc_attr( $mode ); ?>">
                                    <div class="cb-pb-gutter" aria-hidden="true"></div>
                                    <textarea class="cb-pb-code" name="blocks[<?php echo $index; ?>][code]" spellcheck="false"><?php echo esc_textarea( $block['code'] ); ?></textarea>
                                </div>
                                <div class="cb-pb-block-editor" hidden><div class="cb-pb-block-preview" contenteditable="true" spellcheck="false"></div></div>
                                <div class="cb-pb-code-footer"><span class="cb-pb-count">0 characters · 0 lines</span><span>Target: real Elementor HTML widget</span></div>
                            </div>
                        </section>
                    <?php endforeach; ?>
                    </div>

                    <details class="cb-pb-more-containers">
                        <summary>Select more containers</summary>
                        <div class="cb-pb-more-grid">
                        <?php foreach ( $elements as $element ) : if ( isset( $block_by_element[ $element['id'] ] ) ) { continue; } ?>
                            <label class="cb-pb-more-option"><input type="checkbox" class="cb-pb-add-check" value="<?php echo esc_attr( $element['id'] ); ?>" data-label="<?php echo esc_attr( $element['label'] ); ?>" data-section="<?php echo esc_attr( $element['section_label'] ?? 'Section' ); ?>" data-container="<?php echo esc_attr( $element['container_label'] ?? 'HTML Container' ); ?>"><span><strong><?php echo esc_html( $element['container_label'] ?? 'HTML Container' ); ?></strong><small><?php echo esc_html( ( $element['section_label'] ?? 'Section' ) . ' · HTML #' . $element['id'] ); ?></small></span></label>
                        <?php endforeach; ?>
                        </div>
                        <button type="button" class="button" id="cb-pb-add-selected">Add Selected Containers</button>
                    </details>

                    <div class="cb-pb-bottom-actions">
                        <button class="button button-primary button-large" type="submit">Save to Pages Builder</button>
                        <span class="cb-pb-bottom-note">Draft changes are stored on this WordPress page until you send them to Elementor.</span>
                    </div>
                </form>

                <div class="cb-pb-sendbar">
                    <div><strong>Ready for Elementor?</strong><span>Creates a backup, then updates only the selected real HTML widget IDs.</span></div>
                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                        <input type="hidden" name="action" value="cb_codetizer_pages_builder_send"><input type="hidden" name="page_id" value="<?php echo (int) $page_id; ?>">
                        <?php wp_nonce_field( 'cb_codetizer_pages_builder_send', 'cb_codetizer_pages_builder_nonce' ); ?>
                        <button class="button button-primary button-large" type="submit" <?php disabled( ! $elementor_available || ! $elements ); ?>>Send to Elementor</button>
                    </form>
                </div>
            </main>
        </div>
    <?php endif; ?>
</div>
