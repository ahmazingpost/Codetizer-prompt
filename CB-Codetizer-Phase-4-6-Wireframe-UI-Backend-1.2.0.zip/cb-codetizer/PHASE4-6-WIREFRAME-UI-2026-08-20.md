# CB CODETIZER Phase 4-6 — Wireframe UI + Backend

This build keeps the existing Phase 4-6 backend and adds the WordPress-style Pages Builder and JS Arena screens based on the approved wireframe.

## Pages Builder

- First screen uses a WordPress-style Pages list with All / Published / Draft views, search, bulk controls, date filter, table rows, status, comments and date.
- Existing WordPress pages are loaded automatically.
- Opening a page switches to the builder workspace.
- Elementor data is inspected from the page's real `_elementor_data`.
- Only existing Elementor HTML widgets are selectable targets. The builder never creates fake container IDs.
- The left tree groups real HTML widgets under discovered Elementor section/container hierarchy.
- Section and container labels can be renamed in the builder draft without changing Elementor's actual IDs.
- Each selected target has a collapsible code card with:
  - section/container breadcrumb
  - manual block name
  - language
  - real Elementor HTML element ID
  - Code Editor / Block Editor toggle
  - line numbers
  - live character/line counts
- Additional real HTML widgets can be selected under "Select more containers".
- Save stores the builder draft in page metadata.
- Send to Elementor creates a backup and updates only the exact existing Elementor HTML widget IDs in the saved draft.

## JS Arena

- First screen uses a WordPress-style file list with language filters, search, bulk controls, date filter, status and date columns.
- Existing code items are loaded automatically.
- Add Code opens the editor workspace.
- File editor has a file name, language, saved state, code editor, line numbers, live lines/words/chars/size, and collapsible HTML/CSS sections.
- Area/target supports Global, Header, Footer, Specific WordPress page, and Elementor page.
- Existing Elementor sync behavior is preserved and now records a last-sync timestamp for the Sent/Saved status.

## Safety / compatibility

- Existing Phase 4-6 files were retained as the base.
- No WordPress core files are modified.
- No Elementor fake elements are introduced by Pages Builder.
- Existing backups, REST routes, services, reports, sanitizer, inspector, beautifier, and JS Arena storage remain in place.
- PHP syntax was checked across the plugin.
- Pages Builder, Elementor integration and JS Arena modified files were linted individually.
- JavaScript files were checked with Node syntax validation.

Full end-to-end WordPress/Elementor runtime testing still needs to be executed on the user's Laragon installation because this build environment does not contain the user's WordPress database/runtime.
