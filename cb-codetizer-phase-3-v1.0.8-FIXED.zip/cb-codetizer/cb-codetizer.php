<?php
/**
 * Plugin Name: CB CODETIZER
 * Plugin URI:  https://example.com/cb-codetizer
 * Description: A comprehensive code inspection, sanitization, and beautification toolkit for WordPress administrators. Scan code for security threats, sanitize malicious patterns, and beautify source code across multiple languages.
 * Version:     1.0.8
 * Author:      CB Plugins
 * Author URI:  https://example.com
 * License:     GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: cb-codetizer
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 8.1
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Minimum PHP version check.
 */
if ( version_compare( PHP_VERSION, '8.1', '<' ) ) {
	/**
	 * Displays an admin notice when the PHP version is too low.
	 */
	function cb_codetizer_php_version_notice() {
		$php_version = PHP_VERSION;
		$message     = sprintf(
			/* translators: 1: Minimum required PHP version, 2: Current PHP version */
			esc_html__( 'CB CODETIZER requires PHP version %1$s or higher. Your server is running PHP %2$s. Please upgrade your PHP version to use this plugin.', 'cb-codetizer' ),
			esc_html( '8.1' ),
			esc_html( $php_version )
		);
		echo '<div class="notice notice-error"><p>' . wp_kses_post( $message ) . '</p></div>';
	}
	add_action( 'admin_notices', 'cb_codetizer_php_version_notice' );
	return;
}

/**
 * Plugin version constant.
 */
define( 'CB_CODETIZER_VERSION', '1.0.0' );

/**
 * Absolute path to the plugin directory.
 */
define( 'CB_CODETIZER_PATH', plugin_dir_path( __FILE__ ) );

/**
 * Absolute URL to the plugin directory.
 */
define( 'CB_CODETIZER_URL', plugin_dir_url( __FILE__ ) );

/**
 * Plugin basename (e.g., cb-codetizer/cb-codetizer.php).
 */
define( 'CB_CODETIZER_BASENAME', plugin_basename( __FILE__ ) );

/**
 * Minimum required PHP version.
 */
define( 'CB_CODETIZER_MIN_PHP', '8.1' );

/**
 * Activation hook callback.
 *
 * @return void
 */
function cb_codetizer_activate() {
	require_once CB_CODETIZER_PATH . 'includes/class-installer.php';
	CB_Codetizer_Installer::activate();
}
register_activation_hook( __FILE__, 'cb_codetizer_activate' );

/**
 * Deactivation hook callback.
 *
 * Cleans up transient data and flushes rewrite rules.
 *
 * @return void
 */
function cb_codetizer_deactivate() {
	delete_transient( 'cb_codetizer_activated' );
	delete_transient( 'cb_codetizer_activity_log' );
	wp_cache_flush();
}
register_deactivation_hook( __FILE__, 'cb_codetizer_deactivate' );

/**
 * Boot the plugin after WordPress is fully loaded.
 *
 * @return void
 */
function cb_codetizer_boot() {
	require_once CB_CODETIZER_PATH . 'includes/class-loader.php';
	CB_Codetizer_Loader::init();
}
add_action( 'plugins_loaded', 'cb_codetizer_boot' );

/**
 * Adds a Settings link to the plugin action links on the Plugins page.
 *
 * @param array $links Existing plugin action links.
 * @return array Modified plugin action links.
 */
function cb_codetizer_plugin_action_links( array $links ): array {
	$settings_url = admin_url( 'admin.php?page=cb-codetizer-settings' );
	$settings_link = sprintf(
		'<a href="%s" aria-label="%s">%s</a>',
		esc_url( $settings_url ),
		esc_attr__( 'Navigate to CB Codetizer Settings', 'cb-codetizer' ),
		esc_html__( 'Settings', 'cb-codetizer' )
	);

	array_unshift( $links, $settings_link );

	return $links;
}
add_filter( 'plugin_action_links_' . CB_CODETIZER_BASENAME, 'cb_codetizer_plugin_action_links' );
