<?php
/**
 * CB CODETIZER - Uninstaller
 *
 * Removes all plugin data including options, database tables,
 * transients, and scheduled cron events when the plugin is uninstalled.
 *
 * @package CB_Codetizer
 */

// Prevent direct access outside of WordPress uninstall process.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
        exit;
}

// --- Delete all plugin options ---

$plugin_options = array(
        'cb_codetizer_max_upload_size',
        'cb_codetizer_default_language',
        'cb_codetizer_scan_profile',
        'cb_codetizer_indent_size',
        'cb_codetizer_indent_type',
        'cb_codetizer_max_input_bytes',
        'cb_codetizer_db_version',
);

foreach ( $plugin_options as $option_name ) {
        delete_option( $option_name );
}

// --- Delete transients ---

delete_transient( 'cb_codetizer_activated' );
delete_transient( 'cb_codetizer_activity_log' );

// --- Drop the custom database table ---

global $wpdb;

$table_name = $wpdb->prefix . 'cb_codetizer_reports';
// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name is a fixed prefix.
$wpdb->query( "DROP TABLE IF EXISTS {$table_name}" );

// --- Clear any scheduled cron events ---

$cron_hooks = array(
        'cb_codetizer_cleanup_event',
        'cb_codetizer_scheduled_scan',
);

foreach ( $cron_hooks as $hook ) {
        wp_clear_scheduled_hook( $hook );
}

// --- Clean up any user meta added by the plugin ---

$wpdb->query(
        $wpdb->prepare(
                "DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE %s",
                $wpdb->esc_like( 'cb_codetizer_' ) . '%'
        )
);
