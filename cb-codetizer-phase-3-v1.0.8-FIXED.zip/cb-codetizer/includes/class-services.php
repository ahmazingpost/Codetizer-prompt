<?php
/**
 * CB CODETIZER - Services
 *
 * A minimal, dependency-free access point for the three core engines
 * (Inspector, Sanitizer, Beautifier). This deliberately is NOT a
 * dependency-injection container — it is a thin static factory so that
 * callers (currently class-ajax.php; potentially future REST controllers
 * or Elementor integration code in a later phase) obtain engine instances
 * through one place instead of calling `new CB_Codetizer_*_Engine()`
 * directly everywhere.
 *
 * Each engine is stateless per request (no constructor arguments, no
 * persisted state between calls), so instances are cached for the
 * duration of the request to avoid repeated construction — this is a
 * micro-optimization, not a correctness requirement.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CB_Codetizer_Services
 *
 * Static accessors for the core engines. Intentionally minimal: no
 * container, no autowiring, no configuration — just three methods.
 */
class CB_Codetizer_Services {

	/**
	 * Cached engine instances, keyed by class name.
	 *
	 * @var array<string, object>
	 */
	private static array $instances = array();

	/**
	 * Get the Inspector engine instance.
	 *
	 * @return CB_Codetizer_Inspector_Engine
	 */
	public static function inspector(): CB_Codetizer_Inspector_Engine {
		if ( ! isset( self::$instances[ CB_Codetizer_Inspector_Engine::class ] ) ) {
			self::$instances[ CB_Codetizer_Inspector_Engine::class ] = new CB_Codetizer_Inspector_Engine();
		}
		return self::$instances[ CB_Codetizer_Inspector_Engine::class ];
	}

	/**
	 * Get the Sanitizer engine instance.
	 *
	 * @return CB_Codetizer_Sanitizer_Engine
	 */
	public static function sanitizer(): CB_Codetizer_Sanitizer_Engine {
		if ( ! isset( self::$instances[ CB_Codetizer_Sanitizer_Engine::class ] ) ) {
			self::$instances[ CB_Codetizer_Sanitizer_Engine::class ] = new CB_Codetizer_Sanitizer_Engine();
		}
		return self::$instances[ CB_Codetizer_Sanitizer_Engine::class ];
	}

	/**
	 * Get the Beautifier engine instance.
	 *
	 * @return CB_Codetizer_Beautifier_Engine
	 */
	public static function beautifier(): CB_Codetizer_Beautifier_Engine {
		if ( ! isset( self::$instances[ CB_Codetizer_Beautifier_Engine::class ] ) ) {
			self::$instances[ CB_Codetizer_Beautifier_Engine::class ] = new CB_Codetizer_Beautifier_Engine();
		}
		return self::$instances[ CB_Codetizer_Beautifier_Engine::class ];
	}

	/**
	 * Reset all cached instances.
	 *
	 * Not used in normal request handling (each request is a fresh PHP
	 * process). Exposed for tests that need a clean slate.
	 *
	 * @return void
	 */
	public static function reset(): void {
		self::$instances = array();
	}
}
