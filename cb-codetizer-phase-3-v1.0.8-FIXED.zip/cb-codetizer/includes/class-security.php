<?php
/**
 * CB CODETIZER - Security
 *
 * Provides security utilities for nonce verification, capability checks,
 * input sanitization, file upload validation, and output escaping.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CB_Codetizer_Security
 *
 * Static utility class encapsulating all security-related operations
 * for the CB Codetizer plugin.
 */
class CB_Codetizer_Security {

	/**
	 * Verify a WordPress nonce for AJAX or form submissions.
	 *
	 * Retrieves the nonce value from the request body (POST only) and
	 * verifies it against the expected action. Sends a JSON error
	 * response and terminates execution on failure.
	 *
	 * Reading from $_POST (rather than $_REQUEST) narrows the CSRF
	 * surface: a nonce cannot be supplied via the URL or a cookie.
	 *
	 * @param string $action      The nonce action string.
	 * @param string $nonce_field The key used to retrieve the nonce from the request. Default 'cb_codetizer_nonce'.
	 * @return void
	 */
	public static function verify_nonce( string $action, string $nonce_field = 'cb_codetizer_nonce' ): void {
		$nonce = isset( $_POST[ $nonce_field ] ) ? sanitize_text_field( wp_unslash( $_POST[ $nonce_field ] ) ) : '';

		if ( 1 !== wp_verify_nonce( $nonce, $action ) ) {
			wp_send_json_error(
				array(
					'message' => esc_html__( 'Security verification failed. Please refresh the page and try again.', 'cb-codetizer' ),
				),
				403
			);
		}
	}

	/**
	 * Verify a WordPress nonce against any of the provided actions.
	 *
	 * Accepts the nonce from POST only. If at least one of the supplied
	 * actions verifies successfully, the request is considered authenticated.
	 * Sends a JSON error response and terminates execution only if none
	 * of the actions verify.
	 *
	 * This exists to support handlers that are legitimately reachable from
	 * more than one admin page, where each page emits a nonce bound to a
	 * different action string (e.g. "Clear all reports" is reachable from
	 * both the Reports page and the Settings page).
	 *
	 * @param string[] $actions     One or more nonce action strings. The first that verifies wins.
	 * @param string   $nonce_field The key used to retrieve the nonce from POST. Default 'cb_codetizer_nonce'.
	 * @return void
	 */
	public static function verify_nonce_any( array $actions, string $nonce_field = 'cb_codetizer_nonce' ): void {
		$nonce = isset( $_POST[ $nonce_field ] ) ? sanitize_text_field( wp_unslash( $_POST[ $nonce_field ] ) ) : '';

		foreach ( $actions as $action ) {
			if ( is_string( $action ) && 1 === wp_verify_nonce( $nonce, $action ) ) {
				return;
			}
		}

		wp_send_json_error(
			array(
				'message' => esc_html__( 'Security verification failed. Please refresh the page and try again.', 'cb-codetizer' ),
			),
			403
		);
	}

	/**
	 * Verify that the current user has a specific capability.
	 *
	 * Sends a JSON error response and terminates execution
	 * if the user lacks the required capability.
	 *
	 * @param string $capability The capability to check. Default 'manage_options'.
	 * @return void
	 */
	public static function verify_capability( string $capability = 'manage_options' ): void {
		if ( ! current_user_can( $capability ) ) {
			wp_send_json_error(
				array(
					'message' => esc_html__( 'You do not have permission to perform this action.', 'cb-codetizer' ),
				),
				403
			);
		}
	}

	/**
	 * Recursively sanitize input data.
	 *
	 * Applies appropriate sanitization based on value type:
	 * - Strings: wp_kses_post
	 * - Integers: intval
	 * - Other scalars: sanitize_text_field
	 * - Arrays: recursive map
	 *
	 * @param mixed $data The input data to sanitize.
	 * @return mixed The sanitized data.
	 */
	public static function sanitize_input( mixed $data ): mixed {
		if ( is_array( $data ) ) {
			return array_map( array( __CLASS__, 'sanitize_input' ), $data );
		}

		if ( is_int( $data ) ) {
			return intval( $data );
		}

		if ( is_string( $data ) ) {
			return wp_kses_post( $data );
		}

		if ( is_numeric( $data ) ) {
			return sanitize_text_field( (string) $data );
		}

		return sanitize_text_field( (string) $data );
	}

	/**
	 * Sanitize raw code input for safe processing.
	 *
	 * Strips null bytes, normalizes line endings to \n,
	 * and trims whitespace from both ends.
	 *
	 * @param string $code The raw code string.
	 * @return string The sanitized code string.
	 */
	public static function sanitize_code_input( string $code ): string {
		// Remove null bytes.
		$code = str_replace( "\0", '', $code );

		// Normalize line endings: \r\n -> \n, \r -> \n.
		$code = str_replace( array( "\r\n", "\r" ), "\n", $code );

		// Trim leading/trailing whitespace.
		$code = trim( $code );

		return $code;
	}

	/**
	 * Default allowed upload extensions.
	 *
	 * PHP upload types (php, phtml, phar, pht, php5, php7, php8) are
	 * deliberately excluded: a security-inspection plugin should not
	 * accept executable uploads by default. Trusted administrators can
	 * re-enable them via the cb_codetizer_allowed_extensions filter.
	 */
	const DEFAULT_ALLOWED_EXTENSIONS = array(
		'html', 'htm', 'svg', 'css', 'js',
		'json', 'xml', 'md', 'txt',
	);

	/**
	 * Map of allowed extension → expected MIME type prefix(es).
	 *
	 * The actual MIME returned by finfo is compared (case-insensitively,
	 * prefix match) against the values listed here. A prefix match is used
	 * because finfo may return charset suffixes (e.g. "text/plain; charset=utf-8"
	 * is normalized by PHP to "text/plain" already, but some builds report
	 * "text/html" for .svg which we accept).
	 */
	const EXTENSION_MIME_MAP = array(
		'html' => array( 'text/html', 'text/plain' ),
		'htm'  => array( 'text/html', 'text/plain' ),
		'svg'  => array( 'image/svg+xml', 'text/svg+xml', 'text/xml', 'application/xml', 'text/plain' ),
		'css'  => array( 'text/css', 'text/plain' ),
		'js'   => array( 'text/javascript', 'application/javascript', 'application/x-javascript', 'text/plain' ),
		'json' => array( 'application/json', 'text/json', 'text/plain' ),
		'xml'  => array( 'text/xml', 'application/xml', 'text/plain' ),
		'md'   => array( 'text/markdown', 'text/x-markdown', 'text/plain' ),
		'txt'  => array( 'text/plain' ),
	);

	/**
	 * Validate an uploaded file.
	 *
	 * Checks that the file was actually uploaded, is not empty, is within
	 * the configured maximum upload size, has an allowed file extension,
	 * and — when the fileinfo extension is available — that the detected
	 * MIME type is consistent with the claimed extension.
	 *
	 * @param array $file The file entry from the $_FILES superglobal.
	 * @return string|WP_Error The sanitized file path on success, WP_Error on failure.
	 */
	public static function check_file_upload( array $file ): string|WP_Error {
		// Verify the file was uploaded via HTTP POST.
		if ( ! isset( $file['tmp_name'] ) || ! is_uploaded_file( $file['tmp_name'] ) ) {
			return new WP_Error(
				'invalid_upload',
				esc_html__( 'No file was uploaded or the upload was intercepted.', 'cb-codetizer' )
			);
		}

		// Check for upload errors.
		if ( isset( $file['error'] ) && UPLOAD_ERR_OK !== $file['error'] ) {
			$upload_errors = array(
				UPLOAD_ERR_INI_SIZE   => esc_html__( 'The uploaded file exceeds the upload_max_filesize directive in php.ini.', 'cb-codetizer' ),
				UPLOAD_ERR_FORM_SIZE  => esc_html__( 'The uploaded file exceeds the MAX_FILE_SIZE directive specified in the HTML form.', 'cb-codetizer' ),
				UPLOAD_ERR_PARTIAL    => esc_html__( 'The uploaded file was only partially uploaded.', 'cb-codetizer' ),
				UPLOAD_ERR_NO_FILE    => esc_html__( 'No file was uploaded.', 'cb-codetizer' ),
				UPLOAD_ERR_NO_TMP_DIR => esc_html__( 'Missing a temporary folder.', 'cb-codetizer' ),
				UPLOAD_ERR_CANT_WRITE => esc_html__( 'Failed to write file to disk.', 'cb-codetizer' ),
				UPLOAD_ERR_EXTENSION  => esc_html__( 'A PHP extension stopped the file upload.', 'cb-codetizer' ),
			);
			$error_message = $upload_errors[ $file['error'] ] ?? esc_html__( 'An unknown upload error occurred.', 'cb-codetizer' );

			return new WP_Error( 'upload_error', $error_message );
		}

		// Check file size against plugin setting.
		$max_size   = (int) get_option( 'cb_codetizer_max_upload_size', 2097152 );
		$file_size  = filesize( $file['tmp_name'] );

		if ( false === $file_size || $file_size > $max_size ) {
			$max_readable = size_format( $max_size );
			return new WP_Error(
				'file_too_large',
				sprintf(
					/* translators: %s: Maximum allowed file size */
					esc_html__( 'The uploaded file exceeds the maximum allowed size of %s.', 'cb-codetizer' ),
					esc_html( $max_readable )
				)
			);
		}

		// Check for empty file.
		if ( 0 === $file_size ) {
			return new WP_Error(
				'file_empty',
				esc_html__( 'The uploaded file is empty.', 'cb-codetizer' )
			);
		}

		// Validate file extension. The list is filterable so trusted
		// administrators can re-enable types (e.g. .php) if needed.
		$allowed_extensions = self::get_allowed_extensions();

		$file_info      = wp_check_filetype( $file['name'] );
		$file_extension = strtolower( $file_info['ext'] ?? '' );

		if ( empty( $file_extension ) || ! in_array( $file_extension, $allowed_extensions, true ) ) {
			$allowed_list = implode( ', ', array_map( 'strtoupper', $allowed_extensions ) );
			return new WP_Error(
				'invalid_extension',
				sprintf(
					/* translators: %s: Comma-separated list of allowed extensions */
					esc_html__( 'File type not allowed. Supported extensions: %s.', 'cb-codetizer' ),
					esc_html( $allowed_list )
				)
			);
		}

		// MIME verification. When ext-fileinfo is available, confirm
		// that the server-detected MIME of the actual file content is
		// consistent with the claimed extension. This catches renamed
		// executables and polyglot files. If fileinfo is unavailable
		// (rare), we fall back to extension-only validation.
		$detected_mime = self::detect_mime( $file['tmp_name'] );
		if ( null !== $detected_mime ) {
			$expected_mimes = self::EXTENSION_MIME_MAP[ $file_extension ] ?? null;
			if ( is_array( $expected_mimes ) && ! self::mime_matches( $detected_mime, $expected_mimes ) ) {
				return new WP_Error(
					'mime_mismatch',
					sprintf(
						/* translators: 1: Claimed extension, 2: Detected MIME type */
						esc_html__( 'The uploaded file claims to be .%1$s but its content was detected as %2$s. This may be a disguised file.', 'cb-codetizer' ),
						esc_html( $file_extension ),
						esc_html( $detected_mime )
					)
				);
			}
		}

		// Validate the temporary file path is real and resolve symlinks.
		// This is defense-in-depth: tmp_name comes from PHP's upload handler
		// and should already be safe, but realpath() ensures the path resolves
		// to an actual file (not a symlink to elsewhere) and normalizes it.
		$real_path = realpath( $file['tmp_name'] );
		if ( false === $real_path || ! is_file( $real_path ) || ! is_readable( $real_path ) ) {
			return new WP_Error(
				'invalid_temp_file',
				esc_html__( 'The uploaded file could not be located on the server.', 'cb-codetizer' )
			);
		}

		// Sanitize and return the resolved real path.
		return sanitize_file_path( $real_path );
	}

	/**
	 * Get the list of allowed upload extensions, filterable.
	 *
	 * @return string[] Lowercased extension list without leading dots.
	 */
	public static function get_allowed_extensions(): array {
		$defaults = self::DEFAULT_ALLOWED_EXTENSIONS;
		$filtered = apply_filters( 'cb_codetizer_allowed_extensions', $defaults );

		if ( ! is_array( $filtered ) ) {
			return $defaults;
		}

		$clean = array();
		foreach ( $filtered as $ext ) {
			if ( ! is_string( $ext ) ) {
				continue;
			}
			$clean_ext = ltrim( strtolower( trim( $ext ) ), '.' );
			if ( '' !== $clean_ext ) {
				$clean[] = $clean_ext;
			}
		}

		return $clean;
	}

	/**
	 * Detect the MIME type of a file using ext-fileinfo.
	 *
	 * @param string $path Absolute path to the file.
	 * @return string|null MIME type string, or null if fileinfo is unavailable or fails.
	 */
	private static function detect_mime( string $path ): ?string {
		if ( ! function_exists( 'finfo_open' ) ) {
			return null;
		}

		$finfo = finfo_open( FILEINFO_MIME_TYPE );
		if ( false === $finfo ) {
			return null;
		}

		$mime = finfo_file( $finfo, $path );
		finfo_close( $finfo );

		return ( is_string( $mime ) && '' !== $mime ) ? strtolower( trim( $mime ) ) : null;
	}

	/**
	 * Check whether a detected MIME matches any of the expected MIME prefixes.
	 *
	 * @param string   $detected  Lowercased detected MIME.
	 * @param string[] $expected  Lowercased expected MIME prefixes.
	 * @return bool True if the detected MIME starts with any expected prefix.
	 */
	private static function mime_matches( string $detected, array $expected ): bool {
		foreach ( $expected as $want ) {
			if ( str_starts_with( $detected, strtolower( $want ) ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Escape output for safe HTML display.
	 *
	 * Applies esc_html() to strings and recursively maps
	 * over arrays to escape each element.
	 *
	 * @param mixed $data The data to escape.
	 * @return mixed The escaped data.
	 */
	public static function escape_output( mixed $data ): mixed {
		if ( is_array( $data ) ) {
			return array_map( array( __CLASS__, 'escape_output' ), $data );
		}

		if ( is_string( $data ) ) {
			return esc_html( $data );
		}

		return $data;
	}

	/**
	 * Validate a language identifier against the supported list.
	 *
	 * Delegates to CB_Codetizer_Helpers::get_supported_languages() — the
	 * single source of truth for which languages the plugin supports —
	 * so this can never drift out of sync with the display layer.
	 *
	 * @param string $lang The language identifier to validate.
	 * @return string The validated language identifier, or 'html' as default.
	 */
	public static function validate_language( string $lang ): string {
		$supported = array_keys( CB_Codetizer_Helpers::get_supported_languages() );

		$sanitized = strtolower( sanitize_text_field( $lang ) );

		return in_array( $sanitized, $supported, true ) ? $sanitized : 'html';
	}

	/**
	 * Resolve the effective scan profile for Inspector calls.
	 *
	 * Reads the cb_codetizer_scan_profile option (validated on save by
	 * CB_Codetizer_Settings::sanitize_scan_profile() to one of 'standard',
	 * 'strict', 'custom') and resolves it to a value the Inspector engine
	 * / Pattern Repository actually know how to act on.
	 *
	 * IMPORTANT: 'custom' is intentionally resolved to 'standard' here.
	 * The settings UI offers "Custom" as a scan-profile option, but no
	 * rule in the Pattern Repository is currently tagged for a 'custom'
	 * profile — a genuine custom-rule builder is out of scope for this
	 * phase. Passing 'custom' straight through to
	 * CB_Codetizer_Pattern_Repository::get_rules_for_language() would
	 * currently still resolve safely to the standard rule set there too
	 * (its profile check only special-cases 'strict'), but resolving it
	 * explicitly here — rather than relying on that incidental fallback —
	 * makes the behavior a documented decision instead of an implicit
	 * side effect, and protects against a future change to the
	 * Repository's matching logic silently reintroducing a
	 * zero-rules-matched gap for anyone who has "Custom" selected.
	 *
	 * @return string Either 'standard' or 'strict'.
	 */
	public static function resolve_scan_profile(): string {
		$stored = strtolower( (string) get_option( 'cb_codetizer_scan_profile', 'standard' ) );

		return 'strict' === $stored ? 'strict' : 'standard';
	}

	/**
	 * Assert that a string input does not exceed the maximum allowed size.
	 *
	 * The limit defaults to the cb_codetizer_max_input_bytes option (or
	 * 5 MB if unset), and is filterable via cb_codetizer_max_input_bytes.
	 * Returns a WP_Error when the input exceeds the limit, or null when
	 * the input is within bounds. Callers are responsible for handling
	 * the WP_Error (typically by forwarding it to wp_send_json_error()).
	 *
	 * @param string    $code      The raw input string to check.
	 * @param int|null  $max_bytes Optional explicit limit in bytes. Falls back to the option/filter value.
	 * @return WP_Error|null WP_Error with code 'input_too_large' on overflow, null otherwise.
	 */
	public static function assert_size_limit( string $code, ?int $max_bytes = null ): ?WP_Error {
		if ( null === $max_bytes ) {
			$max_bytes = (int) apply_filters( 'cb_codetizer_max_input_bytes', (int) get_option( 'cb_codetizer_max_input_bytes', 5242880 ) );
		}

		if ( $max_bytes <= 0 ) {
			return null;
		}

		$length = strlen( $code );
		if ( $length > $max_bytes ) {
			$max_readable = size_format( $max_bytes );
			return new WP_Error(
				'input_too_large',
				sprintf(
					/* translators: 1: Supplied input size, 2: Maximum allowed size */
					esc_html__( 'The supplied input is %1$s which exceeds the maximum allowed size of %2$s.', 'cb-codetizer' ),
					esc_html( size_format( $length ) ),
					esc_html( false === $max_readable ? (string) $max_bytes : $max_readable )
				)
			);
		}

		return null;
	}

	/**
	 * Check and enforce a per-user, per-action rate limit.
	 *
	 * Uses a WordPress transient as a sliding-window counter keyed by the
	 * current user ID and the action name. When the limit is exceeded a
	 * WP_Error is returned (callers typically forward it to
	 * wp_send_json_error() with a 429 status). When the limit is not yet
	 * reached the counter is incremented and null is returned.
	 *
	 * @param string $action         A short identifier for the action being limited (e.g. 'inspect').
	 * @param int    $max_per_minute Maximum calls per minute. Default 60.
	 * @return WP_Error|null WP_Error with code 'rate_limited' when the limit is exceeded, null otherwise.
	 */
	public static function check_rate_limit( string $action, int $max_per_minute = 60 ): ?WP_Error {
		$user_id = get_current_user_id();
		$key     = 'cb_codetizer_rl_' . $action . '_' . $user_id;
		$now     = time();
		$window  = 60;

		$bucket = get_transient( $key );
		if ( ! is_array( $bucket ) ) {
			$bucket = array();
		}

		// Drop entries older than the window.
		$bucket = array_values(
			array_filter(
				$bucket,
				static function ( $timestamp ) use ( $now, $window ) {
					return is_int( $timestamp ) && ( $now - $timestamp ) < $window;
				}
			)
		);

		if ( count( $bucket ) >= $max_per_minute ) {
			$oldest   = $bucket ? min( $bucket ) : $now;
			$retry_in = max( 1, $window - ( $now - $oldest ) );
			return new WP_Error(
				'rate_limited',
				sprintf(
					/* translators: %d: Seconds until the rate limit resets */
					esc_html__( 'Rate limit exceeded for this action. Please try again in %d seconds.', 'cb-codetizer' ),
					$retry_in
				),
				array( 'retry_after' => $retry_in )
			);
		}

		$bucket[] = $now;
		set_transient( $key, $bucket, $window );

		return null;
	}

	/**
	 * Create a DOMDocument configured for safe loading of untrusted XML/SVG/HTML.
	 *
	 * This helper centralizes the libxml configuration needed to prevent
	 * XXE (XML External Entity) attacks when parsing user-supplied markup.
	 * All DOMDocument usage in the plugin (Beautifier, Sanitizer, future
	 * Elementor integration) MUST go through this helper.
	 *
	 * Protections applied:
	 *   - LIBXML_NONET: disables network access for both loading and saving,
	 *     preventing external entity fetching over HTTP/HTTPS.
	 *   - libxml_use_internal_errors(true): suppresses PHP warnings, errors
	 *     are collected internally and can be retrieved via libxml_get_errors().
	 *   - On PHP 8.0+ with libxml 2.9+, external entity loading is disabled
	 *     by default (libxml_disable_entity_loader() is deprecated/no-op).
	 *
	 * What is NOT applied (intentionally):
	 *   - LIBXML_DTDLOAD: would allow loading external DTDs — NOT set.
	 *   - LIBXML_NOENT: would enable entity substitution — NOT set, because
	 *     we want to preserve entity references as text, not expand them.
	 *   - LIBXML_DTDATTR: would load default DTD attributes — NOT set.
	 *
	 * @return DOMDocument A configured DOMDocument instance. The caller is
	 *                      responsible for calling loadXML/loadHTML with
	 *                      LIBXML_NONET in the $options argument.
	 */
	public static function create_safe_domdocument(): DOMDocument {
		$dom = new DOMDocument( '1.0', 'UTF-8' );
		$dom->strictErrorChecking = true;
		$dom->validateOnParse     = false;
		$dom->resolveExternals    = false;
		$dom->preserveWhiteSpace  = false;
		return $dom;
	}

	/**
	 * Get the libxml options bitmask for safe XML loading.
	 *
	 * Callers should pass this as the $options argument to DOMDocument::loadXML().
	 *
	 * @return int The libxml options bitmask (LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING).
	 */
	public static function safe_xml_options(): int {
		return LIBXML_NONET | LIBXML_NOERROR | LIBXML_NOWARNING;
	}

	/**
	 * Check whether a string contains XML entity/DOCTYPE declarations
	 * that could be used for XXE attacks.
	 *
	 * This is a defense-in-depth check used before DOM parsing. Even
	 * though create_safe_domdocument() + safe_xml_options() prevent
	 * entity expansion, we reject DOCTYPE/ENTITY declarations outright
	 * so they never reach the parser. This also produces a clearer
	 * error message for the user.
	 *
	 * @param string $code The XML/SVG/HTML code to check.
	 * @return bool True if a DOCTYPE or ENTITY declaration is found.
	 */
	public static function contains_dangerous_xml_declarations( string $code ): bool {
		if ( preg_match( '/<!\s*DOCTYPE\b/i', $code ) ) {
			return true;
		}
		if ( preg_match( '/<!\s*ENTITY\b/i', $code ) ) {
			return true;
		}
		return false;
	}
	/**
	 * Keys that cause prototype pollution in JavaScript.
	 *
	 * Used by sanitize_json_structurally() to strip these keys at any depth.
	 * The check is performed AFTER json_decode(), so Unicode-escaped
	 * variants like "\u005f\u005fproto\u005f\u005f" are decoded to the
	 * literal string "__proto__" and then matched.
	 */
	const PROTOTYPE_POLLUTION_KEYS = array( '__proto__', 'constructor', 'prototype' );

	/**
	 * Structurally sanitize a JSON string by removing prototype-pollution keys.
	 *
	 * This is the correct way to sanitize JSON: decode it, walk the decoded
	 * structure, and remove dangerous keys at any depth. This handles
	 * Unicode-escaped variants (e.g., "\u005f\u005fproto\u005f\u005f")
	 * that regex-only sanitizers miss, because json_decode() resolves the
	 * escapes to their literal characters before we inspect the keys.
	 *
	 * @param string $json The raw JSON string.
	 * @return array{ sanitized: string, removed: array } Sanitized JSON string and list of removed keys.
	 */
	public static function sanitize_json_structurally( string $json ): array {
		$removed = array();

		if ( '' === trim( $json ) ) {
			return array( 'sanitized' => $json, 'removed' => $removed );
		}

		$decoded = json_decode( $json, true, 512, JSON_BIGINT_AS_STRING );

		if ( null === $decoded && JSON_ERROR_NONE !== json_last_error() ) {
			// Invalid JSON — return unchanged.
			return array( 'sanitized' => $json, 'removed' => $removed );
		}

		$cleaned = self::remove_prototype_keys_recursive( $decoded, $removed );

		$encoded = wp_json_encode( $cleaned, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRESERVE_ZERO_FRACTION );

		if ( false === $encoded ) {
			return array( 'sanitized' => $json, 'removed' => $removed );
		}

		return array( 'sanitized' => $encoded, 'removed' => $removed );
	}

	/**
	 * Recursively remove __proto__/constructor/prototype keys from a decoded JSON structure.
	 *
	 * @param mixed $data    The decoded JSON data (array, object, or scalar).
	 * @param array $removed Removed-items log (passed by reference).
	 * @return mixed The cleaned data.
	 */
	private static function remove_prototype_keys_recursive( mixed $data, array &$removed ): mixed {
		if ( is_array( $data ) ) {
			$clean = array();
			foreach ( $data as $key => $value ) {
				// Check string keys against the prototype-pollution list.
				if ( is_string( $key ) && in_array( $key, self::PROTOTYPE_POLLUTION_KEYS, true ) ) {
					$removed[] = array(
						'type'    => 'json_prototype_key',
						'content' => esc_html( CB_Codetizer_Helpers::truncate( (string) $key, 200 ) ),
						'line'    => 0,
						'reason'  => sprintf(
							/* translators: %s: Key name */
							esc_html__( 'Removed prototype-pollution key: %s.', 'cb-codetizer' ),
							esc_html( (string) $key )
						),
					);
					continue;
				}
				$clean[ $key ] = self::remove_prototype_keys_recursive( $value, $removed );
			}
			return $clean;
		}

		return $data;
	}

}
