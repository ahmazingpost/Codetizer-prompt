<?php
/**
 * CB CODETIZER - Installer
 *
 * Handles plugin activation tasks: creating database tables
 * and setting default configuration options.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CB_Codetizer_Installer
 *
 * Manages the installation process including database table creation
 * and default option seeding.
 */
class CB_Codetizer_Installer {

	/**
	 * Plugin activation callback.
	 *
	 * Creates the required database tables and sets default options.
	 * Existing options are never overwritten.
	 *
	 * @return void
	 */
	public static function activate(): void {
		self::create_tables();
		self::set_default_options();
	}

	/**
	 * Create the custom database table for scan reports.
	 *
	 * Uses dbDelta() for safe, incremental schema updates.
	 * Running activate() again on an existing install is safe —
	 * dbDelta adds only the missing columns/indexes.
	 *
	 * @return void
	 */
	private static function create_tables(): void {
		global $wpdb;

		$table_name      = $wpdb->prefix . 'cb_codetizer_reports';
		$charset_collate = $wpdb->get_charset_collate();

		// NOTE: score column added in v1.0.0 to persist security scores per report.
		$sql = "CREATE TABLE {$table_name} (
id               bigint(20)   NOT NULL AUTO_INCREMENT,
scan_type        varchar(20)  NOT NULL,
language         varchar(20)  NOT NULL DEFAULT 'html',
input_summary    text         NOT NULL,
output_summary   text         DEFAULT NULL,
results          longtext     DEFAULT NULL,
threats_found    int(11)      NOT NULL DEFAULT 0,
severity_summary varchar(255) DEFAULT NULL,
score            smallint(3)  NOT NULL DEFAULT 100,
created_at       datetime     NOT NULL DEFAULT CURRENT_TIMESTAMP,
user_id          bigint(20)   NOT NULL DEFAULT 0,
PRIMARY KEY  (id),
KEY scan_type (scan_type),
KEY language (language),
KEY created_at (created_at),
KEY user_id (user_id)
) {$charset_collate};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );

		update_option( 'cb_codetizer_db_version', CB_CODETIZER_VERSION );
	}

	/**
	 * Set default plugin options.
	 *
	 * Uses add_option() which does not overwrite existing values,
	 * ensuring user customizations are preserved on reactivation.
	 *
	 * @return void
	 */
	private static function set_default_options(): void {
		$defaults = array(
			'cb_codetizer_max_upload_size' => 2097152,
			'cb_codetizer_max_input_bytes'  => 5242880,
			'cb_codetizer_default_language' => 'html',
			'cb_codetizer_scan_profile'     => 'standard',
			'cb_codetizer_indent_size'      => 4,
			'cb_codetizer_indent_type'      => 'spaces',
			'cb_codetizer_db_version'       => CB_CODETIZER_VERSION,
		);

		foreach ( $defaults as $option_name => $default_value ) {
			add_option( $option_name, $default_value );
		}

		// Set a transient to signal that the plugin was just activated.
		set_transient( 'cb_codetizer_activated', 1, 30 );
	}

	/**
	 * Run any database upgrades needed between versions.
	 *
	 * Called on every page load when the stored DB version differs from
	 * the current plugin version. Safe to call repeatedly.
	 *
	 * @return void
	 */
	public static function maybe_upgrade(): void {
		$stored_version = get_option( 'cb_codetizer_db_version', '0' );

		if ( version_compare( $stored_version, CB_CODETIZER_VERSION, '<' ) ) {
			// Re-running create_tables() via dbDelta() handles schema additions safely.
			self::create_tables();
		}
	}
}
