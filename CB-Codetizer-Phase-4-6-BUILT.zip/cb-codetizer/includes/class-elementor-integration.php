<?php
/**
 * CB CODETIZER - Elementor Integration.
 *
 * Provides Elementor availability, JSON sanitization, and explicit JS Arena
 * synchronization. No automatic destructive save hook is used.
 *
 * @package CB_Codetizer
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class CB_Codetizer_Elementor_Integration {
    private CB_Codetizer_Backups $backups;

    public function __construct( CB_Codetizer_Backups $backups ) {
        $this->backups = $backups;
        add_action( 'elementor/widgets/register', array( $this, 'register_widget' ) );
    }

    public function available(): bool {
        return did_action( 'elementor/loaded' ) > 0 || class_exists( '\Elementor\Plugin' );
    }

    public function sanitize_post( int $post_id, bool $persist = false ): array|WP_Error {
        if ( ! $this->available() ) { return new WP_Error( 'elementor_unavailable', __( 'Elementor is not loaded on this site.', 'cb-codetizer' ) ); }
        $raw = get_post_meta( $post_id, '_elementor_data', true );
        if ( ! is_string( $raw ) || '' === trim( $raw ) ) { return new WP_Error( 'elementor_data_missing', __( 'No Elementor JSON content was found for this post.', 'cb-codetizer' ) ); }
        $decoded = json_decode( $raw, true );
        if ( ! is_array( $decoded ) ) { return new WP_Error( 'elementor_json_invalid', __( 'Elementor JSON could not be decoded.', 'cb-codetizer' ) ); }
        $backup_id = $this->backups->create( 'elementor', 'json', $raw, array( 'post_id' => $post_id, 'meta_key' => '_elementor_data' ) );
        if ( false === $backup_id ) { return new WP_Error( 'backup_failed', __( 'Elementor sanitization was stopped because the backup could not be created.', 'cb-codetizer' ) ); }
        $stats = array( 'fields_changed' => 0, 'removed_items' => array() );
        $sanitized = $this->walk( $decoded, $stats );
        $json = wp_json_encode( $sanitized, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
        if ( false === $json ) { return new WP_Error( 'elementor_json_encode_failed', __( 'Sanitized Elementor data could not be encoded.', 'cb-codetizer' ) ); }
        if ( $persist && $json !== $raw ) { update_post_meta( $post_id, '_elementor_data', wp_slash( $json ) ); }
        return array( 'post_id' => $post_id, 'backup_id' => $backup_id, 'changed' => $json !== $raw, 'sanitized_json' => $json, 'stats' => $stats, 'persisted' => $persist && $json !== $raw );
    }

    /** Apply a JS Arena item to Elementor, explicitly and with a backup. */
    public function apply_arena_item( int $post_id, array $item, bool $persist = true ): array|WP_Error {
        if ( ! $this->available() ) { return new WP_Error( 'elementor_unavailable', __( 'Elementor is not loaded on this site.', 'cb-codetizer' ) ); }
        $raw = get_post_meta( $post_id, '_elementor_data', true );
        if ( ! is_string( $raw ) || '' === trim( $raw ) ) { return new WP_Error( 'elementor_data_missing', __( 'This page has no Elementor data yet. Open it once in Elementor and save it, then sync again.', 'cb-codetizer' ) ); }
        $data = json_decode( $raw, true );
        if ( ! is_array( $data ) ) { return new WP_Error( 'elementor_json_invalid', __( 'Elementor JSON could not be decoded.', 'cb-codetizer' ) ); }

        $backup_id = $this->backups->create( 'elementor-arena', 'json', $raw, array( 'post_id' => $post_id, 'item_id' => (int) ( $item['id'] ?? 0 ), 'meta_key' => '_elementor_data' ) );
        if ( false === $backup_id ) { return new WP_Error( 'backup_failed', __( 'Elementor sync was stopped because the backup could not be created.', 'cb-codetizer' ) ); }

        $html = (string) ( $item['html'] ?? '' );
        $css = (string) ( $item['css'] ?? '' );
        $js = (string) ( $item['javascript'] ?? '' );
        $html_widget = $this->make_html_widget( $html, 'html' );
        $css_widget = $this->make_html_widget( $css !== '' ? '<style>' . $this->strip_style_tags( $css ) . '</style>' : '', 'css' );
        $js_widget = $this->make_html_widget( $js !== '' ? '<script>' . $this->strip_script_tags( $js ) . '</script>' : '', 'javascript' );

        $added = 0;
        $data = $this->append_to_sections( $data, array( $html_widget, $css_widget, $js_widget ), $added );
        if ( 0 === $added ) { return new WP_Error( 'elementor_no_target', __( 'No Elementor section/container target was found on this page.', 'cb-codetizer' ) ); }
        $json = wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
        if ( false === $json ) { return new WP_Error( 'elementor_json_encode_failed', __( 'Updated Elementor data could not be encoded.', 'cb-codetizer' ) ); }
        if ( $persist ) {
            update_post_meta( $post_id, '_elementor_data', wp_slash( $json ) );
            update_post_meta( $post_id, '_cb_codetizer_last_arena_sync', current_time( 'mysql' ) );
        }
        return array( 'post_id' => $post_id, 'item_id' => (int) ( $item['id'] ?? 0 ), 'backup_id' => $backup_id, 'sections_updated' => $added, 'persisted' => $persist );
    }

    /** Ensure every Elementor section/container has two default Codetizer HTML widgets. */
    public function ensure_default_containers( int $post_id, bool $persist = true ): array|WP_Error {
        if ( ! $this->available() ) { return new WP_Error( 'elementor_unavailable', __( 'Elementor is not loaded.', 'cb-codetizer' ) ); }
        $raw = get_post_meta( $post_id, '_elementor_data', true );
        $data = is_string( $raw ) ? json_decode( $raw, true ) : null;
        if ( ! is_array( $data ) ) { return new WP_Error( 'elementor_data_missing', __( 'No Elementor JSON data found.', 'cb-codetizer' ) ); }
        $backup_id = $this->backups->create( 'elementor-default-containers', 'json', $raw, array( 'post_id' => $post_id ) );
        if ( false === $backup_id ) { return new WP_Error( 'backup_failed', __( 'Could not create the Elementor backup.', 'cb-codetizer' ) ); }
        $added = 0;
        $data = $this->append_defaults_recursive( $data, $added );
        $json = wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
        if ( false === $json ) { return new WP_Error( 'elementor_json_encode_failed', __( 'Elementor data could not be encoded.', 'cb-codetizer' ) ); }
        if ( $persist && $json !== $raw ) { update_post_meta( $post_id, '_elementor_data', wp_slash( $json ) ); }
        return array( 'post_id' => $post_id, 'backup_id' => $backup_id, 'sections_updated' => $added, 'changed' => $json !== $raw );
    }

    public function is_elementor_page( int $post_id ): bool {
        return (bool) get_post_meta( $post_id, '_elementor_edit_mode', true ) || '' !== (string) get_post_meta( $post_id, '_elementor_data', true );
    }

    /** Return real Elementor nodes, including their existing IDs and hierarchy. */
    public function discover_elements( int $post_id ): array|WP_Error {
        if ( ! $this->available() ) { return new WP_Error( 'elementor_unavailable', __( 'Elementor is not loaded on this site.', 'cb-codetizer' ) ); }
        $raw = get_post_meta( $post_id, '_elementor_data', true );
        $data = is_string( $raw ) ? json_decode( $raw, true ) : null;
        if ( ! is_array( $data ) ) { return new WP_Error( 'elementor_data_missing', __( 'No Elementor data was found. Open and save the page in Elementor first.', 'cb-codetizer' ) ); }
        $out = array();
        $this->collect_elements( $data, $out, '' );
        return $out;
    }

    /** Apply named builder blocks only to the exact existing Elementor node IDs. */
    public function apply_page_builder_blocks( int $post_id, array $blocks ): array|WP_Error {
        if ( ! $this->available() ) { return new WP_Error( 'elementor_unavailable', __( 'Elementor is not loaded on this site.', 'cb-codetizer' ) ); }
        $raw = get_post_meta( $post_id, '_elementor_data', true );
        $data = is_string( $raw ) ? json_decode( $raw, true ) : null;
        if ( ! is_array( $data ) ) { return new WP_Error( 'elementor_data_missing', __( 'No Elementor data was found. Open and save the page in Elementor first.', 'cb-codetizer' ) ); }
        $backup_id = $this->backups->create( 'pages-builder', 'json', $raw, array( 'post_id' => $post_id, 'block_count' => count( $blocks ) ) );
        if ( false === $backup_id ) { return new WP_Error( 'backup_failed', __( 'Send to Elementor stopped because a backup could not be created.', 'cb-codetizer' ) ); }
        $wanted = array();
        foreach ( $blocks as $block ) {
            if ( ! is_array( $block ) || '' === (string) ( $block['element_id'] ?? '' ) ) { continue; }
            $wanted[ (string) $block['element_id'] ] = $block;
        }
        $updated = 0;
        $this->apply_blocks_recursive( $data, $wanted, $updated );
        if ( 0 === $updated && $wanted ) { return new WP_Error( 'elementor_targets_missing', __( 'None of the selected Elementor HTML elements still exist. Refresh the page builder and select the current elements.', 'cb-codetizer' ) ); }
        $json = wp_json_encode( $data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
        if ( false === $json ) { return new WP_Error( 'elementor_json_encode_failed', __( 'Updated Elementor data could not be encoded.', 'cb-codetizer' ) ); }
        update_post_meta( $post_id, '_elementor_data', wp_slash( $json ) );
        update_post_meta( $post_id, '_cb_codetizer_pages_builder_last_backup', $backup_id );
        return array( 'post_id' => $post_id, 'backup_id' => $backup_id, 'updated' => $updated, 'persisted' => true );
    }

    private function collect_elements( array $nodes, array &$out, string $parent_label ): void {
        foreach ( $nodes as $index => $node ) {
            if ( ! is_array( $node ) ) { continue; }
            $id = (string) ( $node['id'] ?? '' );
            $el_type = (string) ( $node['elType'] ?? '' );
            $widget_type = (string) ( $node['widgetType'] ?? '' );
            $label = $node['settings']['_title'] ?? $node['settings']['title'] ?? '';
            $label = is_string( $label ) ? $label : '';
            if ( '' === $label ) { $label = $widget_type ? ucfirst( $widget_type ) : ucfirst( $el_type ); }
            if ( '' !== $id && 'widget' === $el_type && 'html' === $widget_type ) {
                $out[] = array(
                    'id' => $id,
                    'elType' => 'widget',
                    'widgetType' => 'html',
                    'label' => $label,
                    'parent' => $parent_label,
                    'path_index' => $index,
                    'current_code' => (string) ( $node['settings']['htmlContent'] ?? '' ),
                );
            }
            if ( isset( $node['elements'] ) && is_array( $node['elements'] ) ) {
                $next_parent = $label . ( $id ? ' · ' . $id : '' );
                $this->collect_elements( $node['elements'], $out, $next_parent );
            }
        }
    }

    private function apply_blocks_recursive( array &$nodes, array $wanted, int &$updated ): void {
        foreach ( $nodes as &$node ) {
            if ( ! is_array( $node ) ) { continue; }
            $id = (string) ( $node['id'] ?? '' );
            if ( '' !== $id && isset( $wanted[ $id ] ) && 'widget' === (string) ( $node['elType'] ?? '' ) && 'html' === (string) ( $node['widgetType'] ?? '' ) ) {
                $block = $wanted[ $id ];
                $language = (string) ( $block['language'] ?? 'html' );
                $code = (string) ( $block['code'] ?? '' );
                $node['settings']['htmlContent'] = $this->builder_code_to_html( $code, $language );
                $node['settings']['_cb_codetizer_block_name'] = sanitize_text_field( (string) ( $block['name'] ?? '' ) );
                $node['settings']['_cb_codetizer_language'] = sanitize_key( $language );
                $updated++;
            }
            if ( isset( $node['elements'] ) && is_array( $node['elements'] ) ) { $this->apply_blocks_recursive( $node['elements'], $wanted, $updated ); }
        }
    }

    private function builder_code_to_html( string $code, string $language ): string {
        if ( 'css' === $language ) { return '<style>\n' . $this->strip_style_tags( $code ) . '\n</style>'; }
        if ( 'javascript' === $language ) { return '<script>\n' . $this->strip_script_tags( $code ) . '\n</script>'; }
        return $code;
    }

    public function register_widget( $widgets_manager ): void {
        if ( ! class_exists( 'CB_Codetizer_Elementor_Widget' ) ) {
            require_once CB_CODETIZER_PATH . 'includes/class-elementor-widget.php';
        }
        if ( class_exists( 'CB_Codetizer_Elementor_Widget' ) ) { $widgets_manager->register( new CB_Codetizer_Elementor_Widget() ); }
    }

    private function make_html_widget( string $content, string $role ): array {
        return array(
            'id' => function_exists( 'wp_unique_id' ) ? wp_unique_id( 'cbcodetizer_' ) : substr( md5( uniqid( '', true ) ), 0, 7 ),
            'elType' => 'widget',
            'isInner' => false,
            'widgetType' => 'html',
            'settings' => array( 'htmlContent' => $content, '_cb_codetizer_role' => $role ),
            'elements' => array(),
        );
    }

    private function append_to_sections( array $nodes, array $widgets, int &$added ): array {
        foreach ( $nodes as &$node ) {
            if ( ! is_array( $node ) ) { continue; }
            $type = (string) ( $node['elType'] ?? '' );
            if ( in_array( $type, array( 'section', 'container' ), true ) ) {
                $target_index = $this->first_content_child_index( $node['elements'] ?? array() );
                if ( null !== $target_index ) {
                    $children = $node['elements'][ $target_index ]['elements'] ?? array();
                    if ( ! is_array( $children ) ) { $children = array(); }
                    foreach ( $widgets as $widget ) {
                        $role = $widget['settings']['_cb_codetizer_role'];
                        if ( $this->has_role( $children, $role ) ) { continue; }
                        $children[] = $widget;
                    }
                    $node['elements'][ $target_index ]['elements'] = $children;
                    $added++;
                }
            }
            if ( isset( $node['elements'] ) && is_array( $node['elements'] ) ) { $node['elements'] = $this->append_to_sections( $node['elements'], $widgets, $added ); }
        }
        return $nodes;
    }

    private function append_defaults_recursive( array $nodes, int &$added ): array {
        foreach ( $nodes as &$node ) {
            if ( ! is_array( $node ) ) { continue; }
            $type = (string) ( $node['elType'] ?? '' );
            if ( in_array( $type, array( 'section', 'container' ), true ) ) {
                $idx = $this->first_content_child_index( $node['elements'] ?? array() );
                if ( null !== $idx ) {
                    $children = $node['elements'][ $idx ]['elements'] ?? array();
                    if ( ! is_array( $children ) ) { $children = array(); }
                    $roles = array(); foreach ( $children as $child ) { $roles[] = $child['settings']['_cb_codetizer_role'] ?? ''; }
                    if ( ! in_array( 'html-default', $roles, true ) ) { $children[] = $this->make_html_widget( '', 'html-default' ); $added++; }
                    if ( ! in_array( 'css-default', $roles, true ) ) { $children[] = $this->make_html_widget( '<style></style>', 'css-default' ); $added++; }
                    $node['elements'][ $idx ]['elements'] = $children;
                }
            }
            if ( isset( $node['elements'] ) && is_array( $node['elements'] ) ) { $node['elements'] = $this->append_defaults_recursive( $node['elements'], $added ); }
        }
        return $nodes;
    }

    private function first_content_child_index( array $elements ): ?int {
        foreach ( $elements as $i => $element ) {
            if ( is_array( $element ) && in_array( (string) ( $element['elType'] ?? '' ), array( 'column', 'container' ), true ) ) { return $i; }
        }
        return null;
    }

    private function has_role( array $children, string $role ): bool {
        foreach ( $children as $child ) { if ( is_array( $child ) && (string) ( $child['settings']['_cb_codetizer_role'] ?? '' ) === $role ) { return true; } }
        return false;
    }

    private function walk( mixed $value, array &$stats, string $key = '' ): mixed {
        if ( is_array( $value ) ) { foreach ( $value as $k => $v ) { $value[ $k ] = $this->walk( $v, $stats, (string) $k ); } return $value; }
        if ( ! is_string( $value ) || ! preg_match( '/^(html|css|custom_css|javascript|js)$/i', $key ) ) { return $value; }
        $language = preg_match( '/css/i', $key ) ? 'css' : ( preg_match( '/java|js/i', $key ) ? 'javascript' : 'html' );
        $result = CB_Codetizer_Services::sanitizer()->sanitize( $value, $language );
        $clean = $result['sanitized_code'] ?? $value;
        if ( $clean !== $value ) { $stats['fields_changed']++; $stats['removed_items'] = array_merge( $stats['removed_items'], $result['removed_items'] ?? array() ); }
        return $clean;
    }

    private function strip_style_tags( string $css ): string { return preg_replace( '/<\/?style[^>]*>/i', '', $css ) ?? ''; }
    private function strip_script_tags( string $js ): string { return preg_replace( '/<\/?script[^>]*>/i', '', $js ) ?? ''; }
}
