<?php
/**
 * CB CODETIZER - Admin
 *
 * Registers the admin menu pages and handles rendering for every
 * plugin screen by delegating to template files.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CB_Codetizer_Admin
 *
 * Sets up the WordPress admin menu entries (main page + 6 subpages)
 * and dispatches page rendering to the appropriate template.
 */
class CB_Codetizer_Admin {

	/**
	 * Map of menu slugs to template file names (without .php).
	 *
	 * @var array<string, string>
	 */
	private array $page_templates = array(
		'cb-codetizer'          => 'dashboard',
		'cb-codetizer-inspector' => 'inspector',
		'cb-codetizer-sanitizer' => 'sanitizer',
		'cb-codetizer-beautifier'=> 'beautifier',
		'cb-codetizer-reports'   => 'reports',
		'cb-codetizer-settings'  => 'settings',
		'cb-codetizer-about'     => 'about',
		'cb-codetizer-js-arena'  => 'js-arena',
		'cb-codetizer-pages-builder' => 'pages-builder',
	);

	/**
	 * Constructor.
	 *
	 * Hooks into WordPress to register the admin menu and to handle
	 * the post-activation redirect.
	 */
	public function __construct() {
		add_action( 'admin_menu', array( $this, 'register_menus' ) );
		add_action( 'admin_init', array( $this, 'handle_activation_redirect' ) );
	}

	/**
	 * Register all admin menu pages.
	 *
	 * Creates the main top-level page and six sub-pages using
	 * the exact slugs required by the plugin.
	 *
	 * @return void
	 */
	public function register_menus(): void {
		// Main dashboard page.
		add_menu_page(
			esc_html__( 'CB Codetizer', 'cb-codetizer' ),
			esc_html__( 'CB Codetizer', 'cb-codetizer' ),
			'manage_options',
			'cb-codetizer',
			function () {
				$this->render_page( 'cb-codetizer' );
			},
			'dashicons-shield-alt',
			80
		);

		// Inspector sub-page.
		add_submenu_page(
			'cb-codetizer',
			esc_html__( 'Inspector', 'cb-codetizer' ),
			esc_html__( 'Inspector', 'cb-codetizer' ),
			'manage_options',
			'cb-codetizer-inspector',
			function () {
				$this->render_page( 'cb-codetizer-inspector' );
			}
		);

		// Sanitizer sub-page.
		add_submenu_page(
			'cb-codetizer',
			esc_html__( 'Sanitizer', 'cb-codetizer' ),
			esc_html__( 'Sanitizer', 'cb-codetizer' ),
			'manage_options',
			'cb-codetizer-sanitizer',
			function () {
				$this->render_page( 'cb-codetizer-sanitizer' );
			}
		);

		// Beautifier sub-page.
		add_submenu_page(
			'cb-codetizer',
			esc_html__( 'Beautifier', 'cb-codetizer' ),
			esc_html__( 'Beautifier', 'cb-codetizer' ),
			'manage_options',
			'cb-codetizer-beautifier',
			function () {
				$this->render_page( 'cb-codetizer-beautifier' );
			}
		);

		// Reports sub-page.
		add_submenu_page(
			'cb-codetizer',
			esc_html__( 'Reports', 'cb-codetizer' ),
			esc_html__( 'Reports', 'cb-codetizer' ),
			'manage_options',
			'cb-codetizer-reports',
			function () {
				$this->render_page( 'cb-codetizer-reports' );
			}
		);

		// Settings sub-page.
		add_submenu_page(
			'cb-codetizer',
			esc_html__( 'Settings', 'cb-codetizer' ),
			esc_html__( 'Settings', 'cb-codetizer' ),
			'manage_options',
			'cb-codetizer-settings',
			function () {
				$this->render_page( 'cb-codetizer-settings' );
			}
		);

		// JS Arena / code management.
		add_submenu_page(
			'cb-codetizer',
			esc_html__( 'JS Arena', 'cb-codetizer' ),
			esc_html__( 'JS Arena', 'cb-codetizer' ),
			'manage_options',
			'cb-codetizer-js-arena',
			function () {
				$this->render_page( 'cb-codetizer-js-arena' );
			}
		);

		// Pages Builder.
		add_submenu_page(
			'cb-codetizer',
			esc_html__( 'Pages Builder', 'cb-codetizer' ),
			esc_html__( 'Pages Builder', 'cb-codetizer' ),
			'manage_options',
			'cb-codetizer-pages-builder',
			function () {
				$this->render_page( 'cb-codetizer-pages-builder' );
			}
		);

		// About sub-page.
		add_submenu_page(
			'cb-codetizer',
			esc_html__( 'About', 'cb-codetizer' ),
			esc_html__( 'About', 'cb-codetizer' ),
			'manage_options',
			'cb-codetizer-about',
			function () {
				$this->render_page( 'cb-codetizer-about' );
			}
		);
	}

	/**
	 * Render a plugin admin page.
	 *
	 * Verifies the current user has the 'manage_options' capability,
	 * then includes the appropriate template file. If the page slug
	 * is not recognized, a fallback message is displayed.
	 *
	 * @param string $page The menu page slug.
	 * @return void
	 */
	public function render_page( string $page ): void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die(
				esc_html__( 'You do not have permission to access this page.', 'cb-codetizer' ),
				403
			);
		}

		$template = $this->page_templates[ $page ] ?? null;

		if ( null === $template ) {
			printf(
				'<div class="wrap"><h1>%s</h1><p>%s</p></div>',
				esc_html__( 'CB Codetizer', 'cb-codetizer' ),
				esc_html__( 'The requested page could not be found.', 'cb-codetizer' )
			);
			return;
		}

		$template_path = CB_CODETIZER_PATH . 'templates/' . $template . '.php';

		if ( ! file_exists( $template_path ) ) {
			printf(
				'<div class="wrap"><h1>%s</h1><p>%s</p></div>',
				esc_html__( 'CB Codetizer', 'cb-codetizer' ),
				esc_html__( 'The template file for this page is missing.', 'cb-codetizer' )
			);
			return;
		}

		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- template file handles its own escaping.
		include $template_path;
	}

	/**
	 * Handle the post-activation redirect to the About page.
	 *
	 * Checks for the 'cb_codetizer_activated' transient. If present,
	 * deletes it and redirects the user to the About page once.
	 *
	 * @return void
	 */
	public function handle_activation_redirect(): void {
		if ( get_transient( 'cb_codetizer_activated' ) ) {
			delete_transient( 'cb_codetizer_activated' );

			// Only redirect if we are not already on the about page.
			$screen = get_current_screen();
			if ( $screen && 'cb-codetizer' !== $screen->parent_base ) {
				wp_safe_redirect( admin_url( 'admin.php?page=cb-codetizer-about' ) );
				exit;
			}
		}
	}
}
