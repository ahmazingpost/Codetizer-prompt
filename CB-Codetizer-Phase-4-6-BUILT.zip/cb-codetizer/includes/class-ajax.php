<?php
/**
 * CB CODETIZER - AJAX Handlers
 *
 * Registers and implements every wp_ajax_* action used by the
 * plugin's admin interface. Each handler verifies the nonce and
 * the user capability before processing the request.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CB_Codetizer_Ajax
 *
 * Thin controller layer that wires incoming AJAX requests to the
 * appropriate engine or settings/reports service.
 */
class CB_Codetizer_Ajax {

	/**
	 * Constructor.
	 *
	 * Registers all AJAX action handlers with WordPress.
	 */
	public function __construct() {
		$this->register_handlers();
	}

	/**
	 * Register all wp_ajax_* actions.
	 *
	 * @return void
	 */
	public function register_handlers(): void {
		$actions = array(
			'cb_codetizer_inspect',
			'cb_codetizer_sanitize',
			'cb_codetizer_beautify',
			'cb_codetizer_save_settings',
			'cb_codetizer_reset_settings',
			'cb_codetizer_clear_reports',
			'cb_codetizer_delete_report',
			'cb_codetizer_get_reports',
			'cb_codetizer_export_csv',
			'cb_codetizer_get_dashboard_stats',
		);

		foreach ( $actions as $action ) {
			add_action( 'wp_ajax_' . $action, array( $this, 'handle_' . str_replace( 'cb_codetizer_', '', $action ) ) );
		}
	}

	/* ------------------------------------------------------------------
	 *  Shared helpers.
	 * ----------------------------------------------------------------- */

	/**
	 * Read code from either a file upload or a POST field.
	 *
	 * After reading, the input is passed through assert_size_limit() so
	 * that no engine ever receives a payload larger than the configured
	 * maximum (default 5 MB). This is a defense-in-depth against memory
	 * exhaustion and ReDoS on adversarial inputs.
	 *
	 * @param string $post_key  The POST field name containing raw code.
	 * @param string $file_key  The FILES key for uploaded files.
	 * @return string|WP_Error  Raw code string or WP_Error on failure.
	 */
	private function get_code_input( string $post_key = 'code', string $file_key = 'code_file' ): string|WP_Error {
		if ( ! empty( $_FILES[ $file_key ]['name'] ) ) {
			$file_check = CB_Codetizer_Security::check_file_upload( $_FILES[ $file_key ] );

			if ( is_wp_error( $file_check ) ) {
				return $file_check;
			}

			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
			$code = file_get_contents( $file_check );

			if ( false === $code ) {
				return new WP_Error( 'read_fail', esc_html__( 'Failed to read the uploaded file.', 'cb-codetizer' ) );
			}

			$size_error = CB_Codetizer_Security::assert_size_limit( $code );
			if ( is_wp_error( $size_error ) ) {
				return $size_error;
			}

			return $code;
		}

		$raw_code = isset( $_POST[ $post_key ] ) ? wp_unslash( $_POST[ $post_key ] ) : '';
		$code     = CB_Codetizer_Security::sanitize_code_input( is_string( $raw_code ) ? $raw_code : '' );

		$size_error = CB_Codetizer_Security::assert_size_limit( $code );
		if ( is_wp_error( $size_error ) ) {
			return $size_error;
		}

		return $code;
	}

	/**
	 * Enforce the per-action rate limit and send a 429 response on failure.
	 *
	 * @param string $action         Short action identifier.
	 * @param int    $max_per_minute Maximum calls per minute. Default 60.
	 * @return void
	 */
	private function enforce_rate_limit( string $action, int $max_per_minute = 60 ): void {
		$error = CB_Codetizer_Security::check_rate_limit( $action, $max_per_minute );
		if ( is_wp_error( $error ) ) {
			$data        = $error->get_error_data();
			$retry_after = ( is_array( $data ) && isset( $data['retry_after'] ) ) ? $data['retry_after'] : 60;
			if ( is_int( $retry_after ) ) {
				header( 'X-RateLimit-Reset: ' . (string) $retry_after );
			}
			wp_send_json_error(
				array( 'message' => $error->get_error_message() ),
				429
			);
		}
	}

	/**
	 * Resolve the effective language for a request.
	 *
	 * Uses the submitted language unless it is empty or 'auto', in which
	 * case content-based detection is applied.
	 *
	 * @param string $submitted The raw language value from POST.
	 * @param string $code      The code to inspect for auto-detection.
	 * @return string           A validated language identifier.
	 */
	private function resolve_language( string $submitted, string $code ): string {
		$submitted = strtolower( trim( $submitted ) );

		if ( '' === $submitted || 'auto' === $submitted ) {
			return CB_Codetizer_Helpers::detect_language( $code );
		}

		return CB_Codetizer_Security::validate_language( $submitted );
	}

	/* ------------------------------------------------------------------
	 *  Individual handler methods.
	 * ----------------------------------------------------------------- */

	/**
	 * Handle the code inspection request.
	 *
	 * Accepts code from POST (or a file upload), runs it through
	 * the Inspector engine, saves a report, and returns results.
	 */
	public function handle_inspect(): void {
		CB_Codetizer_Security::verify_nonce( 'cb_codetizer_inspect' );
		CB_Codetizer_Security::verify_capability( 'cb_codetizer_use_tools' );
		$this->enforce_rate_limit( 'inspect' );

		$code = $this->get_code_input( 'code', 'code_file' );

		if ( is_wp_error( $code ) ) {
			wp_send_json_error( array( 'message' => $code->get_error_message() ) );
		}

		if ( empty( $code ) ) {
			wp_send_json_error( array( 'message' => esc_html__( 'No code provided for inspection.', 'cb-codetizer' ) ) );
		}

		// Resolve language — auto-detect when not specified or 'auto'.
		$submitted = isset( $_POST['language'] ) ? sanitize_text_field( wp_unslash( $_POST['language'] ) ) : '';
		$language  = $this->resolve_language( $submitted, $code );

		// Run inspection.
		/**
		 * Fires immediately before the Inspector engine runs.
		 *
		 * Fires after nonce verification, capability verification, and
		 * language validation have already passed — a callback attached
		 * here cannot be used to bypass any of those checks, only to
		 * observe or log the request.
		 *
		 * @param string $code     The code about to be inspected.
		 * @param string $language The validated language identifier.
		 */
		do_action( 'cb_codetizer_before_inspect', $code, $language );

		$engine  = CB_Codetizer_Services::inspector();
		$results = $engine->inspect( $code, $language, CB_Codetizer_Security::resolve_scan_profile() );

		/**
		 * Fires immediately after the Inspector engine runs.
		 *
		 * @param array  $results  The inspection results array.
		 * @param string $code     The code that was inspected.
		 * @param string $language The validated language identifier.
		 */
		do_action( 'cb_codetizer_after_inspect', $results, $code, $language );

		// Add detected language and original code to response.
		$results['language']      = $language;
		$results['original_code'] = $code;

		// Build threats_high / threats_medium / threats_low aliases for JS.
		$results['threats_high']   = $results['stats']['threats_high']   ?? 0;
		$results['threats_medium'] = $results['stats']['threats_medium'] ?? 0;
		$results['threats_low']    = $results['stats']['threats_low']    ?? 0;
		$results['threats_info']   = $results['stats']['threats_info']   ?? 0;

		// Save report.
		$reports     = new CB_Codetizer_Reports();
		$report_data = array(
			'scan_type'        => 'inspector',
			'language'         => $language,
			'input_summary'    => CB_Codetizer_Helpers::truncate( $code, 200 ),
			'output_summary'   => $results['summary'] ?? '',
			'results'          => $results,
			'threats_found'    => count( $results['threats'] ?? array() ),
			'severity_summary' => $results['summary'] ?? '',
			'score'            => $results['score'] ?? 100,
		);
		$insert_id = $reports->save( $report_data );

		CB_Codetizer_Helpers::log_activity(
			sprintf(
				/* translators: %s: Language name, %d: Number of threats */
				esc_html__( 'Inspected %1$s code: %2$d threat(s) found.', 'cb-codetizer' ),
				esc_html( strtoupper( $language ) ),
				count( $results['threats'] ?? array() )
			)
		);

		$results['report_id'] = $insert_id;

		wp_send_json_success( $results );
	}

	/**
	 * Handle the code sanitization request.
	 *
	 * Runs the Inspector before and after sanitization so the caller
	 * receives a full before/after security-score comparison, along with
	 * the full list of threats found, removed, and remaining.
	 */
	public function handle_sanitize(): void {
		CB_Codetizer_Security::verify_nonce( 'cb_codetizer_sanitize' );
		CB_Codetizer_Security::verify_capability( 'cb_codetizer_use_tools' );
		$this->enforce_rate_limit( 'sanitize' );

		$code = $this->get_code_input( 'code', 'code_file' );

		if ( is_wp_error( $code ) ) {
			wp_send_json_error( array( 'message' => $code->get_error_message() ) );
		}

		if ( empty( $code ) ) {
			wp_send_json_error( array( 'message' => esc_html__( 'No code provided for sanitization.', 'cb-codetizer' ) ) );
		}

		// Resolve language.
		$submitted = isset( $_POST['language'] ) ? sanitize_text_field( wp_unslash( $_POST['language'] ) ) : '';
		$language  = $this->resolve_language( $submitted, $code );
		$profile   = CB_Codetizer_Security::resolve_scan_profile();

		// --- Step 1: Inspect BEFORE sanitization ---
		$inspector = CB_Codetizer_Services::inspector();

		/** This action is documented in handle_inspect() above. */
		do_action( 'cb_codetizer_before_inspect', $code, $language );
		$before_report = $inspector->inspect( $code, $language, $profile );
		/** This action is documented in handle_inspect() above. */
		do_action( 'cb_codetizer_after_inspect', $before_report, $code, $language );

		$score_before  = $before_report['score'] ?? 100;
		$threats_found = count( $before_report['threats'] ?? array() );

		// Phase 4: mandatory backup before any destructive mutation.
		$backups = new CB_Codetizer_Backups();
		$backup_id = $backups->create( 'sanitize', $language, $code, array(
			'profile' => $profile,
			'threats_found' => $threats_found,
		) );
		if ( false === $backup_id ) {
			wp_send_json_error( array( 'message' => esc_html__( 'Sanitization stopped because the safety backup could not be created.', 'cb-codetizer' ) ), 500 );
		}

		// Phase 4: apply only declarative, proven transformations first.
		$transformer = CB_Codetizer_Services::transformer();
		$transform = $transformer->transform( $code, $language );
		$working_code = $transform['transformed_code'] ?? $code;
		$transformation_report = $transform['changes'] ?? array();

		// Mandatory verification after a transformation and before the legacy
		// sanitizer fallback is allowed to run.
		if ( ! empty( $transform['verification_required'] ) ) {
			$transform_check = $inspector->inspect( $working_code, $language, $profile );
			if ( ! empty( $transform_check['threats'] ) ) {
				$working_code = $code;
				$transformation_report = array();
			}
		}

		// --- Step 2: Sanitizer fallback for anything not safely transformed ---
		$sanitizer = CB_Codetizer_Services::sanitizer();

		/**
		 * Fires immediately before the Sanitizer engine runs.
		 *
		 * Fires after nonce verification, capability verification, and
		 * language validation have already passed — a callback attached
		 * here cannot be used to bypass any of those checks.
		 *
		 * @param string $code     The code about to be sanitized.
		 * @param string $language The validated language identifier.
		 */
		do_action( 'cb_codetizer_before_sanitize', $code, $language );
		$san = $sanitizer->sanitize( $working_code, $language );
		/**
		 * Fires immediately after the Sanitizer engine runs.
		 *
		 * @param array  $san      The sanitize() result array (sanitized_code, removed_items).
		 * @param string $code     The original code that was sanitized.
		 * @param string $language The validated language identifier.
		 */
		do_action( 'cb_codetizer_after_sanitize', $san, $code, $language );

		$sanitized_code = $san['sanitized_code'] ?? $code;
		$removed_items  = $san['removed_items']  ?? array();
		$items_removed  = count( $removed_items );

		// Split removed items into 'security' (a real Inspector-flagged
		// threat was neutralized) vs 'structural' (DOM-allowlist policy
		// cleanup, e.g. an element simply not on the allowlist — never
		// flagged as a threat by Inspector in the first place). Items
		// without an explicit category (all regex-layer items, and most
		// DOM-layer items) default to 'security', since that is what they
		// are; only the allowlist-driven "disallowed element/attribute"
		// removals are tagged 'structural'. This lets the UI and score
		// reporting stay internally consistent: structural cleanup should
		// not be reported the same way as a neutralized threat.
		$structural_items = array_values( array_filter( $removed_items, static function ( $item ) {
			return 'structural' === ( $item['category'] ?? 'security' );
		} ) );
		$security_items = array_values( array_filter( $removed_items, static function ( $item ) {
			return 'structural' !== ( $item['category'] ?? 'security' );
		} ) );
		$structural_changes = count( $structural_items );
		$security_removed   = count( $security_items );

		// --- Step 3: Inspect AFTER sanitization ---
		/** This action is documented in handle_inspect() above. */
		do_action( 'cb_codetizer_before_inspect', $sanitized_code, $language );
		$after_report = $inspector->inspect( $sanitized_code, $language, $profile );
		/** This action is documented in handle_inspect() above. */
		do_action( 'cb_codetizer_after_inspect', $after_report, $sanitized_code, $language );

		$score_after             = $after_report['score'] ?? 100;
		$threats_remaining_count = count( $after_report['threats'] ?? array() );

		// Build remaining threats list with explanation.
		//
		// BUG FIX: this detailed array used to be built and then silently
		// discarded — the response sent a plain integer count under the
		// 'threats_remaining' key, while assets/js/sanitizer.js expects
		// that key to hold this array (it calls .length and .forEach on
		// it). The mismatch meant the "Remaining Threats" stat always
		// rendered as `undefined`, and the "Remaining Threats" detail
		// panel always fell through to "All detected threats were removed
		// successfully" even when threats genuinely remained. Sending the
		// array here (matching the JS's existing, correct expectation)
		// fixes both without requiring any JS change.
		$remaining_threats = array();
		foreach ( $after_report['threats'] ?? array() as $t ) {
			$remaining_threats[] = array(
				'type'           => $t['type'],
				'severity'       => $t['severity'],
				'line'           => $t['line'],
				'description'    => $t['description'],
				'recommendation' => $t['recommendation'],
				'reason_not_auto_removed' => esc_html__( 'This threat requires manual review and cannot be safely removed automatically without potentially breaking the code.', 'cb-codetizer' ),
			);
		}

		// Compose full response.
		//
		// NOTE on 'threats_removed': kept as the full removed-items count
		// (unchanged) for backward compatibility with any existing
		// consumer of this field. 'threats_removed_security' and
		// 'structural_changes' are additive fields that split that same
		// total by category — see the split above.
		$response = array(
			'original_code'            => $code,
			'backup_id'                => $backup_id,
			'transformations'          => $transformation_report,
			'sanitized_code'           => $sanitized_code,
			'language'                 => $language,
			'score_before'             => $score_before,
			'score_after'              => $score_after,
			'threats_found'            => $threats_found,
			'threats_removed'          => $items_removed,
			'threats_removed_security' => $security_removed,
			'structural_changes'       => $structural_changes,
			'threats_remaining'        => $remaining_threats,
			'threats_remaining_count'  => $threats_remaining_count,
			'removed_items'            => $removed_items,
			'stats'                    => array(
				'items_removed'  => $items_removed,
				'original_size'  => strlen( $code ),
				'cleaned_size'   => strlen( $sanitized_code ),
			),
		);

		// Save report.
		$reports     = new CB_Codetizer_Reports();
		$severity_parts = array();
		if ( $threats_found > 0 ) {
			$severity_parts[] = sprintf(
				/* translators: %d: Count */
				_n( '%d threat found', '%d threats found', $threats_found, 'cb-codetizer' ),
				$threats_found
			);
		}
		if ( $items_removed > 0 ) {
			$severity_parts[] = sprintf(
				/* translators: %d: Count */
				_n( '%d removed', '%d removed', $items_removed, 'cb-codetizer' ),
				$items_removed
			);
		}
		if ( $threats_remaining_count > 0 ) {
			$severity_parts[] = sprintf(
				/* translators: %d: Count */
				_n( '%d remaining', '%d remaining', $threats_remaining_count, 'cb-codetizer' ),
				$threats_remaining_count
			);
		}

		$reports->save( array(
			'scan_type'        => 'sanitizer',
			'language'         => $language,
			'input_summary'    => CB_Codetizer_Helpers::truncate( $code, 200 ),
			'output_summary'   => CB_Codetizer_Helpers::truncate( $sanitized_code, 200 ),
			'results'          => $response,
			'threats_found'    => $threats_found,
			'severity_summary' => implode( ', ', $severity_parts ),
			'score'            => $score_after,
		) );

		CB_Codetizer_Helpers::log_activity(
			sprintf(
				/* translators: %1$s: Language, %2$d: removed, %3$d: remaining */
				esc_html__( 'Sanitized %1$s code: %2$d item(s) removed, %3$d remaining.', 'cb-codetizer' ),
				esc_html( strtoupper( $language ) ),
				$items_removed,
				$threats_remaining_count
			)
		);

		wp_send_json_success( $response );
	}

	/**
	 * Handle the code beautification request.
	 *
	 * Accepts code from POST (or a file upload), runs it through
	 * the Beautifier engine with the current indent settings, and
	 * returns the formatted code together with the original.
	 */
	public function handle_beautify(): void {
		CB_Codetizer_Security::verify_nonce( 'cb_codetizer_beautify' );
		CB_Codetizer_Security::verify_capability( 'cb_codetizer_use_tools' );
		$this->enforce_rate_limit( 'beautify' );

		$code = $this->get_code_input( 'code', 'code_file' );

		if ( is_wp_error( $code ) ) {
			wp_send_json_error( array( 'message' => $code->get_error_message() ) );
		}

		if ( empty( $code ) ) {
			wp_send_json_error( array( 'message' => esc_html__( 'No code provided for beautification.', 'cb-codetizer' ) ) );
		}

		// Resolve language.
		$submitted = isset( $_POST['language'] ) ? sanitize_text_field( wp_unslash( $_POST['language'] ) ) : '';
		$language  = $this->resolve_language( $submitted, $code );

		// Read indent settings.
		$indent_size = (int) get_option( 'cb_codetizer_indent_size', 4 );
		$indent_type = (string) get_option( 'cb_codetizer_indent_type', 'spaces' );

		// Beautify.
		$engine  = CB_Codetizer_Services::beautifier();
		$results = $engine->beautify( $code, $language, $indent_size, $indent_type );

		// Add original code and language to response.
		$results['original_code'] = $code;
		$results['language']      = $language;

		// Convenience aliases for JS compatibility.
		$results['original_lines']   = $results['stats']['original_lines']   ?? count( explode( "\n", $code ) );
		$results['beautified_lines'] = $results['stats']['beautified_lines'] ?? count( explode( "\n", $results['beautified_code'] ?? $code ) );

		// Save report.
		$reports = new CB_Codetizer_Reports();
		$reports->save( array(
			'scan_type'        => 'beautifier',
			'language'         => $language,
			'input_summary'    => CB_Codetizer_Helpers::truncate( $code, 200 ),
			'output_summary'   => CB_Codetizer_Helpers::truncate( $results['beautified_code'] ?? '', 200 ),
			'results'          => $results,
			'threats_found'    => 0,
			'severity_summary' => sprintf(
				/* translators: %d: line count */
				esc_html__( 'Beautified successfully — %d lines', 'cb-codetizer' ),
				$results['beautified_lines']
			),
			'score'            => 100,
		) );

		CB_Codetizer_Helpers::log_activity(
			sprintf(
				/* translators: %s: Language name */
				esc_html__( 'Beautified %s code successfully.', 'cb-codetizer' ),
				esc_html( strtoupper( $language ) )
			)
		);

		wp_send_json_success( $results );
	}

	/**
	 * Handle saving plugin settings.
	 */
	public function handle_save_settings(): void {
		CB_Codetizer_Security::verify_nonce( 'cb_codetizer_settings_page' );
		CB_Codetizer_Security::verify_capability( 'cb_codetizer_manage_settings' );
		$this->enforce_rate_limit( 'save_settings' );

		$raw          = isset( $_POST['settings'] ) ? wp_unslash( $_POST['settings'] ) : '';
		$raw_settings = json_decode( $raw, true );

		if ( ! is_array( $raw_settings ) ) {
			wp_send_json_error( array( 'message' => esc_html__( 'Invalid settings data.', 'cb-codetizer' ) ) );
		}

		$settings = new CB_Codetizer_Settings();
		$result   = $settings->save( $raw_settings );

		wp_send_json_success( $result );
	}

	/**
	 * Handle resetting plugin settings to defaults.
	 */
	public function handle_reset_settings(): void {
		CB_Codetizer_Security::verify_nonce( 'cb_codetizer_settings_page' );
		CB_Codetizer_Security::verify_capability( 'cb_codetizer_manage_settings' );
		$this->enforce_rate_limit( 'reset_settings' );

		$settings = new CB_Codetizer_Settings();
		$result   = $settings->reset();

		wp_send_json_success( $result );
	}

	/**
	 * Handle clearing all reports.
	 */
	public function handle_clear_reports(): void {
		CB_Codetizer_Security::verify_nonce_any(
			array( 'cb_codetizer_get_reports', 'cb_codetizer_settings_page' )
		);
		CB_Codetizer_Security::verify_capability( 'cb_codetizer_view_reports' );
		$this->enforce_rate_limit( 'clear_reports' );

		$reports_model = new CB_Codetizer_Reports();
		$success       = $reports_model->delete_all();

		if ( $success ) {
			wp_send_json_success( array( 'message' => esc_html__( 'All reports cleared.', 'cb-codetizer' ) ) );
		} else {
			wp_send_json_error( array( 'message' => esc_html__( 'Failed to clear reports.', 'cb-codetizer' ) ) );
		}
	}

	/**
	 * Handle deleting a single report.
	 */
	public function handle_delete_report(): void {
		CB_Codetizer_Security::verify_nonce( 'cb_codetizer_get_reports' );
		CB_Codetizer_Security::verify_capability( 'cb_codetizer_view_reports' );
		$this->enforce_rate_limit( 'delete_report' );

		$id = isset( $_POST['report_id'] ) ? absint( $_POST['report_id'] ) : 0;

		if ( ! $id ) {
			wp_send_json_error( array( 'message' => esc_html__( 'Invalid report ID.', 'cb-codetizer' ) ) );
		}

		$reports_model = new CB_Codetizer_Reports();
		$success       = $reports_model->delete( $id );

		if ( $success ) {
			wp_send_json_success( array( 'message' => esc_html__( 'Report deleted.', 'cb-codetizer' ) ) );
		} else {
			wp_send_json_error( array( 'message' => esc_html__( 'Failed to delete report.', 'cb-codetizer' ) ) );
		}
	}

	/**
	 * Handle the paginated reports list request.
	 */
	public function handle_get_reports(): void {
		CB_Codetizer_Security::verify_nonce( 'cb_codetizer_get_reports' );
		CB_Codetizer_Security::verify_capability( 'cb_codetizer_view_reports' );
		$this->enforce_rate_limit( 'get_reports' );

		$page      = isset( $_POST['page'] )     ? absint( $_POST['page'] )                                              : 1;
		$per_page  = isset( $_POST['per_page'] ) ? max( 1, min( 100, absint( $_POST['per_page'] ) ) )                   : 20;
		$search    = isset( $_POST['search'] )   ? sanitize_text_field( wp_unslash( $_POST['search'] ) )                : '';
		$scan_type = isset( $_POST['filter'] )   ? sanitize_text_field( wp_unslash( $_POST['filter'] ) )                : '';

		if ( 'all' === $scan_type ) {
			$scan_type = '';
		}

		$reports_model = new CB_Codetizer_Reports();
		$result        = $reports_model->get_all( array(
			'page'      => $page,
			'per_page'  => $per_page,
			'search'    => $search,
			'scan_type' => $scan_type,
		) );

		// Normalise rows for the JS: rename scan_type → type.
		// SECURITY: We intentionally do NOT include the full `results` blob
		// in the list response. The results blob contains the original
		// scanned code, sanitized code, threat snippets, and removed_items —
		// all of which are potentially dangerous if rendered. The list view
		// only needs the summary fields. A separate get-report endpoint can
		// provide full details when the user explicitly opens a single report.
		$normalised = array();
		foreach ( $result['reports'] as $row ) {
			$item = array(
				'id'       => (int) $row->id,
				'type'     => $row->scan_type ?? '',
				'language' => $row->language  ?? '',
				'summary'  => $row->input_summary  ?? '',
				'threats'  => (int) ( $row->threats_found ?? 0 ),
				'severity' => $row->severity_summary ?? '',
				'date'     => $row->created_at ?? '',
				'score'    => isset( $row->score ) ? (int) $row->score : null,
			);

			$normalised[] = $item;
		}

		wp_send_json_success( array(
			'reports'      => $normalised,
			'total'        => $result['total'],
			'pages'        => $result['pages'],
			'current_page' => $result['current_page'],
		) );
	}

	/**
	 * Handle CSV export of all reports.
	 */
	public function handle_export_csv(): void {
		CB_Codetizer_Security::verify_nonce( 'cb_codetizer_get_reports' );
		CB_Codetizer_Security::verify_capability( 'cb_codetizer_view_reports' );
		$this->enforce_rate_limit( 'export_csv' );

		$reports_model = new CB_Codetizer_Reports();
		$all_reports   = $reports_model->get_all( array( 'per_page' => 10000 ) );

		$report_rows = $all_reports['reports'] ?? array();

		if ( empty( $report_rows ) ) {
			wp_send_json_error( array(
				'message' => esc_html__( 'No reports to export.', 'cb-codetizer' ),
			) );
		}

		$exporter = new CB_Codetizer_CSV_Export();
		$csv      = $exporter->generate( $report_rows );

		wp_send_json_success( array( 'csv' => $csv ) );
	}

	/**
	 * Handle the dashboard stats AJAX request.
	 */
	public function handle_get_dashboard_stats(): void {
		CB_Codetizer_Security::verify_nonce( 'cb_codetizer_get_dashboard_stats' );
		CB_Codetizer_Security::verify_capability( 'cb_codetizer_view_reports' );
		$this->enforce_rate_limit( 'get_dashboard_stats' );

		$reports = new CB_Codetizer_Reports();
		$stats   = $reports->get_stats();

		// Use the persisted `score` column via the model method,
		// avoiding raw JSON_EXTRACT queries in the controller layer.
		$stats['average_score'] = $reports->get_average_score();

		$activity_log = CB_Codetizer_Helpers::get_activity_log();

		wp_send_json_success( array(
			'stats'        => $stats,
			'activity_log' => $activity_log,
		) );
	}
}
