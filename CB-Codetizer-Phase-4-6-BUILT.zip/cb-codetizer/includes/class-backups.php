<?php
/**
 * CB CODETIZER - Backups
 *
 * Independently queryable before/after content backups for destructive
 * sanitization and future Elementor operations.
 *
 * @package CB_Codetizer
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class CB_Codetizer_Backups {
    private wpdb $db;
    private string $table_name;

    public function __construct() {
        global $wpdb;
        $this->db = $wpdb;
        $this->table_name = $wpdb->prefix . 'cb_codetizer_backups';
    }

    public function create( string $source_type, string $language, string $content, array $meta = array() ): int|false {
        $hash = hash( 'sha256', $content );
        $result = $this->db->insert(
            $this->table_name,
            array(
                'source_type' => sanitize_key( $source_type ),
                'language'    => sanitize_key( $language ),
                'content'     => $content,
                'content_hash'=> $hash,
                'meta'        => wp_json_encode( $meta ),
                'created_at'  => current_time( 'mysql' ),
                'user_id'     => get_current_user_id(),
            ),
            array( '%s', '%s', '%s', '%s', '%s', '%s', '%d' )
        );
        return false === $result ? false : (int) $this->db->insert_id;
    }

    public function get( int $id ): object|null {
        $sql = $this->db->prepare( "SELECT * FROM {$this->table_name} WHERE id = %d", $id );
        $row = $this->db->get_row( $sql );
        return $row ?: null;
    }

    public function get_all( int $per_page = 20, int $page = 1, ?int $user_id = null ): array {
        $per_page = max( 1, min( 100, $per_page ) );
        $page = max( 1, $page );
        $offset = ( $page - 1 ) * $per_page;
        $where = '1=1';
        $args = array();
        if ( null !== $user_id ) {
            $where .= ' AND user_id = %d';
            $args[] = $user_id;
        }
        $count_sql = $this->db->prepare( "SELECT COUNT(*) FROM {$this->table_name} WHERE {$where}", ...$args );
        $total = (int) $this->db->get_var( $count_sql );
        $args[] = $per_page;
        $args[] = $offset;
        $sql = $this->db->prepare( "SELECT id, source_type, language, content_hash, meta, created_at, user_id FROM {$this->table_name} WHERE {$where} ORDER BY id DESC LIMIT %d OFFSET %d", ...$args );
        return array(
            'backups' => $this->db->get_results( $sql ) ?: array(),
            'total' => $total,
            'pages' => max( 1, (int) ceil( $total / $per_page ) ),
            'current_page' => $page,
        );
    }

    /**
     * Restore only after the caller has explicitly confirmed. The supplied
     * verifier must return an array containing a zero-threat result.
     */
    public function restore( int $id, callable $verifier, bool $confirmed = false ): array|WP_Error {
        if ( ! $confirmed ) {
            return new WP_Error( 'confirmation_required', __( 'Explicit restore confirmation is required.', 'cb-codetizer' ) );
        }
        $backup = $this->get( $id );
        if ( ! $backup ) {
            return new WP_Error( 'backup_not_found', __( 'Backup not found.', 'cb-codetizer' ) );
        }
        $verification = call_user_func( $verifier, (string) $backup->content, (string) $backup->language );
        if ( is_wp_error( $verification ) ) { return $verification; }
        $threats = is_array( $verification ) ? ( $verification['threats'] ?? array() ) : array();
        if ( ! empty( $threats ) ) {
            return new WP_Error( 'restore_blocked', __( 'Restore blocked because the backed-up content still contains detected threats.', 'cb-codetizer' ), array( 'threats' => $threats ) );
        }
        return array( 'content' => (string) $backup->content, 'backup' => $backup, 'verification' => $verification );
    }

    public function purge_older_than_days( int $days = 30 ): int {
        $days = max( 1, $days );
        $cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );
        $sql = $this->db->prepare( "DELETE FROM {$this->table_name} WHERE created_at < %s", $cutoff );
        $deleted = $this->db->query( $sql );
        return false === $deleted ? 0 : (int) $deleted;
    }
}
