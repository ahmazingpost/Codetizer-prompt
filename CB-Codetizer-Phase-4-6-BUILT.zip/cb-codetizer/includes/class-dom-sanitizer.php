<?php
/**
 * CB CODETIZER - DOM Sanitizer
 *
 * Provides DOM-based sanitization for HTML, SVG, and XML content.
 * This is the primary structural sanitization layer; the regex-based
 * CB_Codetizer_Sanitizer_Engine serves as a secondary defense-in-depth
 * pass for languages that do not benefit from DOM parsing (JS, PHP, CSS,
 * Markdown) and to catch anything the DOM pass misses.
 *
 * Security properties:
 *   - Uses an explicit element allowlist (no denylist).
 *   - Uses an explicit attribute allowlist.
 *   - Removes ALL on* event handler attributes.
 *   - Validates URL-bearing attributes (href, src, action, etc.) against
 *     an allowlist of safe URL schemes.
 *   - Disables external entity loading (XXE protection).
 *   - Rejects DOCTYPE/ENTITY declarations before parsing.
 *   - Removes <script>, <iframe>, <object>, <embed>, <foreignObject>,
 *     <use> with external href, and other dangerous elements.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CB_Codetizer_DOM_Sanitizer
 *
 * Static utility class providing DOM-based sanitization for markup languages.
 */
class CB_Codetizer_DOM_Sanitizer {

	/**
	 * HTML element allowlist.
	 *
	 * Elements NOT in this list are removed (along with their children for
	 * dangerous elements, or escaped for benign-but-unknown elements).
	 * This is a conservative allowlist; it can be extended via the
	 * cb_codetizer_allowed_html_elements filter.
	 */
	const ALLOWED_HTML_ELEMENTS = array(
		// Document structure
		'html', 'head', 'body', 'title', 'meta', 'link', 'base',
		// Sections
		'div', 'span', 'p', 'br', 'hr', 'pre', 'blockquote', 'address',
		// Headings
		'h1', 'h2', 'h3', 'h4', 'h5', 'h6',
		// Lists
		'ul', 'ol', 'li', 'dl', 'dt', 'dd',
		// Tables
		'table', 'thead', 'tbody', 'tfoot', 'tr', 'th', 'td', 'caption', 'colgroup', 'col',
		// Text formatting
		'a', 'strong', 'em', 'b', 'i', 'u', 's', 'small', 'mark', 'sub', 'sup',
		'del', 'ins', 'abbr', 'cite', 'q', 'code', 'kbd', 'samp', 'var', 'time',
		// Media (sanitized)
		'img', 'figure', 'figcaption', 'picture', 'source', 'audio', 'video', 'track',
		// Forms (sanitized — form action, input values are checked)
		'form', 'fieldset', 'legend', 'label', 'input', 'button', 'select', 'option', 'optgroup', 'textarea',
		// Semantic
		'article', 'aside', 'nav', 'section', 'header', 'footer', 'main', 'details', 'summary',
		'hgroup', 'dialog', 'data', 'wbr', 'bdi', 'bdo', 'ruby', 'rt', 'rp',
		// Presentational containers with a dedicated, content-aware sanitization
		// path (see walk_and_sanitize()): <style> content is run through the
		// CSS sanitizer; <svg> subtrees are re-validated against the
		// SVG-specific allowlist/dangerous-element rules, not the HTML ones.
		'style', 'svg',
	);

	/**
	 * HTML elements whose entire subtree is removed (dangerous elements).
	 *
	 * These are removed along with all their children. They are NOT in the
	 * allowlist, but listing them here ensures they are removed even if a
	 * future filter adds them to the allowlist by mistake.
	 */
	const DANGEROUS_HTML_ELEMENTS = array(
		'script', 'iframe', 'object', 'embed', 'applet', 'frame', 'frameset', 'noframes',
		'noscript', 'template', 'slot',
	);

	/**
	 * SVG element allowlist.
	 *
	 * SVG is more dangerous than HTML because it supports <script>,
	 * <foreignObject> (arbitrary HTML inside SVG), external references,
	 * and event handlers. This allowlist is intentionally conservative.
	 */
	const ALLOWED_SVG_ELEMENTS = array(
		// Root
		'svg', 'g', 'defs', 'symbol', 'use',
		// Shapes
		'path', 'rect', 'circle', 'ellipse', 'line', 'polyline', 'polygon',
		// Text
		'text', 'tspan', 'textPath', 'defs',
		// Styling
		'style',
		// Grouping
		'a', 'switch', 'image',
		// Gradients/patterns
		'linearGradient', 'radialGradient', 'stop', 'pattern',
		// Clip/mask
		'clipPath', 'mask',
		// Markers
		'marker',
		// Other
		'title', 'desc', 'metadata',
	);

	/**
	 * SVG elements that are always removed (dangerous in SVG context).
	 */
	const DANGEROUS_SVG_ELEMENTS = array(
		'script', 'foreignObject', 'foreignobject', 'animate', 'animateTransform',
		'animateMotion', 'set',
	);

	/**
	 * Global attribute allowlist (allowed on any element).
	 *
	 * Does NOT include any on* event handlers — those are always removed.
	 */
	const ALLOWED_GLOBAL_ATTRIBUTES = array(
		'class', 'id', 'style', 'title', 'lang', 'dir', 'tabindex',
		'role', 'aria-hidden', 'aria-label', 'aria-labelledby', 'aria-describedby',
		'aria-live', 'aria-expanded', 'aria-selected', 'aria-checked', 'aria-disabled',
		'aria-haspopup', 'aria-controls', 'aria-owns', 'aria-activedescendant',
		'data-testid', 'data-id', 'data-type',
	);

	/**
	 * Element-specific attribute allowlist.
	 *
	 * Maps element name => array of allowed attributes (in addition to global).
	 */
	const ALLOWED_ELEMENT_ATTRIBUTES = array(
		'a'      => array( 'href', 'name', 'target', 'rel', 'download', 'type' ),
		'img'    => array( 'src', 'alt', 'width', 'height', 'loading', 'srcset', 'sizes', 'decoding' ),
		'source' => array( 'src', 'srcset', 'sizes', 'type', 'media' ),
		'input'  => array( 'type', 'name', 'value', 'placeholder', 'required', 'disabled', 'readonly', 'checked', 'min', 'max', 'step', 'pattern', 'maxlength', 'minlength', 'multiple', 'accept', 'autocomplete', 'autofocus', 'list', 'size', 'span' ),
		'textarea' => array( 'name', 'placeholder', 'required', 'disabled', 'readonly', 'rows', 'cols', 'maxlength', 'minlength', 'wrap', 'autocomplete', 'autofocus' ),
		'select' => array( 'name', 'required', 'disabled', 'multiple', 'size', 'autocomplete', 'autofocus' ),
		'option' => array( 'value', 'selected', 'disabled', 'label' ),
		'optgroup' => array( 'label', 'disabled' ),
		'button' => array( 'type', 'name', 'value', 'disabled' ),
		'form'   => array( 'action', 'method', 'enctype', 'accept-charset', 'target', 'autocomplete', 'novalidate' ),
		'label'  => array( 'for' ),
		'fieldset' => array( 'disabled', 'form', 'name' ),
		'table'  => array( 'summary', 'border', 'cellpadding', 'cellspacing' ),
		'th'     => array( 'colspan', 'rowspan', 'scope', 'abbr', 'headers', 'sorted' ),
		'td'     => array( 'colspan', 'rowspan', 'headers' ),
		'col'    => array( 'span' ),
		'colgroup' => array( 'span' ),
		'video'  => array( 'src', 'poster', 'width', 'height', 'controls', 'autoplay', 'loop', 'muted', 'preload', 'playsinline' ),
		'audio'  => array( 'src', 'controls', 'autoplay', 'loop', 'muted', 'preload' ),
		'track'  => array( 'src', 'kind', 'srclang', 'label', 'default' ),
		'meta'   => array( 'name', 'content', 'charset', 'http-equiv', 'property' ),
		'link'   => array( 'href', 'rel', 'type', 'media', 'sizes', 'crossorigin', 'integrity', 'as' ),
		'base'   => array( 'href', 'target' ),
		'details' => array( 'open' ),
		'dialog' => array( 'open' ),
		'ol'     => array( 'type', 'start', 'reversed' ),
		'ul'     => array( 'type' ),
		// SVG-specific
		'svg'    => array( 'xmlns', 'xmlns:xlink', 'viewBox', 'width', 'height', 'preserveAspectRatio', 'version', 'baseProfile', 'x', 'y' ),
		'use'    => array( 'href', 'xlink:href', 'x', 'y', 'width', 'height' ),
		'image'  => array( 'href', 'xlink:href', 'x', 'y', 'width', 'height', 'preserveAspectRatio' ),
		'path'   => array( 'd', 'fill', 'stroke', 'stroke-width', 'stroke-linecap', 'stroke-linejoin', 'stroke-dasharray', 'stroke-dashoffset', 'stroke-opacity', 'fill-opacity', 'opacity', 'transform' ),
		'rect'   => array( 'x', 'y', 'width', 'height', 'rx', 'ry', 'fill', 'stroke', 'stroke-width', 'transform', 'opacity' ),
		'circle' => array( 'cx', 'cy', 'r', 'fill', 'stroke', 'stroke-width', 'transform', 'opacity' ),
		'ellipse' => array( 'cx', 'cy', 'rx', 'ry', 'fill', 'stroke', 'stroke-width', 'transform', 'opacity' ),
		'line'   => array( 'x1', 'y1', 'x2', 'y2', 'stroke', 'stroke-width', 'transform', 'opacity' ),
		'polyline' => array( 'points', 'fill', 'stroke', 'stroke-width', 'transform', 'opacity' ),
		'polygon' => array( 'points', 'fill', 'stroke', 'stroke-width', 'transform', 'opacity' ),
		'text'   => array( 'x', 'y', 'dx', 'dy', 'text-anchor', 'font-family', 'font-size', 'font-weight', 'fill', 'transform', 'opacity' ),
		'g'      => array( 'transform', 'opacity' ),
		'stop'   => array( 'offset', 'stop-color', 'stop-opacity' ),
		'linearGradient' => array( 'id', 'x1', 'y1', 'x2', 'y2', 'gradientUnits', 'gradientTransform', 'spreadMethod' ),
		'radialGradient' => array( 'id', 'cx', 'cy', 'r', 'fx', 'fy', 'gradientUnits', 'gradientTransform', 'spreadMethod' ),
	);

	/**
	 * Allowed URL schemes for URL-bearing attributes.
	 *
	 * Any URL not matching one of these schemes (after lowercasing) is
	 * replaced with '#'. This prevents javascript:, vbscript:, data:
	 * (except data:image/* which is allowed), and other dangerous schemes.
	 */
	const ALLOWED_URL_SCHEMES = array(
		'http', 'https', 'mailto', 'tel', 'ftp', 'ftps', 'sms', 'geo', 'news', 'nntp',
	);

	/**
	 * URL-bearing attributes that need scheme validation.
	 */
	const URL_BEARING_ATTRIBUTES = array(
		'href', 'src', 'action', 'formaction', 'data', 'poster', 'background',
		'cite', 'longdesc', 'usemap', 'profile', 'manifest', 'archive',
		'codebase', 'classid', 'icon', 'dynsrc', 'xlink:href',
	);

	/**
	 * Sanitize HTML content using DOM-based parsing.
	 *
	 * @param string $html The HTML content to sanitize.
	 * @return array{ sanitized: string, removed: array } Sanitized HTML and list of removed items.
	 */
	public static function sanitize_html( string $html ): array {
		$removed = array();

		if ( '' === trim( $html ) ) {
			return array( 'sanitized' => $html, 'removed' => $removed );
		}

		if ( ! class_exists( 'DOMDocument' ) ) {
			// No DOMDocument available — return unchanged. The regex-based
			// sanitizer will handle what it can.
			return array( 'sanitized' => $html, 'removed' => $removed );
		}

		$prev_errors = libxml_use_internal_errors( true );

		$dom = CB_Codetizer_Security::create_safe_domdocument();
		// LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD prevent libxml from
		// auto-inserting <html><head><body> wrappers around fragments.
		$options = LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD | CB_Codetizer_Security::safe_xml_options();
		$loaded = $dom->loadHTML( '<?xml encoding="UTF-8">' . $html, $options );

		libxml_clear_errors();
		libxml_use_internal_errors( $prev_errors );

		if ( ! $loaded ) {
			// Parse failed — return unchanged. Regex sanitizer handles it.
			return array( 'sanitized' => $html, 'removed' => $removed );
		}

		$allowed_elements  = self::get_allowed_html_elements();
		$dangerous_elements = self::DANGEROUS_HTML_ELEMENTS;

		self::walk_and_sanitize( $dom, $allowed_elements, $dangerous_elements, $removed, 'html' );

		// Serialize back to HTML.
		$output = $dom->saveHTML();

		// Remove the wrapping that saveHTML may add.
		$output = self::strip_html_wrappers( $output );

		// HTML parsing is case-insensitive and libxml lowercases SVG attribute
		// names such as viewBox to viewbox. The attribute is semantically valid,
		// but preserving the canonical SVG spelling keeps embedded SVG output
		// stable and avoids a false regression in consumers that compare the
		// serialized markup. Do this only for the canonical SVG attribute name;
		// no values or security decisions are changed here.
		$output = preg_replace_callback(
			'/<svg\\b[^>]*>/i',
			static function ( $matches ) {
				return preg_replace( '/\\bviewbox\\s*=/i', 'viewBox=', $matches[0] );
			},
			$output
		);

		return array( 'sanitized' => $output, 'removed' => $removed );
	}

	/**
	 * Sanitize SVG content using DOM-based parsing.
	 *
	 * SVG is treated as XML (stricter parsing) and uses a more restrictive
	 * allowlist than HTML. DOCTYPE/ENTITY declarations are rejected before
	 * parsing to prevent XXE.
	 *
	 * @param string $svg The SVG content to sanitize.
	 * @return array{ sanitized: string, removed: array } Sanitized SVG and list of removed items.
	 */
	public static function sanitize_svg( string $svg ): array {
		$removed = array();

		if ( '' === trim( $svg ) ) {
			return array( 'sanitized' => $svg, 'removed' => $removed );
		}

		// XXE defense-in-depth: reject DOCTYPE/ENTITY before parsing.
		if ( CB_Codetizer_Security::contains_dangerous_xml_declarations( $svg ) ) {
			$removed[] = array(
				'type'    => 'svg_doctype_or_entity',
				'content' => esc_html__( 'SVG contained DOCTYPE or ENTITY declarations which were blocked.', 'cb-codetizer' ),
				'line'    => 0,
				'reason'  => esc_html__( 'DOCTYPE/ENTITY declarations are blocked to prevent XXE attacks.', 'cb-codetizer' ),
			);
			// Return the SVG with DOCTYPE/ENTITY removed via regex (fallback).
			$svg = preg_replace( '/<!\s*DOCTYPE\b[^>]*>/i', '', $svg );
			$svg = preg_replace( '/<!\s*ENTITY\b[^>]*>/i', '', $svg );
		}

		if ( ! class_exists( 'DOMDocument' ) ) {
			return array( 'sanitized' => $svg, 'removed' => $removed );
		}

		$prev_errors = libxml_use_internal_errors( true );

		$dom = CB_Codetizer_Security::create_safe_domdocument();
		$loaded = $dom->loadXML( $svg, CB_Codetizer_Security::safe_xml_options() );

		libxml_clear_errors();
		libxml_use_internal_errors( $prev_errors );

		if ( ! $loaded ) {
			return array( 'sanitized' => $svg, 'removed' => $removed );
		}

		$allowed_elements   = self::get_allowed_svg_elements();
		$dangerous_elements = self::DANGEROUS_SVG_ELEMENTS;

		self::walk_and_sanitize( $dom, $allowed_elements, $dangerous_elements, $removed, 'svg' );

		$output = $dom->saveXML( $dom->documentElement );

		if ( false === $output ) {
			return array( 'sanitized' => $svg, 'removed' => $removed );
		}

		return array( 'sanitized' => $output, 'removed' => $removed );
	}

	/**
	 * Sanitize XML content using DOM-based parsing.
	 *
	 * @param string $xml The XML content to sanitize.
	 * @return array{ sanitized: string, removed: array } Sanitized XML and list of removed items.
	 */
	public static function sanitize_xml( string $xml ): array {
		$removed = array();

		if ( '' === trim( $xml ) ) {
			return array( 'sanitized' => $xml, 'removed' => $removed );
		}

		// XXE defense-in-depth: reject DOCTYPE/ENTITY before parsing.
		if ( CB_Codetizer_Security::contains_dangerous_xml_declarations( $xml ) ) {
			$removed[] = array(
				'type'    => 'xml_doctype_or_entity',
				'content' => esc_html__( 'XML contained DOCTYPE or ENTITY declarations which were blocked.', 'cb-codetizer' ),
				'line'    => 0,
				'reason'  => esc_html__( 'DOCTYPE/ENTITY declarations are blocked to prevent XXE attacks.', 'cb-codetizer' ),
			);
			$xml = preg_replace( '/<!\s*DOCTYPE\b[^>]*>/i', '', $xml );
			$xml = preg_replace( '/<!\s*ENTITY\b[^>]*>/i', '', $xml );
		}

		if ( ! class_exists( 'DOMDocument' ) ) {
			return array( 'sanitized' => $xml, 'removed' => $removed );
		}

		$prev_errors = libxml_use_internal_errors( true );

		$dom = CB_Codetizer_Security::create_safe_domdocument();
		$loaded = $dom->loadXML( $xml, CB_Codetizer_Security::safe_xml_options() );

		libxml_clear_errors();
		libxml_use_internal_errors( $prev_errors );

		if ( ! $loaded ) {
			return array( 'sanitized' => $xml, 'removed' => $removed );
		}

		// For XML, we don't use an element allowlist (XML vocabularies are
		// arbitrary). Instead, we remove known-dangerous constructs:
		// processing instructions (e.g. an embedded server-side tag), XInclude, XSLT script.
		self::remove_xml_dangerous_nodes( $dom, $removed );

		$output = $dom->saveXML();

		if ( false === $output ) {
			return array( 'sanitized' => $xml, 'removed' => $removed );
		}

		return array( 'sanitized' => $output, 'removed' => $removed );
	}

	/**
	 * Recursively walk the DOM and sanitize nodes.
	 *
	 * - Removes elements not in the allowlist (dangerous elements are removed
	 *   with their children; unknown elements are escaped or removed).
	 * - Removes attributes not in the allowlist.
	 * - Removes ALL on* event handler attributes.
	 * - Validates URL-bearing attributes.
	 *
	 * @param DOMNode $node               The node to walk.
	 * @param array   $allowed_elements   Lowercase tag names that are allowed.
	 * @param array   $dangerous_elements Lowercase tag names whose entire subtree is removed.
	 * @param array   $removed            Removed-items log (passed by reference).
	 * @param string  $context            'html' or 'svg' (for logging).
	 */
	private static function walk_and_sanitize( DOMNode $node, array $allowed_elements, array $dangerous_elements, array &$removed, string $context ): void {
		if ( ! $node->hasChildNodes() ) {
			return;
		}

		// Iterate over a copy of childNodes since we modify the tree.
		$children = array();
		foreach ( $node->childNodes as $child ) {
			$children[] = $child;
		}

		foreach ( $children as $child ) {
			self::process_node( $node, $child, $allowed_elements, $dangerous_elements, $removed, $context );
		}
	}

	/**
	 * Process a single child node against the given rule set.
	 *
	 * Handles: text/comment passthrough, IE conditional-comment removal,
	 * SVG context-switching, dangerous-element removal, allowlist
	 * enforcement (with child hoisting for disallowed-but-benign
	 * wrappers), <style> content sanitization, attribute sanitization,
	 * and recursion.
	 *
	 * SECURITY: when a disallowed element is unwrapped, its children are
	 * hoisted into the parent and then individually re-processed through
	 * this same method before returning. Without this, hoisted content
	 * would bypass every check below (dangerous-element removal,
	 * allowlist enforcement, attribute sanitization) simply because its
	 * original wrapper element was not on the allowlist — this was a
	 * genuine structural sanitization bypass affecting, e.g., an <svg>
	 * embedded in HTML before <svg> was added to ALLOWED_HTML_ELEMENTS.
	 *
	 * @param DOMNode $node               The parent node.
	 * @param DOMNode $child              The child node to process.
	 * @param array   $allowed_elements   Lowercase tag names allowed in the current context.
	 * @param array   $dangerous_elements Lowercase tag names removed with their subtree.
	 * @param array   $removed            Removed-items log (passed by reference).
	 * @param string  $context            'html' or 'svg' (for logging and rule selection).
	 */
	private static function process_node( DOMNode $node, DOMNode $child, array $allowed_elements, array $dangerous_elements, array &$removed, string $context ): void {
		if ( XML_ELEMENT_NODE !== $child->nodeType ) {
			// Text nodes, comment nodes, etc. — leave them (text is escaped
			// by DOMDocument on serialization). But remove comment nodes
			// that look like IE conditional comments (downlevel-revealed).
			if ( XML_COMMENT_NODE === $child->nodeType ) {
				$comment = $child->nodeValue;
				if ( preg_match( '/^\[if\s/i', trim( $comment ) ) ) {
					$node->removeChild( $child );
				}
			}
			return;
		}

		// Use localName where available so namespaced SVG nodes such as
		// <foreignObject> cannot evade the dangerous-element check because
		// DOMDocument exposes a namespace-qualified nodeName.
		$tag_name = strtolower( $child->localName ?: $child->nodeName );

		// Context switch: an <svg> element encountered while walking HTML
		// must be validated with the SVG-specific allowlist and
		// dangerous-element list, not the HTML ones — SVG has its own
		// dangerous constructs (<foreignObject>, <animate>/<set> attribute
		// injection, etc.) that do not exist in HTML and are not covered
		// by DANGEROUS_HTML_ELEMENTS. The <svg> wrapper itself is kept
		// (it is legitimate content), but everything inside it is walked
		// under 'svg' rules from this point on.
		if ( 'html' === $context && 'svg' === $tag_name ) {
			self::sanitize_attributes( $child, $removed, 'svg' );
			self::walk_and_sanitize( $child, self::get_allowed_svg_elements(), self::DANGEROUS_SVG_ELEMENTS, $removed, 'svg' );
			return;
		}

		// <style> content is CSS, not markup — validate it with the CSS
		// sanitizer rather than either passing it through unchecked or
		// discarding it as an unknown wrapper.
		if ( 'style' === $tag_name ) {
			self::sanitize_style_element( $child, $removed, $context );
			return;
		}

		// Remove dangerous elements (entire subtree).
		if ( in_array( $tag_name, $dangerous_elements, true ) ) {
			$removed[] = array(
				'type'    => $context . '_dangerous_element',
				'content' => esc_html( CB_Codetizer_Helpers::truncate( $child->nodeName, 200 ) ),
				'line'    => $child->getLineNo(),
				'reason'  => sprintf(
					/* translators: %s: Element name */
					esc_html__( 'Removed dangerous <%s> element and its contents.', 'cb-codetizer' ),
					esc_html( $child->nodeName )
				),
			);
			$node->removeChild( $child );
			return;
		}

		// Remove elements not in the allowlist.
		if ( ! in_array( $tag_name, $allowed_elements, true ) ) {
			// For unknown elements, remove the element but keep children
			// (unwrap). This preserves text content while removing the
			// potentially dangerous wrapper.
			$removed[] = array(
				'type'     => $context . '_disallowed_element',
				'content'  => esc_html( CB_Codetizer_Helpers::truncate( $child->nodeName, 200 ) ),
				'line'     => $child->getLineNo(),
				'reason'   => sprintf(
					/* translators: %s: Element name */
					esc_html__( 'Removed disallowed <%s> element (children preserved).', 'cb-codetizer' ),
					esc_html( $child->nodeName )
				),
				// Structural policy cleanup, not a neutralized security
				// threat — Inspector's rule set never flagged this element
				// as dangerous. Kept distinct from 'security' so reporting
				// (see class-ajax.php::handle_sanitize()) doesn't count it
				// as a "threat removed" and confuse the before/after score.
				'category' => 'structural',
			);

			// Move children to parent, then remove the element.
			$grandchildren = array();
			while ( $child->hasChildNodes() ) {
				$grandchild = $child->firstChild;
				$child->removeChild( $grandchild );
				$node->insertBefore( $grandchild, $child );
				$grandchildren[] = $grandchild;
			}
			$node->removeChild( $child );

			// Re-validate every hoisted grandchild through this same
			// method — see the security note in the docblock above.
			foreach ( $grandchildren as $grandchild ) {
				self::process_node( $node, $grandchild, $allowed_elements, $dangerous_elements, $removed, $context );
			}
			return;
		}

		// Sanitize attributes.
		self::sanitize_attributes( $child, $removed, $context );

		// Recurse into children.
		self::walk_and_sanitize( $child, $allowed_elements, $dangerous_elements, $removed, $context );
	}

	/**
	 * Sanitize a <style> element's text content as CSS.
	 *
	 * Reuses CB_Codetizer_Sanitizer_Engine::sanitize_css() (the same,
	 * already-audited logic used for standalone .css files) so dangerous
	 * CSS constructs (expression(), -moz-binding, behavior:, javascript:
	 * in url()) are stripped from inline <style> blocks exactly as they
	 * would be from a standalone stylesheet, instead of being passed
	 * through unchecked or the whole block being discarded.
	 *
	 * @param DOMElement $style_element The <style> element.
	 * @param array      $removed       Removed-items log (passed by reference).
	 * @param string     $context       'html' or 'svg'.
	 */
	private static function sanitize_style_element( DOMElement $style_element, array &$removed, string $context ): void {
		// The <style> element itself can still carry attributes (media,
		// or — illegitimately — an event handler); validate those the
		// same way every other allowed element's attributes are.
		self::sanitize_attributes( $style_element, $removed, $context );

		$css = $style_element->textContent;

		if ( '' !== trim( $css ) && class_exists( 'CB_Codetizer_Sanitizer_Engine' ) ) {
			list( $clean_css, $css_removed ) = CB_Codetizer_Sanitizer_Engine::sanitize_css( $css );

			if ( $clean_css !== $css ) {
				// Replace the element's content with the sanitized CSS.
				while ( $style_element->hasChildNodes() ) {
					$style_element->removeChild( $style_element->firstChild );
				}
				$style_element->appendChild( $style_element->ownerDocument->createTextNode( $clean_css ) );
			}

			foreach ( $css_removed as $item ) {
				$item['type'] = $context . '_style_' . ( $item['type'] ?? 'css_issue' );
				$removed[]    = $item;
			}
		}
	}

	/**
	 * Sanitize attributes on an element.
	 *
	 * - Removes attributes not in the allowlist (global or element-specific).
	 * - Removes ALL on* event handler attributes (always, regardless of allowlist).
	 * - Validates URL-bearing attributes.
	 *
	 * @param DOMElement $element The element to sanitize.
	 * @param array      $removed Removed-items log (passed by reference).
	 * @param string     $context 'html' or 'svg'.
	 */
	private static function sanitize_attributes( DOMElement $element, array &$removed, string $context ): void {
		if ( ! $element->hasAttributes() ) {
			return;
		}

		$tag_name         = strtolower( $element->nodeName );
		$global_attrs     = self::get_allowed_global_attributes();
		$element_attrs    = self::ALLOWED_ELEMENT_ATTRIBUTES[ $tag_name ] ?? array();
		$allowed_for_this = array_merge( $global_attrs, $element_attrs );
		// HTML parsing lowercases attribute names (for example viewBox ->
		// viewbox), while SVG/XML preserves their canonical spelling. Compare
		// case-insensitively but never mutate the original attribute name. This
		// preserves legitimate SVG attributes such as viewBox in embedded SVG.
		$allowed_for_this_normalized = array_map( 'strtolower', $allowed_for_this );

		// Iterate over a copy since we modify the attribute list.
		$attrs_to_remove = array();
		foreach ( $element->attributes as $attr ) {
			$attr_name = strtolower( $attr->nodeName );

			// ALWAYS remove on* event handlers, regardless of allowlist.
			if ( str_starts_with( $attr_name, 'on' ) ) {
				$attrs_to_remove[] = $attr_name;
				$removed[] = array(
					'type'    => $context . '_event_handler',
					'content' => esc_html( CB_Codetizer_Helpers::truncate( $attr_name . '="' . $attr->nodeValue . '"', 200 ) ),
					'line'    => $element->getLineNo(),
					'reason'  => sprintf(
						/* translators: %s: Attribute name */
						esc_html__( 'Removed event handler attribute %s.', 'cb-codetizer' ),
						esc_html( $attr_name )
					),
				);
				continue;
			}

			// Remove attributes not in the allowlist.
			if ( ! in_array( $attr_name, $allowed_for_this_normalized, true ) ) {
				$attrs_to_remove[] = $attr_name;
				$removed[] = array(
					'type'     => $context . '_disallowed_attribute',
					'content'  => esc_html( CB_Codetizer_Helpers::truncate( $attr_name, 200 ) ),
					'line'     => $element->getLineNo(),
					'reason'   => sprintf(
						/* translators: %s: Attribute name */
						esc_html__( 'Removed disallowed attribute %s.', 'cb-codetizer' ),
						esc_html( $attr_name )
					),
					// Policy cleanup (an attribute simply not on the
					// allowlist), not a neutralized threat — see the note
					// on '_disallowed_element' above.
					'category' => 'structural',
				);
				continue;
			}

			// Validate URL-bearing attributes.
			if ( in_array( $attr_name, self::URL_BEARING_ATTRIBUTES, true ) ) {
				$value = $attr->nodeValue;
				if ( ! self::is_safe_url( $value ) ) {
					$attrs_to_remove[] = $attr_name;
					$removed[] = array(
						'type'    => $context . '_dangerous_url',
						'content' => esc_html( CB_Codetizer_Helpers::truncate( $attr_name . '="' . $value . '"', 200 ) ),
						'line'    => $element->getLineNo(),
						'reason'  => sprintf(
							/* translators: %s: URL value */
							esc_html__( 'Removed URL with dangerous scheme: %s.', 'cb-codetizer' ),
							esc_html( CB_Codetizer_Helpers::truncate( $value, 100 ) )
						),
					);
				}
			}
		}

		foreach ( $attrs_to_remove as $attr_name ) {
			$element->removeAttribute( $attr_name );
		}
	}

	/**
	 * Remove dangerous XML nodes: processing instructions, XInclude, XSLT script.
	 *
	 * @param DOMDocument $dom     The document to clean.
	 * @param array       $removed Removed-items log (passed by reference).
	 */
	private static function remove_xml_dangerous_nodes( DOMDocument $dom, array &$removed ): void {
		$xpath = new DOMXPath( $dom );

		// Remove processing instructions (embedded server-side tags, XML stylesheet PIs, etc.)
		// except the XML declaration itself.
		$pis = $xpath->query( '//processing-instruction()' );
		if ( false !== $pis ) {
			foreach ( $pis as $pi ) {
				$target = strtolower( $pi->nodeName );
				if ( 'xml' === $target ) {
					continue; // Keep the XML declaration.
				}
				$removed[] = array(
					'type'    => 'xml_processing_instruction',
					'content' => esc_html( CB_Codetizer_Helpers::truncate( '<?' . $pi->target . ' ?>', 200 ) ),
					'line'    => $pi->getLineNo(),
					'reason'  => esc_html__( 'Removed XML processing instruction.', 'cb-codetizer' ),
				);
				$pi->parentNode->removeChild( $pi );
			}
		}

		// Remove XInclude elements (xi:include) in any namespace.
		$includes = $xpath->query( '//*[local-name()="include"]' );
		if ( false !== $includes ) {
			foreach ( $includes as $inc ) {
				$removed[] = array(
					'type'    => 'xml_xinclude',
					'content' => esc_html( CB_Codetizer_Helpers::truncate( '<' . $inc->nodeName . '>', 200 ) ),
					'line'    => $inc->getLineNo(),
					'reason'  => esc_html__( 'Removed XInclude element.', 'cb-codetizer' ),
				);
				$inc->parentNode->removeChild( $inc );
			}
		}

		// Remove XSLT script elements in any namespace.
		$scripts = $xpath->query( '//*[local-name()="script" and namespace-uri()="http://www.w3.org/1999/XSL/Transform"]' );
		if ( false !== $scripts ) {
			foreach ( $scripts as $script ) {
				$removed[] = array(
					'type'    => 'xml_xslt_script',
					'content' => esc_html( CB_Codetizer_Helpers::truncate( '<' . $script->nodeName . '>', 200 ) ),
					'line'    => $script->getLineNo(),
					'reason'  => esc_html__( 'Removed XSLT script element.', 'cb-codetizer' ),
				);
				$script->parentNode->removeChild( $script );
			}
		}
	}

	/**
	 * Check whether a URL is safe.
	 *
	 * A URL is safe if:
	 *   - It is a relative URL (no scheme), OR
	 *   - It uses an allowed scheme (http, https, mailto, etc.), OR
	 *   - It is a data: URL with an image/* MIME type (safe for img src), OR
	 *   - It is a fragment (#...) or anchor.
	 *
	 * @param string $url The URL to check.
	 * @return bool True if the URL is safe.
	 */
	private static function is_safe_url( string $url ): bool {
		$url = trim( $url );

		if ( '' === $url ) {
			return true;
		}

		// Fragment URLs are safe.
		if ( str_starts_with( $url, '#' ) ) {
			return true;
		}

		// Relative URLs (no scheme) are safe. Detect scheme by looking for
		// a colon before any /, ?, # that would indicate a path/query/fragment.
		$scheme_end = strpos( $url, ':' );
		if ( false === $scheme_end ) {
			return true; // No scheme — relative URL.
		}

		// Check if the colon is part of the path (e.g., "/foo:bar").
		$path_start = strpos( $url, '/' );
		if ( false !== $path_start && $path_start < $scheme_end ) {
			return true; // Colon is after a /, so it's a relative path.
		}

		$scheme = strtolower( substr( $url, 0, $scheme_end ) );

		// Allowlist of safe schemes.
		if ( in_array( $scheme, self::ALLOWED_URL_SCHEMES, true ) ) {
			return true;
		}

		// Allow data: URLs only for image/* MIME types.
		if ( 'data' === $scheme ) {
			if ( preg_match( '/^data:image\/[a-z0-9.+-]+/i', $url ) ) {
				return true;
			}
			return false;
		}

		// javascript:, vbscript:, and any other scheme are unsafe.
		return false;
	}

	/**
	 * Strip HTML wrappers added by saveHTML().
	 *
	 * saveHTML() on a fragment may add <html><body>...</body></html> wrappers.
	 * This removes them to return just the fragment content.
	 *
	 * @param string $html The HTML output from saveHTML().
	 * @return string The HTML with wrappers removed.
	 */
	private static function strip_html_wrappers( string $html ): string {
		// Remove <!DOCTYPE html> if present.
		$html = preg_replace( '/^<!DOCTYPE[^>]*>\s*/i', '', $html );

		// Remove <html> and <body> wrappers if the input was a fragment.
		// We only strip if they appear at the very start/end.
		$html = preg_replace( '/^<html[^>]*>\s*<body[^>]*>/i', '', $html );
		$html = preg_replace( '/<\/body>\s*<\/html>\s*$/i', '', $html );

		// Remove the XML encoding hint we added.
		$html = preg_replace( '/^<\?xml[^>]*\?>\s*/', '', $html );

		return trim( $html );
	}

	/**
	 * Get the allowed HTML elements, filterable.
	 *
	 * @return array Lowercase tag names.
	 */
	public static function get_allowed_html_elements(): array {
		$filtered = apply_filters( 'cb_codetizer_allowed_html_elements', self::ALLOWED_HTML_ELEMENTS );
		if ( ! is_array( $filtered ) ) {
			return self::ALLOWED_HTML_ELEMENTS;
		}
		$clean = array();
		foreach ( $filtered as $tag ) {
			if ( is_string( $tag ) ) {
				$clean[] = strtolower( trim( $tag ) );
			}
		}
		return $clean;
	}

	/**
	 * Get the allowed SVG elements, filterable.
	 *
	 * @return array Lowercase tag names.
	 */
	public static function get_allowed_svg_elements(): array {
		$filtered = apply_filters( 'cb_codetizer_allowed_svg_elements', self::ALLOWED_SVG_ELEMENTS );
		if ( ! is_array( $filtered ) ) {
			return self::ALLOWED_SVG_ELEMENTS;
		}
		$clean = array();
		foreach ( $filtered as $tag ) {
			if ( is_string( $tag ) ) {
				$clean[] = strtolower( trim( $tag ) );
			}
		}
		return $clean;
	}

	/**
	 * Get the allowed global attributes, filterable.
	 *
	 * @return array Lowercase attribute names.
	 */
	public static function get_allowed_global_attributes(): array {
		$filtered = apply_filters( 'cb_codetizer_allowed_global_attributes', self::ALLOWED_GLOBAL_ATTRIBUTES );
		if ( ! is_array( $filtered ) ) {
			return self::ALLOWED_GLOBAL_ATTRIBUTES;
		}
		$clean = array();
		foreach ( $filtered as $attr ) {
			if ( is_string( $attr ) ) {
				$clean[] = strtolower( trim( $attr ) );
			}
		}
		return $clean;
	}
}
