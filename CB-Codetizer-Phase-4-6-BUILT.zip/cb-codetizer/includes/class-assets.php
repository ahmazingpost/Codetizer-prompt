<?php
/**
 * CB CODETIZER - Assets
 *
 * Enqueues CSS and JavaScript files for every admin screen
 * that belongs to the CB Codetizer plugin.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CB_Codetizer_Assets
 *
 * Manages the conditional loading of stylesheets and scripts.
 * A global admin.css/admin.js pair is loaded on every CB Codetizer
 * page, and page-specific assets are loaded additionally.
 */
class CB_Codetizer_Assets {

	/**
	 * Map of page slugs (partial match) to their asset handles.
	 *
	 * The key is a substring expected to appear in the $hook parameter.
	 * Only pages that need extra assets beyond the global ones are listed.
	 *
	 * @var array<string, string>
	 */
	private array $page_asset_map = array(
		'cb-codetizer-inspector' => 'inspector',
		'cb-codetizer-sanitizer' => 'sanitizer',
		'cb-codetizer-beautifier'=> 'beautifier',
		'cb-codetizer-reports'   => 'reports',
		'cb-codetizer-settings'  => 'settings',
		'cb-codetizer-about'     => 'about',
		'cb-codetizer-js-arena'  => 'js-arena',
		'cb-codetizer-pages-builder' => 'pages-builder',
	);

	/**
	 * Constructor.
	 *
	 * Hooks the enqueue method into admin_enqueue_scripts.
	 */
	public function __construct() {
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
	}

	/**
	 * Enqueue styles and scripts for CB Codetizer admin pages.
	 *
	 * First checks whether the current hook belongs to the plugin.
	 * If so, the global admin.css and admin.js are always enqueued.
	 * Then, page-specific CSS and JS files are enqueued when applicable.
	 *
	 * @param string $hook The current admin page hook suffix.
	 * @return void
	 */
	public function enqueue( string $hook ): void {
		// Only load assets on CB Codetizer pages.
		if ( ! str_contains( $hook, 'cb-codetizer' ) ) {
			return;
		}

		// Global assets — loaded on every CB Codetizer page.
		$this->register_style( 'cb-codetizer-admin', 'assets/css/admin.css' );
		$this->register_script( 'cb-codetizer-admin', 'assets/js/admin.js' );
		$this->localize_admin_script();

		// Page-specific assets.
		foreach ( $this->page_asset_map as $hook_fragment => $handle ) {
			if ( str_contains( $hook, $hook_fragment ) ) {
				$this->register_style( 'cb-codetizer-' . $handle, 'assets/css/' . $handle . '.css' );
				$this->register_script( 'cb-codetizer-' . $handle, 'assets/js/' . $handle . '.js' );
				break;
			}
		}

		// Dashboard page (cb-codetizer page without a specific sub-slug) only gets globals.
	}

	/**
	 * Emit an explicit AJAX-action → nonce map for admin.js to consume.
	 *
	 * Historically admin.js located its nonce by querying the DOM for the
	 * first element named "cb_codetizer_nonce" on the page — which happens
	 * to work today because each page only ever calls AJAX actions that
	 * share that page's single embedded nonce action, but is fragile: it
	 * silently breaks the moment a page needs to call two AJAX actions
	 * bound to two different nonce actions.
	 *
	 * This localizes an explicit, unambiguous map instead: AJAX action
	 * name => a nonce valid for that specific action, generated with
	 * wp_create_nonce() so it is verified server-side exactly the same
	 * way as before (CB_Codetizer_Security::verify_nonce() /
	 * verify_nonce_any() are unchanged). The field name posted back is
	 * still "cb_codetizer_nonce" for full backward compatibility — this
	 * only changes *which* nonce value admin.js selects, not the
	 * request shape, and the old DOM-based lookup remains as a fallback
	 * (see assets/js/admin.js) so nothing breaks if this data object is
	 * ever unavailable for any reason.
	 *
	 * This does not weaken verification in any way: every nonce here is
	 * still a real, single-action-scoped WordPress nonce, and capability
	 * checks in CB_Codetizer_Security::verify_capability() are enforced
	 * independently of which nonce was used.
	 *
	 * @return void
	 */
	private function localize_admin_script(): void {
		// Maps each registered wp_ajax_* action name to the nonce action(s)
		// its handler actually verifies (see class-ajax.php register_handlers()
		// and each handle_*() method's verify_nonce()/verify_nonce_any() call).
		// Kept in sync with class-ajax.php by design — both are small and
		// reviewed together; this is not meant to replace verify_nonce()
		// server-side, only to make the client-side nonce selection explicit.
		$action_nonce_map = array(
			'cb_codetizer_inspect'             => 'cb_codetizer_inspect',
			'cb_codetizer_sanitize'            => 'cb_codetizer_sanitize',
			'cb_codetizer_beautify'            => 'cb_codetizer_beautify',
			'cb_codetizer_save_settings'       => 'cb_codetizer_settings_page',
			'cb_codetizer_reset_settings'      => 'cb_codetizer_settings_page',
			'cb_codetizer_clear_reports'       => 'cb_codetizer_get_reports',
			'cb_codetizer_delete_report'       => 'cb_codetizer_get_reports',
			'cb_codetizer_get_reports'         => 'cb_codetizer_get_reports',
			'cb_codetizer_export_csv'          => 'cb_codetizer_get_reports',
			'cb_codetizer_get_dashboard_stats' => 'cb_codetizer_get_dashboard_stats',
		);

		$nonces = array();
		foreach ( $action_nonce_map as $ajax_action => $nonce_action ) {
			$nonces[ $ajax_action ] = wp_create_nonce( $nonce_action );
		}

		wp_localize_script(
			'cb-codetizer-admin',
			'CBCodeTizerData',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonces'  => $nonces,
			)
		);
	}

	/**
	 * Register and enqueue a CSS stylesheet.
	 *
	 * Uses filemtime() for the version parameter so that
	 * browser caches are busted whenever the file changes.
	 *
	 * @param string $handle  The stylesheet handle.
	 * @param string $rel_path Path relative to CB_CODETIZER_URL.
	 * @return void
	 */
	private function register_style( string $handle, string $rel_path ): void {
		$file_path = CB_CODETIZER_PATH . $rel_path;
		$version   = file_exists( $file_path ) ? (string) filemtime( $file_path ) : CB_CODETIZER_VERSION;

		wp_enqueue_style(
			$handle,
			CB_CODETIZER_URL . $rel_path,
			array(),
			$version
		);
	}

	/**
	 * Register and enqueue a JavaScript file.
	 *
	 * Uses filemtime() for the version parameter so that
	 * browser caches are busted whenever the file changes.
	 * No jQuery dependency is declared — all scripts use vanilla JS.
	 *
	 * @param string $handle  The script handle.
	 * @param string $rel_path Path relative to CB_CODETIZER_URL.
	 * @return void
	 */
	private function register_script( string $handle, string $rel_path ): void {
		$file_path = CB_CODETIZER_PATH . $rel_path;
		$version   = file_exists( $file_path ) ? (string) filemtime( $file_path ) : CB_CODETIZER_VERSION;

		wp_enqueue_script(
			$handle,
			CB_CODETIZER_URL . $rel_path,
			array(),
			$version,
			true  // Load in footer.
		);
	}
}
