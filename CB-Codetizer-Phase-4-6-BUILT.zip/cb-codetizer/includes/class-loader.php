<?php
/**
 * CB CODETIZER - Loader
 *
 * Orchestrates the loading of all plugin include files and
 * instantiates core singleton-like service classes.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CB_Codetizer_Loader
 *
 * Responsible for requiring all necessary class files and
 * bootstrapping the plugin's core services in the correct order.
 */
class CB_Codetizer_Loader {

	/**
	 * Initialize the plugin by loading all required files and
	 * instantiating core classes.
	 *
	 * @return void
	 */
	public static function init(): void {
		$includes_dir = CB_CODETIZER_PATH . 'includes/';

		// --- Core utility classes first ---
		require_once $includes_dir . 'class-security.php';
		require_once $includes_dir . 'class-helpers.php';
		require_once $includes_dir . 'class-settings.php';
		require_once $includes_dir . 'class-reports.php';
		require_once $includes_dir . 'class-backups.php';
		require_once $includes_dir . 'class-js-arena.php';
		require_once $includes_dir . 'class-pages-builder.php';
		require_once $includes_dir . 'class-installer.php';

		// --- Engine classes ---
		require_once $includes_dir . 'engines/class-inspector-engine.php';
		require_once $includes_dir . 'engines/class-sanitizer-engine.php';
		require_once $includes_dir . 'engines/class-beautifier-engine.php';
		require_once $includes_dir . 'engines/class-threat-transformer-engine.php';
		require_once $includes_dir . 'class-services.php';

		// --- Exporter classes ---
		require_once $includes_dir . 'exporters/class-csv-export.php';
		require_once $includes_dir . 'exporters/class-download.php';

		// --- Infrastructure classes ---
		require_once $includes_dir . 'class-pattern-repository.php';
		require_once $includes_dir . 'class-dom-sanitizer.php';
		require_once $includes_dir . 'class-ajax.php';
		require_once $includes_dir . 'class-assets.php';
		require_once $includes_dir . 'class-admin.php';
		require_once $includes_dir . 'class-rest-api.php';

		$load_elementor = static function () use ( $includes_dir ): void {
		require_once $includes_dir . 'class-elementor-integration.php';
		if ( ! isset( $GLOBALS['cb_codetizer_elementor_integration'] ) ) {
			$GLOBALS['cb_codetizer_elementor_integration'] = new CB_Codetizer_Elementor_Integration( new CB_Codetizer_Backups() );
		}
		};
		if ( did_action( 'elementor/loaded' ) > 0 || class_exists( '\\Elementor\\Plugin' ) ) {
			$load_elementor();
		} else {
			add_action( 'elementor/loaded', $load_elementor, 5 );
		}

		add_action( 'rest_api_init', array( 'CB_Codetizer_REST_API', 'register' ) );
		add_action( 'cb_codetizer_cleanup_backups', static function (): void {
			$days = max( 1, (int) get_option( 'cb_codetizer_backup_retention_days', 30 ) );
			( new CB_Codetizer_Backups() )->purge_older_than_days( $days );
		} );

		// Run any pending DB upgrades (safe to call every load — no-op when
		// the stored version already matches CB_CODETIZER_VERSION).
		CB_Codetizer_Installer::maybe_upgrade();

		// --- Instantiate core services ---
		new CB_Codetizer_Settings();
		new CB_Codetizer_JS_Arena();
		new CB_Codetizer_Pages_Builder();
		new CB_Codetizer_Ajax();
		new CB_Codetizer_Assets();
		new CB_Codetizer_Admin();
	}
}
