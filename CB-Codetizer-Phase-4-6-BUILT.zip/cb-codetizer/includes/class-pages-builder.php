<?php
/**
 * CB CODETIZER - Pages Builder.
 *
 * Stores an editable draft per WordPress page and maps named code blocks to
 * real Elementor HTML widgets by their existing element IDs. Nothing is
 * written to Elementor until the user explicitly chooses Send to Elementor.
 *
 * @package CB_Codetizer
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class CB_Codetizer_Pages_Builder {
    public const META_KEY = '_cb_codetizer_pages_builder';

    public function __construct() {
        add_action( 'admin_post_cb_codetizer_pages_builder_save', array( $this, 'handle_save' ) );
        add_action( 'admin_post_cb_codetizer_pages_builder_send', array( $this, 'handle_send' ) );
    }

    public function get_pages(): array {
        $pages = get_pages( array(
            'sort_column' => 'post_title',
            'sort_order' => 'ASC',
            'post_status' => array( 'publish', 'draft', 'pending', 'private' ),
        ) );
        $out = array();
        foreach ( $pages as $page ) {
            $elementor = class_exists( 'CB_Codetizer_Elementor_Integration' )
                ? ( new CB_Codetizer_Elementor_Integration( new CB_Codetizer_Backups() ) )->is_elementor_page( (int) $page->ID )
                : false;
            $draft = $this->get_draft( (int) $page->ID );
            $out[] = array(
                'id' => (int) $page->ID,
                'name' => $page->post_title ?: __( '(Untitled page)', 'cb-codetizer' ),
                'status' => $page->post_status,
                'language' => $this->page_language( (int) $page->ID ),
                'elementor' => $elementor,
                'updated' => $page->post_modified,
                'blocks' => count( $draft['blocks'] ?? array() ),
            );
        }
        return $out;
    }

    public function get_draft( int $page_id ): array {
        $raw = get_post_meta( $page_id, self::META_KEY, true );
        $draft = is_string( $raw ) ? json_decode( $raw, true ) : $raw;
        if ( ! is_array( $draft ) ) { $draft = array(); }
        $draft['page_id'] = $page_id;
        $draft['blocks'] = is_array( $draft['blocks'] ?? null ) ? array_values( $draft['blocks'] ) : array();
        return $draft;
    }

    public function save_draft( int $page_id, array $blocks ): array|WP_Error {
        if ( ! get_post( $page_id ) ) { return new WP_Error( 'page_not_found', __( 'WordPress page not found.', 'cb-codetizer' ) ); }
        $clean = array();
        foreach ( $blocks as $block ) {
            if ( ! is_array( $block ) ) { continue; }
            $element_id = sanitize_text_field( (string) ( $block['element_id'] ?? '' ) );
            if ( '' === $element_id ) { continue; }
            $language = sanitize_key( (string) ( $block['language'] ?? 'html' ) );
            if ( ! in_array( $language, array( 'html', 'css', 'javascript' ), true ) ) { $language = 'html'; }
            $name = sanitize_text_field( (string) ( $block['name'] ?? '' ) );
            if ( '' === $name ) { $name = sprintf( __( 'HTML %s', 'cb-codetizer' ), $element_id ); }
            $clean[] = array(
                'id' => sanitize_key( (string) ( $block['id'] ?? wp_unique_id( 'cbblock_' ) ) ),
                'name' => $name,
                'language' => $language,
                'element_id' => $element_id,
                'element_type' => sanitize_key( (string) ( $block['element_type'] ?? 'widget:html' ) ),
                'code' => (string) ( $block['code'] ?? '' ),
                'updated' => current_time( 'mysql' ),
            );
        }
        $draft = array( 'version' => 1, 'page_id' => $page_id, 'blocks' => $clean, 'updated' => current_time( 'mysql' ) );
        update_post_meta( $page_id, self::META_KEY, wp_json_encode( $draft, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ) );
        return $draft;
    }

    public function handle_save(): void {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( esc_html__( 'Permission denied.', 'cb-codetizer' ), 403 ); }
        check_admin_referer( 'cb_codetizer_pages_builder_save', 'cb_codetizer_pages_builder_nonce' );
        $page_id = isset( $_POST['page_id'] ) ? absint( $_POST['page_id'] ) : 0;
        $blocks = array();
        if ( isset( $_POST['blocks'] ) && is_array( $_POST['blocks'] ) ) { $blocks = wp_unslash( $_POST['blocks'] ); }
        $result = $this->save_draft( $page_id, $blocks );
        if ( is_wp_error( $result ) ) { wp_die( esc_html( $result->get_error_message() ), 400 ); }
        wp_safe_redirect( admin_url( 'admin.php?page=cb-codetizer-pages-builder&page_id=' . $page_id . '&saved=1' ) );
        exit;
    }

    public function handle_send(): void {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( esc_html__( 'Permission denied.', 'cb-codetizer' ), 403 ); }
        check_admin_referer( 'cb_codetizer_pages_builder_send', 'cb_codetizer_pages_builder_nonce' );
        $page_id = isset( $_POST['page_id'] ) ? absint( $_POST['page_id'] ) : 0;
        $draft = $this->get_draft( $page_id );
        if ( ! class_exists( 'CB_Codetizer_Elementor_Integration' ) ) { wp_die( esc_html__( 'Elementor integration is unavailable.', 'cb-codetizer' ), 409 ); }
        $result = ( new CB_Codetizer_Elementor_Integration( new CB_Codetizer_Backups() ) )->apply_page_builder_blocks( $page_id, $draft['blocks'] );
        if ( is_wp_error( $result ) ) { wp_die( esc_html( $result->get_error_message() ), 400 ); }
        update_post_meta( $page_id, '_cb_codetizer_pages_builder_last_send', current_time( 'mysql' ) );
        wp_safe_redirect( admin_url( 'admin.php?page=cb-codetizer-pages-builder&page_id=' . $page_id . '&sent=1&updated=' . absint( $result['updated'] ?? 0 ) ) );
        exit;
    }

    private function page_language( int $page_id ): string {
        $locale = get_locale();
        $value = get_post_meta( $page_id, '_cb_codetizer_language', true );
        return $value ? sanitize_text_field( $value ) : $locale;
    }
}
