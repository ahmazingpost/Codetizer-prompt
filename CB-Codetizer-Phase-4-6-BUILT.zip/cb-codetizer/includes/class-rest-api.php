<?php
/**
 * CB CODETIZER - REST API (Phase 6)
 *
 * Minimal routes with real permission callbacks and the same validation
 * primitives used by AJAX. No route is public by default.
 *
 * @package CB_Codetizer
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class CB_Codetizer_REST_API {
    public static function register(): void {
        register_rest_route( 'cb-codetizer/v1', '/reports', array(
            array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( __CLASS__, 'reports' ), 'permission_callback' => array( __CLASS__, 'can_view_reports' ) ),
        ) );
        register_rest_route( 'cb-codetizer/v1', '/reports/(?P<id>\d+)', array(
            array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( __CLASS__, 'report' ), 'permission_callback' => array( __CLASS__, 'can_view_reports' ) ),
        ) );
        register_rest_route( 'cb-codetizer/v1', '/sanitize', array(
            array( 'methods' => WP_REST_Server::CREATABLE, 'callback' => array( __CLASS__, 'sanitize' ), 'permission_callback' => array( __CLASS__, 'can_use_tools' ), 'args' => array(
                'code' => array( 'required' => true, 'type' => 'string' ),
                'language' => array( 'required' => false, 'type' => 'string', 'default' => 'auto' ),
            ) ),
        ) );
        register_rest_route( 'cb-codetizer/v1', '/backups/(?P<id>\d+)/restore', array(
            array( 'methods' => WP_REST_Server::CREATABLE, 'callback' => array( __CLASS__, 'restore_backup' ), 'permission_callback' => array( __CLASS__, 'can_view_reports' ), 'args' => array(
                'confirmed' => array( 'required' => true, 'type' => 'boolean' ),
            ) ),
        ) );
        register_rest_route( 'cb-codetizer/v1', '/arena/items', array(
            array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( __CLASS__, 'arena_items' ), 'permission_callback' => array( __CLASS__, 'can_manage_settings' ) ),
            array( 'methods' => WP_REST_Server::CREATABLE, 'callback' => array( __CLASS__, 'arena_save' ), 'permission_callback' => array( __CLASS__, 'can_manage_settings' ) ),
        ) );
        register_rest_route( 'cb-codetizer/v1', '/arena/items/(?P<id>\d+)', array(
            array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( __CLASS__, 'arena_item' ), 'permission_callback' => array( __CLASS__, 'can_manage_settings' ) ),
            array( 'methods' => WP_REST_Server::DELETABLE, 'callback' => array( __CLASS__, 'arena_delete' ), 'permission_callback' => array( __CLASS__, 'can_manage_settings' ) ),
        ) );
        register_rest_route( 'cb-codetizer/v1', '/arena/items/(?P<id>\d+)/elementor', array(
            array( 'methods' => WP_REST_Server::CREATABLE, 'callback' => array( __CLASS__, 'arena_elementor' ), 'permission_callback' => array( __CLASS__, 'can_manage_settings' ) ),
        ) );
        register_rest_route( 'cb-codetizer/v1', '/pages', array(
            array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( __CLASS__, 'pages' ), 'permission_callback' => array( __CLASS__, 'can_manage_settings' ) ),
        ) );
        register_rest_route( 'cb-codetizer/v1', '/pages/(?P<id>\d+)/elements', array(
            array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( __CLASS__, 'page_elements' ), 'permission_callback' => array( __CLASS__, 'can_manage_settings' ) ),
        ) );
        register_rest_route( 'cb-codetizer/v1', '/pages/(?P<id>\d+)/builder', array(
            array( 'methods' => WP_REST_Server::READABLE, 'callback' => array( __CLASS__, 'page_builder_get' ), 'permission_callback' => array( __CLASS__, 'can_manage_settings' ) ),
            array( 'methods' => WP_REST_Server::CREATABLE, 'callback' => array( __CLASS__, 'page_builder_save' ), 'permission_callback' => array( __CLASS__, 'can_manage_settings' ) ),
        ) );
        register_rest_route( 'cb-codetizer/v1', '/pages/(?P<id>\d+)/builder/send', array(
            array( 'methods' => WP_REST_Server::CREATABLE, 'callback' => array( __CLASS__, 'page_builder_send' ), 'permission_callback' => array( __CLASS__, 'can_manage_settings' ) ),
        ) );

        register_rest_route( 'cb-codetizer/v1', '/elementor/(?P<id>\d+)/defaults', array(
            array( 'methods' => WP_REST_Server::CREATABLE, 'callback' => array( __CLASS__, 'elementor_defaults' ), 'permission_callback' => array( __CLASS__, 'can_use_tools' ) ),
        ) );

        register_rest_route( 'cb-codetizer/v1', '/elementor/(?P<id>\d+)/sanitize', array(
            array( 'methods' => WP_REST_Server::CREATABLE, 'callback' => array( __CLASS__, 'elementor_sanitize' ), 'permission_callback' => array( __CLASS__, 'can_use_tools' ), 'args' => array(
                'persist' => array( 'required' => false, 'type' => 'boolean', 'default' => false ),
            ) ),
        ) );
    }

    public static function can_use_tools(): bool { return self::capability( 'cb_codetizer_use_tools' ); }
    public static function can_view_reports(): bool { return self::capability( 'cb_codetizer_view_reports' ); }
    public static function can_manage_settings(): bool { return self::capability( 'cb_codetizer_manage_settings' ); }

    private static function capability( string $cap ): bool {
        return current_user_can( $cap ) || current_user_can( 'manage_options' );
    }

    public static function reports( WP_REST_Request $request ): WP_REST_Response {
        CB_Codetizer_Security::check_rate_limit( 'rest_reports' );
        $model = new CB_Codetizer_Reports();
        $user_id = current_user_can( 'manage_options' ) ? null : get_current_user_id();
        $data = $model->get_all( array(
            'page' => max( 1, (int) $request->get_param( 'page' ) ),
            'per_page' => min( 100, max( 1, (int) ( $request->get_param( 'per_page' ) ?: 20 ) ) ),
            'search' => (string) ( $request->get_param( 'search' ) ?: '' ),
            'scan_type' => (string) ( $request->get_param( 'scan_type' ) ?: '' ),
            'user_id' => $user_id,
        ) );
        return new WP_REST_Response( $data, 200 );
    }

    public static function report( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        $user_id = current_user_can( 'manage_options' ) ? null : get_current_user_id();
        $row = ( new CB_Codetizer_Reports() )->get_by_id( (int) $request['id'], $user_id );
        if ( ! $row ) { return new WP_Error( 'not_found', __( 'Report not found.', 'cb-codetizer' ), array( 'status' => 404 ) ); }
        return new WP_REST_Response( $row, 200 );
    }

    public static function sanitize( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        $code = (string) $request->get_param( 'code' );
        $size_error = CB_Codetizer_Security::assert_size_limit( $code );
        if ( is_wp_error( $size_error ) ) { return $size_error; }
        $language = CB_Codetizer_Security::validate_language( (string) $request->get_param( 'language' ) );
        if ( 'auto' === strtolower( (string) $request->get_param( 'language' ) ) ) { $language = CB_Codetizer_Helpers::detect_language( $code ); }
        $profile = CB_Codetizer_Security::resolve_scan_profile();
        $backup_id = ( new CB_Codetizer_Backups() )->create( 'rest-sanitize', $language, $code, array( 'profile' => $profile ) );
        if ( false === $backup_id ) { return new WP_Error( 'backup_failed', __( 'Sanitization stopped because the backup could not be created.', 'cb-codetizer' ), array( 'status' => 500 ) ); }
        $inspector = CB_Codetizer_Services::inspector();
        $before = $inspector->inspect( $code, $language, $profile );
        $transform = CB_Codetizer_Services::transformer()->transform( $code, $language );
        $working = $transform['transformed_code'] ?? $code;
        if ( ! empty( $transform['verification_required'] ) && ! empty( $inspector->inspect( $working, $language, $profile )['threats'] ) ) { $working = $code; $transform['changes'] = array(); }
        $san = CB_Codetizer_Services::sanitizer()->sanitize( $working, $language );
        $clean = $san['sanitized_code'] ?? $working;
        $after = $inspector->inspect( $clean, $language, $profile );
        $response = array(
            'original_code' => $code,
            'sanitized_code' => $clean,
            'language' => $language,
            'score_before' => $before['score'] ?? 100,
            'score_after' => $after['score'] ?? 100,
            'threats_found' => count( $before['threats'] ?? array() ),
            'threats_removed' => count( $san['removed_items'] ?? array() ),
            'threats_remaining' => $after['threats'] ?? array(),
            'threats_remaining_count' => count( $after['threats'] ?? array() ),
            'removed_items' => $san['removed_items'] ?? array(),
            'transformations' => $transform['changes'] ?? array(),
            'backup_id' => $backup_id,
        );
        return new WP_REST_Response( $response, 200 );
    }

    public static function restore_backup( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        $confirmed = (bool) $request->get_param( 'confirmed' );
        $backups = new CB_Codetizer_Backups();
        $result = $backups->restore( (int) $request['id'], static function ( string $content, string $language ) {
            return CB_Codetizer_Services::inspector()->inspect( $content, $language, CB_Codetizer_Security::resolve_scan_profile() );
        }, $confirmed );
        if ( is_wp_error( $result ) ) { return $result; }
        return new WP_REST_Response( $result, 200 );
    }

    public static function elementor_sanitize( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        if ( ! class_exists( 'CB_Codetizer_Elementor_Integration' ) ) { return new WP_Error( 'elementor_unavailable', __( 'Elementor integration is not loaded.', 'cb-codetizer' ), array( 'status' => 409 ) ); }
        $service = new CB_Codetizer_Elementor_Integration( new CB_Codetizer_Backups() );
        $result = $service->sanitize_post( (int) $request['id'], (bool) $request->get_param( 'persist' ) );
        if ( is_wp_error( $result ) ) { return $result; }
        return new WP_REST_Response( $result, 200 );
    }
    public static function arena_items( WP_REST_Request $request ): WP_REST_Response {
        return new WP_REST_Response( ( new CB_Codetizer_JS_Arena() )->get_items(), 200 );
    }

    public static function arena_item( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        $item = ( new CB_Codetizer_JS_Arena() )->get_item( (int) $request['id'] );
        return $item ? new WP_REST_Response( $item, 200 ) : new WP_Error( 'not_found', __( 'Code item not found.', 'cb-codetizer' ), array( 'status' => 404 ) );
    }

    public static function arena_save( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        $params = $request->get_json_params();
        $title = sanitize_text_field( (string) ( $params['name'] ?? '' ) );
        if ( '' === $title ) { return new WP_Error( 'missing_name', __( 'A code item name is required.', 'cb-codetizer' ), array( 'status' => 400 ) ); }
        $id = absint( $params['id'] ?? 0 );
        $post = wp_insert_post( array( 'ID' => $id, 'post_type' => CB_Codetizer_JS_Arena::POST_TYPE, 'post_status' => 'publish', 'post_title' => $title ), true );
        if ( is_wp_error( $post ) ) { return $post; }
        foreach ( array( 'language','html','css','javascript','target','target_page','elementor_post','enabled' ) as $key ) { if ( array_key_exists( $key, $params ) ) { update_post_meta( $post, '_cb_arena_' . $key, $key === 'target_page' || $key === 'elementor_post' ? absint( $params[$key] ) : ( $key === 'enabled' ? ( $params[$key] ? '1' : '0' ) : wp_unslash( $params[$key] ) ) ); } }
        return new WP_REST_Response( ( new CB_Codetizer_JS_Arena() )->get_item( $post ), 200 );
    }

    public static function arena_delete( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        $id = absint( $request['id'] );
        if ( ! get_post( $id ) ) { return new WP_Error( 'not_found', __( 'Code item not found.', 'cb-codetizer' ), array( 'status' => 404 ) ); }
        wp_delete_post( $id, true );
        return new WP_REST_Response( array( 'deleted' => true, 'id' => $id ), 200 );
    }

    public static function arena_elementor( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        $body = $request->get_json_params();
        $post_id = absint( $body['post_id'] ?? 0 );
        $item = ( new CB_Codetizer_JS_Arena() )->get_item( absint( $request['id'] ) );
        if ( ! $item ) { return new WP_Error( 'not_found', __( 'Code item not found.', 'cb-codetizer' ), array( 'status' => 404 ) ); }
        if ( ! $post_id || ! class_exists( 'CB_Codetizer_Elementor_Integration' ) ) { return new WP_Error( 'elementor_unavailable', __( 'Elementor target or integration is unavailable.', 'cb-codetizer' ), array( 'status' => 409 ) ); }
        $result = ( new CB_Codetizer_Elementor_Integration( new CB_Codetizer_Backups() ) )->apply_arena_item( $post_id, $item, true );
        return is_wp_error( $result ) ? $result : new WP_REST_Response( $result, 200 );
    }

    public static function pages( WP_REST_Request $request ): WP_REST_Response {
        return new WP_REST_Response( ( new CB_Codetizer_Pages_Builder() )->get_pages(), 200 );
    }

    public static function page_elements( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        if ( ! class_exists( 'CB_Codetizer_Elementor_Integration' ) ) { return new WP_Error( 'elementor_unavailable', __( 'Elementor integration is unavailable.', 'cb-codetizer' ), array( 'status' => 409 ) ); }
        $result = ( new CB_Codetizer_Elementor_Integration( new CB_Codetizer_Backups() ) )->discover_elements( (int) $request['id'] );
        return is_wp_error( $result ) ? $result : new WP_REST_Response( $result, 200 );
    }

    public static function page_builder_get( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        return new WP_REST_Response( ( new CB_Codetizer_Pages_Builder() )->get_draft( (int) $request['id'] ), 200 );
    }

    public static function page_builder_save( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        $body = $request->get_json_params();
        $blocks = is_array( $body['blocks'] ?? null ) ? $body['blocks'] : array();
        $result = ( new CB_Codetizer_Pages_Builder() )->save_draft( (int) $request['id'], $blocks );
        return is_wp_error( $result ) ? $result : new WP_REST_Response( $result, 200 );
    }

    public static function page_builder_send( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        if ( ! class_exists( 'CB_Codetizer_Elementor_Integration' ) ) { return new WP_Error( 'elementor_unavailable', __( 'Elementor integration is unavailable.', 'cb-codetizer' ), array( 'status' => 409 ) ); }
        $builder = new CB_Codetizer_Pages_Builder();
        $draft = $builder->get_draft( (int) $request['id'] );
        $result = ( new CB_Codetizer_Elementor_Integration( new CB_Codetizer_Backups() ) )->apply_page_builder_blocks( (int) $request['id'], $draft['blocks'] );
        return is_wp_error( $result ) ? $result : new WP_REST_Response( $result, 200 );
    }

    public static function elementor_defaults( WP_REST_Request $request ): WP_REST_Response|WP_Error {
        if ( ! class_exists( 'CB_Codetizer_Elementor_Integration' ) ) { return new WP_Error( 'elementor_unavailable', __( 'Elementor integration is unavailable.', 'cb-codetizer' ), array( 'status' => 409 ) ); }
        $result = ( new CB_Codetizer_Elementor_Integration( new CB_Codetizer_Backups() ) )->ensure_default_containers( (int) $request['id'], true );
        return is_wp_error( $result ) ? $result : new WP_REST_Response( $result, 200 );
    }

}
