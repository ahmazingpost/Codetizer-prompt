<?php
/**
 * CB CODETIZER - Safe Threat Transformer
 *
 * Declarative, deliberately small set of proven transformations. Rules never
 * execute arbitrary PHP; unknown/untransformable threats are left for the
 * existing sanitizer fallback.
 *
 * @package CB_Codetizer
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class CB_Codetizer_Threat_Transformer_Engine {
    public function transform( string $code, string $language ): array {
        $language = strtolower( $language );
        $original = $code;
        $changes = array();

        if ( in_array( $language, array( 'html', 'svg', 'xml' ), true ) ) {
            $code = preg_replace_callback(
                '/\b(href|src|action|formaction)\s*=\s*(["\'])\s*(?:javascript|vbscript)\s*:[^"\']*\2/i',
                static function ( $m ) use ( &$changes ) {
                    $changes[] = array( 'rule_id' => 'HTML-URI-001', 'action' => 'replace', 'before' => $m[0], 'after' => $m[1] . '=' . $m[2] . '#' . $m[2] );
                    return $m[1] . '=' . $m[2] . '#' . $m[2];
                },
                $code
            );
            $code = preg_replace_callback(
                '/<a\b[^>]*\btarget\s*=\s*(["\'])_blank\1[^>]*>/i',
                static function ( $m ) use ( &$changes ) {
                    if ( preg_match( '/\brel\s*=/i', $m[0] ) ) {
                        return $m[0];
                    }
                    $after = rtrim( substr( $m[0], 0, -1 ) ) . ' rel="noopener noreferrer">';
                    $changes[] = array( 'rule_id' => 'HTML-TARGET-001', 'action' => 'add_attribute', 'before' => $m[0], 'after' => $after );
                    return $after;
                },
                $code
            );
        }

        if ( 'css' === $language ) {
            $code = preg_replace_callback(
                '/url\(\s*(["\']?)\s*(?:javascript|vbscript|data)\s*:[^)]*\1\s*\)/i',
                static function ( $m ) use ( &$changes ) {
                    $changes[] = array( 'rule_id' => 'CSS-URL-001', 'action' => 'replace', 'before' => $m[0], 'after' => 'url(/* removed unsafe URL */)' );
                    return 'url(/* removed unsafe URL */)';
                },
                $code
            );
        }

        return array(
            'transformed_code' => $code,
            'changed' => $code !== $original,
            'changes' => $changes,
            'verification_required' => ! empty( $changes ),
        );
    }
}
