<?php
/**
 * CB CODETIZER - Inspector Engine
 *
 * Performs real pattern-matching code inspection across 9 supported
 * languages, identifying security threats and scoring the code.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CB_Codetizer_Inspector_Engine
 *
 * Analyses code line-by-line with language-specific regex patterns
 * to detect security threats. Each threat is classified by severity
 * and a 0–100 safety score is computed.
 */
class CB_Codetizer_Inspector_Engine {

	/**
	 * Severity-to-score deduction mapping.
	 *
	 * @var array<string, int>
	 */
	private array $deductions = array(
		'high'   => 15,
		'medium' => 10,
		'low'    => 5,
		'info'   => 1,
	);

	/**
	 * Inspect the given code for threats.
	 *
	 * @param string $code     The source code to inspect.
	 * @param string $language The language identifier.
	 * @return array{score: int, threats: array, summary: string, recommendations: array, stats: array}
	 */
	/**
	 * Inspect the given code for threats.
	 *
	 * @param string $code     The source code to inspect.
	 * @param string $language The language identifier.
	 * @param string $profile  Scan profile: 'standard' or 'strict'. Currently
	 *                         only affects PHP inspection (the only language
	 *                         whose rules are sourced from the Pattern
	 *                         Repository, which is what carries per-profile
	 *                         rule tagging). Any value other than 'standard'
	 *                         or 'strict' is treated as 'standard' — see
	 *                         CB_Codetizer_Pattern_Repository::get_rules_for_language().
	 * @return array{score: int, threats: array, summary: string, recommendations: array, stats: array}
	 */
	public function inspect( string $code, string $language = 'html', string $profile = 'standard' ): array {
		$lines      = explode( "\n", $code );
		$threats    = array();
		$language   = strtolower( $language );
		$profile    = strtolower( $profile );

		switch ( $language ) {
			case 'html':
				$threats = $this->inspect_html( $lines );
				break;
			case 'svg':
				$threats = $this->inspect_svg( $lines );
				break;
			case 'css':
				$threats = $this->inspect_css( $lines );
				break;
			case 'javascript':
				$threats = $this->inspect_javascript( $lines );
				break;
			case 'php':
				$threats = $this->inspect_php( $lines, $profile );
				break;
			case 'json':
				$threats = $this->inspect_json( $code, $lines );
				break;
			case 'xml':
				$threats = $this->inspect_xml( $lines );
				break;
			case 'markdown':
				$threats = $this->inspect_markdown( $lines );
				break;
			case 'txt':
			default:
				$threats = array();
				break;
		}

		// Calculate score.
		$score = 100;
		foreach ( $threats as $threat ) {
			$severity = strtolower( $threat['severity'] ?? 'info' );
			$score   -= $this->deductions[ $severity ] ?? 1;
		}
		$score = max( 0, $score );

		// Count per severity.
		$counts = array( 'high' => 0, 'medium' => 0, 'low' => 0, 'info' => 0 );
		foreach ( $threats as $threat ) {
			$sev = strtolower( $threat['severity'] ?? 'info' );
			if ( isset( $counts[ $sev ] ) ) {
				$counts[ $sev ]++;
			}
		}

		// Build summary.
		$total = count( $threats );
		if ( 0 === $total ) {
			$summary = esc_html__( 'No threats detected. The code appears safe.', 'cb-codetizer' );
		} else {
			$summary = sprintf(
				/* translators: %d: Total threats, %d: High severity, %s: Language */
				esc_html__( 'Found %1$d threat(s) in %3$s code (%2$d high severity).', 'cb-codetizer' ),
				$total,
				$counts['high'],
				esc_html( strtoupper( $language ) )
			);
		}

		// Collect unique recommendations.
		$recommendations = array();
		foreach ( $threats as $threat ) {
			$rec = $threat['recommendation'] ?? '';
			if ( ! empty( $rec ) && ! in_array( $rec, $recommendations, true ) ) {
				$recommendations[] = $rec;
			}
		}

		return array(
			'score'          => $score,
			'threats'        => $threats,
			'summary'        => $summary,
			'recommendations'=> $recommendations,
			'stats'          => array(
				'lines_scanned'  => count( $lines ),
				'threats_high'   => $counts['high'],
				'threats_medium' => $counts['medium'],
				'threats_low'    => $counts['low'],
				'threats_info'   => $counts['info'],
			),
		);
	}

	/* ------------------------------------------------------------------
	 *  Language-specific inspectors.
	 * ----------------------------------------------------------------- */

	/**
	 * Inspect HTML code.
	 *
	 * @param string[] $lines Array of code lines.
	 * @return array[] Array of threat descriptors.
	 */
	private function inspect_html( array $lines ): array {
		$threats = array();

		$event_handlers = '/\bon(click|error|load|mouseover|mouseout|mousedown|mouseup|mousemove|keydown|keyup|keypress|focus|blur|change|submit|reset|select|dblclick|contextmenu|drag|dragend|dragenter|dragleave|dragover|dragstart|drop|scroll|wheel|copy|cut|paste|beforeunload|hashchange|message|offline|online|pagehide|pageshow|popstate|resize|storage|unload|touchstart|touchend|touchmove|animationend|animationiteration|animationstart|transitionend)\s*=\s*["\x27]/i';

		foreach ( $lines as $ln => $line ) {
			$ln++;

			// Non-standard/external DOCTYPE declarations and ENTITY declarations
			// are XML/XXE constructs and should be visible to the HTML inspector
			// too. A normal <!DOCTYPE html> is intentionally allowed.
			if ( preg_match( '/<!DOCTYPE\s+(?!(?:html\b|html\s*>))[^>]*(?:SYSTEM|PUBLIC|\[)/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'html_external_doctype',
					'high',
					$ln,
					$m[0][1] + 1,
					esc_html__( 'Non-standard or external DOCTYPE declaration detected — potential XXE/parser abuse.', 'cb-codetizer' ),
					esc_html__( 'Remove external/internal-subset DOCTYPE declarations from untrusted HTML.', 'cb-codetizer' ),
					$line
				);
			}

			if ( preg_match( '/<!ENTITY\s/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'html_xml_entity',
					'high',
					$ln,
					$m[0][1] + 1,
					esc_html__( 'ENTITY declaration detected — potential XML External Entity (XXE) attack.', 'cb-codetizer' ),
					esc_html__( 'Remove ENTITY declarations from untrusted markup.', 'cb-codetizer' ),
					$line
				);
			}

			// Event handler attributes.
			if ( preg_match( $event_handlers, $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'event_handler',
					'high',
					$ln,
					$m[0][1] + 1,
					sprintf(
						/* translators: %s: The matched event handler attribute */
						esc_html__( 'Inline event handler %s detected — potential XSS vector.', 'cb-codetizer' ),
						esc_html( trim( $m[0][0] ) )
					),
					esc_html__( 'Remove inline event handlers and use addEventListener() instead.', 'cb-codetizer' ),
					$line
				);
			}

			// <script> tags.
			if ( preg_match( '/<script\b/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'script_tag',
					'high',
					$ln,
					$m[0][1] + 1,
					esc_html__( '<script> tag detected — potential XSS vector.', 'cb-codetizer' ),
					esc_html__( 'Review the script content. Use Content Security Policy (CSP) to restrict script execution.', 'cb-codetizer' ),
					$line
				);
			}

			// javascript: URLs.
			if ( preg_match( '/javascript\s*:/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'javascript_url',
					'high',
					$ln,
					$m[0][1] + 1,
					esc_html__( 'javascript: URL scheme detected — potential XSS.', 'cb-codetizer' ),
					esc_html__( 'Remove javascript: URLs. Use proper event binding instead.', 'cb-codetizer' ),
					$line
				);
			}

			// vbscript: URLs.
			if ( preg_match( '/vbscript\s*:/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'vbscript_url',
					'high',
					$ln,
					$m[0][1] + 1,
					esc_html__( 'vbscript: URL scheme detected — potential XSS.', 'cb-codetizer' ),
					esc_html__( 'Remove vbscript: URLs.', 'cb-codetizer' ),
					$line
				);
			}

			// iframe/embed/object tags.
			if ( preg_match( '/<(iframe|embed|object)\b/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'embedded_content',
					'medium',
					$ln,
					$m[0][1] + 1,
					sprintf(
						/* translators: %s: Tag name */
						esc_html__( '<%s> tag detected — potential for embedded malicious content.', 'cb-codetizer' ),
						esc_html( $m[1][0] )
					),
					esc_html__( 'Verify the src attribute. Consider adding the sandbox attribute to iframes.', 'cb-codetizer' ),
					$line
				);
			}

			// data: URLs.
			if ( preg_match( '/data\s*:\s*[a-zA-Z0-9+\-]+\/[a-zA-Z0-9+\-]+/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'data_uri',
					'medium',
					$ln,
					$m[0][1] + 1,
					esc_html__( 'data: URI detected — can be used to embed executable content.', 'cb-codetizer' ),
					esc_html__( 'Validate and whitelist allowed data URI MIME types.', 'cb-codetizer' ),
					$line
				);
			}

			// <foreignObject> — can smuggle arbitrary HTML (including event
			// handlers and <script>) inside SVG embedded in an HTML document.
			if ( preg_match( '/<foreignObject\b/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'foreign_object',
					'high',
					$ln,
					$m[0][1] + 1,
					esc_html__( '<foreignObject> detected — can smuggle arbitrary HTML/script inside SVG.', 'cb-codetizer' ),
					esc_html__( 'Remove <foreignObject> or ensure its content is fully trusted and static.', 'cb-codetizer' ),
					$line
				);
			}

			// <set>/<animate> attribute-value injection: attributeName set to
			// an event-handler-like name (e.g. attributeName="onload") is a
			// known SVG XSS technique distinct from the begin="...click"
			// variant checked in inspect_svg().
			if ( preg_match( '/<(set|animate\w*)\b[^>]*\battributeName\s*=\s*["\x27]\s*on\w+/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'svg_attribute_injection',
					'high',
					$ln,
					$m[0][1] + 1,
					sprintf(
						/* translators: %s: Matched tag name */
						esc_html__( '<%s> targeting an event-handler attribute name detected — potential XSS.', 'cb-codetizer' ),
						esc_html( $m[1][0] )
					),
					esc_html__( 'Remove SVG animation elements that target on* attribute names.', 'cb-codetizer' ),
					$line
				);
			}

			// Inline styles with expression/behavior.
			if ( preg_match( '/style\s*=\s*["\x27][^"\x27]*(expression|behavior|\-moz\-binding)/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'dangerous_css_inline',
					'medium',
					$ln,
					$m[0][1] + 1,
					sprintf(
						/* translators: %s: The dangerous CSS property found */
						esc_html__( 'Inline style with dangerous CSS property %s detected.', 'cb-codetizer' ),
						esc_html( $m[1][0] )
					),
					esc_html__( 'Remove expression(), behavior, and -moz-binding from inline styles.', 'cb-codetizer' ),
					$line
				);
			}

			// <base> tag.
			if ( preg_match( '/<base\b/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'base_tag',
					'low',
					$ln,
					$m[0][1] + 1,
					esc_html__( '<base> tag detected — can alter relative URL resolution.', 'cb-codetizer' ),
					esc_html__( 'Verify the href attribute points to a trusted origin.', 'cb-codetizer' ),
					$line
				);
			}

			// <meta> refresh redirects.
			if ( preg_match( '/<meta[^>]+http\-equiv\s*=\s*["\x27]?refresh/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'meta_refresh',
					'low',
					$ln,
					$m[0][1] + 1,
					esc_html__( '<meta http-equiv="refresh"> detected — potential redirect abuse.', 'cb-codetizer' ),
					esc_html__( 'Ensure the redirect URL is safe or use server-side redirects.', 'cb-codetizer' ),
					$line
				);
			}

			// Missing alt on images.
			if ( preg_match( '/<img\b(?![^>]*\balt\s*=)/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'missing_alt',
					'info',
					$ln,
					$m[0][1] + 1,
					esc_html__( '<img> tag without alt attribute — accessibility concern.', 'cb-codetizer' ),
					esc_html__( 'Add a descriptive alt attribute to all <img> tags.', 'cb-codetizer' ),
					$line
				);
			}
		}

		return $threats;
	}

	/**
	 * Inspect SVG code.
	 *
	 * @param string[] $lines Array of code lines.
	 * @return array[]
	 */
	private function inspect_svg( array $lines ): array {
		$threats = array();

		$event_handlers = '/\bon(click|error|load|mouseover|mouseout|mousedown|mouseup|focus|blur|begin|end|repeat)\s*=\s*["\x27]/i';

		foreach ( $lines as $ln => $line ) {
			$ln++;

			// on* event handlers in SVG.
			if ( preg_match( $event_handlers, $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'svg_event_handler',
					'high',
					$ln,
					$m[0][1] + 1,
				sprintf(
						/* translators: %s: Matched event handler */
						esc_html__( 'SVG inline event handler %s detected.', 'cb-codetizer' ),
						esc_html( trim( $m[0][0] ) )
					),
					esc_html__( 'Remove inline event handlers from SVG elements.', 'cb-codetizer' ),
					$line
				);
			}

			// <script> in SVG.
			if ( preg_match( '/<script\b/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'svg_script',
					'high',
					$ln,
					$m[0][1] + 1,
					esc_html__( '<script> tag inside SVG — potential XSS.', 'cb-codetizer' ),
					esc_html__( 'Remove script tags from SVG content.', 'cb-codetizer' ),
					$line
				);
			}

			// <foreignObject> — can smuggle arbitrary HTML/script into an
			// otherwise-graphics-only SVG document.
			if ( preg_match( '/<foreignObject\b/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'svg_foreign_object',
					'high',
					$ln,
					$m[0][1] + 1,
					esc_html__( '<foreignObject> detected — can smuggle arbitrary HTML/script inside SVG.', 'cb-codetizer' ),
					esc_html__( 'Remove <foreignObject> or ensure its content is fully trusted and static.', 'cb-codetizer' ),
					$line
				);
			}

			// javascript: in href or xlink:href.
			if ( preg_match( '/(?:href|xlink:href)\s*=\s*["\x27]?\s*javascript\s*:/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'svg_javascript_url',
					'high',
					$ln,
					$m[0][1] + 1,
					esc_html__( 'javascript: URL in SVG href/xlink:href — XSS vector.', 'cb-codetizer' ),
					esc_html__( 'Remove javascript: URLs from SVG attributes.', 'cb-codetizer' ),
					$line
				);
			}

			// External references via use/xlink:href to different domains.
			if ( preg_match( '/(?:href|xlink:href)\s*=\s*["\x27]?\s*(?:https?:)?\/\/[^"\x27\s>]+/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$url = trim( $m[0][0] );
				// Extract the URL portion.
				if ( preg_match( '/["\x27]?(https?:\/\/[^"\x27\s>]+)/i', $url, $url_match ) ) {
					$parsed = wp_parse_url( $url_match[1] );
					$site_url = wp_parse_url( home_url() );
					if ( isset( $parsed['host'] ) && isset( $site_url['host'] ) && $parsed['host'] !== $site_url['host'] ) {
						$threats[] = $this->make_threat(
							'svg_external_reference',
							'medium',
							$ln,
							$m[0][1] + 1,
							sprintf(
								/* translators: %s: External host */
								esc_html__( 'SVG external reference to %s — verify trust.', 'cb-codetizer' ),
								esc_html( $parsed['host'] )
							),
							esc_html__( 'Validate all external SVG references against a whitelist.', 'cb-codetizer' ),
							$line
						);
					}
				}
			}

			// <set>/<animate> targeting an on* attribute name — a distinct
			// SVG XSS technique from the begin="...click" variant below
			// (the injected value becomes a live event-handler attribute).
			if ( preg_match( '/<(set|animate\w*)\b[^>]*\battributeName\s*=\s*["\x27]\s*on\w+/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'svg_attribute_injection',
					'high',
					$ln,
					$m[0][1] + 1,
					sprintf(
						/* translators: %s: Matched tag name */
						esc_html__( '<%s> targeting an event-handler attribute name detected — potential XSS.', 'cb-codetizer' ),
						esc_html( $m[1][0] )
					),
					esc_html__( 'Remove SVG animation elements that target on* attribute names.', 'cb-codetizer' ),
					$line
				);
			}

			// <set>/<animate> with event-based begin.
			if ( preg_match( '/<(set|animate)\b[^>]*\bbegin\s*=\s*["\x27]?[^"\x27]*(?:click|mouseover|focus|load)/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'svg_event_animation',
					'medium',
					$ln,
					$m[0][1] + 1,
				sprintf(
						/* translators: %s: Element name */
						esc_html__( '<%s> with event-based begin attribute — potential trigger abuse.', 'cb-codetizer' ),
						esc_html( $m[1][0] )
					),
					esc_html__( 'Review animation event triggers for safety.', 'cb-codetizer' ),
					$line
				);
			}

			// data: URIs.
			if ( preg_match( '/data\s*:\s*[a-zA-Z0-9+\-]+\/[a-zA-Z0-9+\-]+/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'svg_data_uri',
					'low',
					$ln,
					$m[0][1] + 1,
					esc_html__( 'data: URI in SVG — can embed executable content.', 'cb-codetizer' ),
					esc_html__( 'Validate data URI MIME types.', 'cb-codetizer' ),
					$line
				);
			}
		}

		return $threats;
	}

	/**
	 * Inspect CSS code.
	 *
	 * @param string[] $lines Array of code lines.
	 * @return array[]
	 */
	private function inspect_css( array $lines ): array {
		$threats = array();

		foreach ( $lines as $ln => $line ) {
			$ln++;

			// expression().
			if ( preg_match( '/expression\s*\(/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'css_expression',
					'high',
					$ln,
					$m[0][1] + 1,
					esc_html__( 'CSS expression() detected — allows JavaScript execution in CSS.', 'cb-codetizer' ),
					esc_html__( 'Remove expression() and use standard CSS properties.', 'cb-codetizer' ),
					$line
				);
			}

			// -moz-binding.
			if ( preg_match( '/\-moz\-binding\s*:/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'css_moz_binding',
					'high',
					$ln,
					$m[0][1] + 1,
					esc_html__( '-moz-binding detected — can load remote XBL and execute code.', 'cb-codetizer' ),
					esc_html__( 'Remove -moz-binding property.', 'cb-codetizer' ),
					$line
				);
			}

			// @import.
			if ( preg_match( '/@import\s/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'css_import',
					'medium',
					$ln,
					$m[0][1] + 1,
					esc_html__( '@import detected — potential for loading external malicious stylesheets.', 'cb-codetizer' ),
					esc_html__( 'Verify @import URLs or use <link> tags instead.', 'cb-codetizer' ),
					$line
				);
			}

			// url() with javascript:/data:.
			if ( preg_match( '/url\s*\(\s*["\x27]?\s*(?:javascript|data)\s*:/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'css_dangerous_url',
					'high',
					$ln,
					$m[0][1] + 1,
					esc_html__( 'url() with javascript: or data: scheme in CSS.', 'cb-codetizer' ),
					esc_html__( 'Remove dangerous URL schemes from CSS url() functions.', 'cb-codetizer' ),
					$line
				);
			}

			// behavior property.
			if ( preg_match( '/behavior\s*:/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'css_behavior',
					'medium',
					$ln,
					$m[0][1] + 1,
					esc_html__( 'behavior property detected — IE-specific, can load HTC files.', 'cb-codetizer' ),
					esc_html__( 'Remove the behavior property.', 'cb-codetizer' ),
					$line
				);
			}

			// @charset issues.
			if ( preg_match( '/@charset\s/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				if ( 1 !== $ln ) {
					$threats[] = $this->make_threat(
						'css_charset_position',
						'low',
						$ln,
						$m[0][1] + 1,
						esc_html__( '@charset must be the very first rule in the stylesheet.', 'cb-codetizer' ),
						esc_html__( 'Move @charset to the first line or remove it.', 'cb-codetizer' ),
						$line
					);
				}
			}
		}

		return $threats;
	}

	/**
	 * Inspect JavaScript code.
	 *
	 * @param string[] $lines Array of code lines.
	 * @return array[]
	 */
	private function inspect_javascript( array $lines ): array {
		$threats = array();

		foreach ( $lines as $ln => $line ) {
			$ln++;

			// eval().
			if ( preg_match( '/\beval\s*\(/', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'js_eval',
					'high',
					$ln,
					$m[0][1] + 1,
					esc_html__( 'eval() detected — arbitrary code execution risk.', 'cb-codetizer' ),
					esc_html__( 'Avoid eval(). Use JSON.parse() for data or Function() alternatives.', 'cb-codetizer' ),
					$line
				);
			}

			// document.write.
			if ( preg_match( '/document\.write\s*\(/', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'js_document_write',
					'high',
					$ln,
					$m[0][1] + 1,
					esc_html__( 'document.write() detected — can inject HTML into the DOM.', 'cb-codetizer' ),
					esc_html__( 'Use DOM manipulation methods (createElement, textContent) instead.', 'cb-codetizer' ),
					$line
				);
			}

			// innerHTML without sanitization context.
			if ( preg_match( '/\.innerHTML\s*=/', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'js_innerhtml',
					'high',
					$ln,
					$m[0][1] + 1,
					esc_html__( 'innerHTML assignment detected — XSS risk if value is user-controlled.', 'cb-codetizer' ),
					esc_html__( 'Use textContent or sanitize the value before assignment.', 'cb-codetizer' ),
					$line
				);
			}

			// Function() constructor.
			if ( preg_match( '/(?:^|[=(:,\s])\s*new\s+Function\s*\(/', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'js_function_constructor',
					'high',
					$ln,
					$m[0][1] + 1,
					esc_html__( 'new Function() constructor detected — similar risk to eval().', 'cb-codetizer' ),
					esc_html__( 'Avoid dynamic function creation. Use arrow functions or named functions.', 'cb-codetizer' ),
					$line
				);
			}

			// setTimeout/setInterval with string argument.
			if ( preg_match( '/\b(?:setTimeout|setInterval)\s*\(\s*["\x27]/', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'js_string_timer',
					'medium',
					$ln,
					$m[0][1] + 1,
					esc_html__( 'setTimeout/setInterval with string argument — implicit eval.', 'cb-codetizer' ),
					esc_html__( 'Pass a function reference instead of a string.', 'cb-codetizer' ),
					$line
				);
			}

			// Prototype pollution patterns.
			if ( preg_match( '/(?:__proto__|constructor\.prototype|\.prototype\[)/', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'js_prototype_pollution',
					'high',
					$ln,
					$m[0][1] + 1,
					esc_html__( 'Prototype pollution pattern detected.', 'cb-codetizer' ),
					esc_html__( 'Avoid modifying Object.prototype or __proto__. Use Object.create(null) for safe maps.', 'cb-codetizer' ),
					$line
				);
			}

			// DOM clobbering.
			if ( preg_match( '/(?:document\.forms\[|document\.images\[|document\.links\[|document\.anchors\[|document\.applets\[)/', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'js_dom_clobbering',
					'medium',
					$ln,
					$m[0][1] + 1,
					esc_html__( 'Potential DOM clobbering — named access to document collections.', 'cb-codetizer' ),
					esc_html__( 'Use getElementById or querySelector instead of named collection access.', 'cb-codetizer' ),
					$line
				);
			}

			// postMessage without origin check (heuristic: postMessage on same line without event.origin or '*').
			if ( preg_match( '/\.postMessage\s*\(/', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				if ( ! preg_match( '/event\.(?:origin|source)/i', $line ) && ! preg_match( '/\*\s*,/i', $line ) ) {
					// Only flag if this line doesn't already check the origin.
					$threats[] = $this->make_threat(
						'js_postmessage',
						'medium',
						$ln,
						$m[0][1] + 1,
						esc_html__( 'postMessage() without visible origin check — verify origin validation.', 'cb-codetizer' ),
						esc_html__( 'Always verify event.origin in the message event handler.', 'cb-codetizer' ),
						$line
					);
				}
			}

			// window.location manipulation.
			if ( preg_match( '/(?:window\.location(?:\.href|\.assign|\.replace)?|location\.href|location\.assign|location\.replace)\s*=/', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'js_location_manipulation',
					'medium',
					$ln,
					$m[0][1] + 1,
					esc_html__( 'window.location manipulation detected — open redirect risk.', 'cb-codetizer' ),
					esc_html__( 'Validate URLs before assigning to location properties.', 'cb-codetizer' ),
					$line
				);
			}

			// .exec() (RegExp or child_process).
			if ( preg_match( '/\.(?:exec)\s*\(/', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				// Skip if it's clearly a RegExp exec on a known regex variable.
				if ( ! preg_match( '/regex|regexp|re\./i', $line ) ) {
					$threats[] = $this->make_threat(
						'js_exec',
						'low',
						$ln,
						$m[0][1] + 1,
						esc_html__( '.exec() call detected — review for safety.', 'cb-codetizer' ),
						esc_html__( 'Ensure .exec() is not used to execute shell commands.', 'cb-codetizer' ),
						$line
					);
				}
			}
		}

		return $threats;
	}

	/**
	 * Inspect PHP code.
	 *
	 * @param string[] $lines   Array of code lines.
	 * @param string   $profile Scan profile ('standard' or 'strict') — passed
	 *                          through to the Pattern Repository so 'strict'
	 *                          can surface additional PHP rules if/when any
	 *                          are tagged strict-only (none are as of this
	 *                          writing — 'strict' and 'standard' currently
	 *                          produce identical PHP results — but the
	 *                          plumbing is real and will pick up future
	 *                          strict-only PHP rules without further changes).
	 * @return array[]
	 */
	private function inspect_php( array $lines, string $profile = 'standard' ): array {
		$threats = array();

		// Fetch all PHP inspector rules from the Pattern Repository.
		// PHP function names are case-insensitive, so the repository patterns
		// include the /i modifier — this ensures EvAl(), SYSTEM(), etc. are
		// detected. The rule definitions also carry the threat type IDs,
		// severities, descriptions, and recommendations that make_threat() needs.
		$rules = CB_Codetizer_Pattern_Repository::get_rules_for_language( 'php', $profile );

		foreach ( $lines as $ln => $line ) {
			$ln++;

			foreach ( $rules as $rule_id => $rule ) {
				$pattern = $rule['pattern'] ?? '';
				if ( '' === $pattern ) {
					continue;
				}

				if ( preg_match( $pattern, $line, $m, PREG_OFFSET_CAPTURE ) ) {
					// Determine the threat type ID from the rule.
					// Map repository rule IDs to the legacy threat type IDs
					// that existing consumers (JS, reports) expect.
					$threat_type = $rule['sanitizer_type'] ?? str_replace( '.', '_', $rule_id );

					// Build the description. For rules with capture groups
					// (like command_execution which captures the function name),
					// format the description with the captured value.
					$description = $rule['description'] ?? $rule_id;
					if ( isset( $m[1][0] ) && false !== strpos( $description, '%s' ) ) {
						$description = sprintf( $description, $m[1][0] );
					}

					$threats[] = $this->make_threat(
						$threat_type,
						$rule['severity'] ?? 'medium',
						$ln,
						$m[0][1] + 1,
						esc_html( $description ),
						esc_html( $rule['recommendation'] ?? '' ),
						$line
					);
				}
			}
		}

		return $threats;
	}

	/**
	 * Inspect JSON code.
	 *
	 * @param string   $code  Full JSON string.
	 * @param string[] $lines Array of code lines.
	 * @return array[]
	 */
	private function inspect_json( string $code, array $lines ): array {
		$threats = array();

		// Validate JSON.
		$decoded = json_decode( $code );
		if ( null === $decoded && JSON_ERROR_NONE !== json_last_error() ) {
			$threats[] = $this->make_threat(
				'json_invalid',
				'medium',
				1,
				1,
				esc_html__( 'Invalid JSON syntax detected.', 'cb-codetizer' ),
				esc_html__( 'Fix the JSON syntax errors.', 'cb-codetizer' ),
				$lines[0] ?? ''
			);
			return $threats;
		}

		foreach ( $lines as $ln => $line ) {
			$ln++;

			// Prototype pollution keys.
			if ( preg_match( '/"(?:__proto__|constructor|prototype)"\s*:/', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'json_prototype_pollution',
					'high',
					$ln,
					$m[0][1] + 1,
				sprintf(
						/* translators: %s: Key name */
						esc_html__( 'Prototype pollution key "%s" found in JSON.', 'cb-codetizer' ),
						esc_html( $m[1][0] )
					),
					esc_html__( 'Remove __proto__, constructor, and prototype keys from JSON data.', 'cb-codetizer' ),
					$line
				);
			}

			// Deep nesting (heuristic: count indentation depth).
			$indent = strlen( $line ) - strlen( ltrim( $line ) );
			if ( $indent > 40 ) {
				$threats[] = $this->make_threat(
					'json_deep_nesting',
					'medium',
					$ln,
					$indent + 1,
					esc_html__( 'Very deep nesting detected — potential DoS via recursive parsing.', 'cb-codetizer' ),
					esc_html__( 'Flatten the JSON structure or validate maximum nesting depth.', 'cb-codetizer' ),
					$line
				);
			}
		}

		return $threats;
	}

	/**
	 * Inspect XML code.
	 *
	 * @param string[] $lines Array of code lines.
	 * @return array[]
	 */
	private function inspect_xml( array $lines ): array {
		$threats = array();
		$in_doctype = false;

		foreach ( $lines as $ln => $line ) {
			$ln++;

			// XXE patterns (<!ENTITY).
			if ( preg_match( '/<!ENTITY\s/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'xml_xxe',
					'high',
					$ln,
					$m[0][1] + 1,
					esc_html__( 'ENTITY declaration detected — potential XML External Entity (XXE) attack.', 'cb-codetizer' ),
					esc_html__( 'Disable external entity processing. Use a non-validating parser with LIBXML_NOENT disabled.', 'cb-codetizer' ),
					$line
				);
			}

			// External DTD.
			if ( preg_match( '/<!DOCTYPE\s[^>]*\bSYSTEM\s/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'xml_external_dtd',
					'medium',
					$ln,
					$m[0][1] + 1,
					esc_html__( 'External DTD reference (SYSTEM) detected.', 'cb-codetizer' ),
					esc_html__( 'Remove external DTD references or validate them against a whitelist.', 'cb-codetizer' ),
					$line
				);
			}

			// XSLT with script.
		if ( preg_match( '/<(?:xsl|msxsl):script\b/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'xml_xslt_script',
					'high',
					$ln,
					$m[0][1] + 1,
					esc_html__( 'XSLT script block detected — code execution risk.', 'cb-codetizer' ),
					esc_html__( 'Remove script blocks from XSLT stylesheets.', 'cb-codetizer' ),
					$line
				);
			}

			// XInclude.
			if ( preg_match( '/<(?:xi|xi:)include\b/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'xml_xinclude',
					'medium',
					$ln,
					$m[0][1] + 1,
					esc_html__( 'XInclude directive detected — potential for including external content.', 'cb-codetizer' ),
					esc_html__( 'Disable XInclude processing or validate include sources.', 'cb-codetizer' ),
					$line
				);
			}
		}

		return $threats;
	}

	/**
	 * Inspect Markdown code.
	 *
	 * @param string[] $lines Array of code lines.
	 * @return array[]
	 */
	private function inspect_markdown( array $lines ): array {
		$threats = array();

		foreach ( $lines as $ln => $line ) {
			$ln++;

			// Raw HTML tags in markdown.
			if ( preg_match( '/<(?!\/?[a-zA-Z]+\s*\/?>)([a-zA-Z][a-zA-Z0-9]*)\b[^>]*>/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$tag = strtolower( $m[1][0] );
				$allowed_tags = array( 'br', 'hr', 'p', 'div', 'span', 'strong', 'em', 'b', 'i', 'a', 'ul', 'ol', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'img', 'code', 'pre', 'blockquote', 'table', 'thead', 'tbody', 'tr', 'th', 'td' );
				if ( ! in_array( $tag, $allowed_tags, true ) ) {
					$threats[] = $this->make_threat(
						'markdown_html_injection',
						'high',
						$ln,
						$m[0][1] + 1,
						sprintf(
							/* translators: %s: HTML tag name */
							esc_html__( 'HTML tag <%s> in Markdown — potential injection.', 'cb-codetizer' ),
							esc_html( $tag )
						),
							esc_html__( 'Remove raw HTML from Markdown or sanitize allowed tags.', 'cb-codetizer' ),
						$line
					);
				}
			}

			// Script tags in markdown.
			if ( preg_match( '/<script\b/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'markdown_script',
					'high',
					$ln,
					$m[0][1] + 1,
					esc_html__( '<script> tag in Markdown — XSS vector.', 'cb-codetizer' ),
					esc_html__( 'Remove script tags from Markdown content.', 'cb-codetizer' ),
					$line
				);
			}

			// data: URLs in markdown.
			if ( preg_match( '/\]\(\s*data\s*:/i', $line, $m, PREG_OFFSET_CAPTURE ) ) {
				$threats[] = $this->make_threat(
					'markdown_data_url',
					'medium',
					$ln,
					$m[0][1] + 1,
					esc_html__( 'data: URL in Markdown link — potential executable content.', 'cb-codetizer' ),
					esc_html__( 'Use proper URLs instead of data: URIs.', 'cb-codetizer' ),
					$line
				);
			}
		}

		return $threats;
	}

	/**
	 * Build a standardized threat descriptor array.
	 *
	 * The snippet is HTML-escaped at this point so that the threat data is
	 * safe to echo in any context (admin template, REST response, CSV
	 * column, debug log) without requiring every consumer to remember to
	 * call esc_html(). Consumers that insert the snippet into an HTML
	 * <code> or <pre> element should use textContent or echo it directly
	 * WITHOUT an additional escaping layer, otherwise the entity will be
	 * double-escaped (e.g. &lt;script&gt; becomes &amp;lt;script&amp;gt;).
	 *
	 * @param string $type           Threat type identifier.
	 * @param string $severity       Severity level (high/medium/low/info).
	 * @param int    $line           1-based line number.
	 * @param int    $column         1-based column number.
	 * @param string $description    Human-readable description.
	 * @param string $recommendation Actionable recommendation.
	 * @param string $snippet        The original code line (raw).
	 * @return array Standardized threat array.
	 */
	private function make_threat( string $type, string $severity, int $line, int $column, string $description, string $recommendation, string $snippet ): array {
		return array(
			'type'           => $type,
			'severity'       => $severity,
			'line'           => $line,
			'column'         => $column,
			'description'    => $description,
			'recommendation' => $recommendation,
			'snippet'        => esc_html( $snippet ),
		);
	}
}
