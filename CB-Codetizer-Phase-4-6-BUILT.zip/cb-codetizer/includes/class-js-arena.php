<?php
/**
 * CB CODETIZER - JS Arena / Code Manager.
 *
 * Owns reusable code items independently of Elementor. Items may target
 * global output, header, footer, a specific WordPress page, or Elementor.
 *
 * @package CB_Codetizer
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class CB_Codetizer_JS_Arena {
    public const POST_TYPE = 'cb_code_item';

    public function __construct() {
        add_action( 'init', array( $this, 'register_post_type' ) );
        add_action( 'add_meta_boxes', array( $this, 'register_meta_box' ) );
        add_action( 'save_post_' . self::POST_TYPE, array( $this, 'save_meta' ), 10, 2 );
        add_action( 'wp_head', array( $this, 'render_head' ), 99 );
        add_action( 'wp_footer', array( $this, 'render_footer' ), 99 );
        add_action( 'admin_post_cb_codetizer_arena_save', array( $this, 'handle_save' ) );
        add_action( 'admin_post_cb_codetizer_arena_delete', array( $this, 'handle_delete' ) );
        add_action( 'admin_post_cb_codetizer_arena_sync_elementor', array( $this, 'handle_sync_elementor' ) );
    }

    public static function meta_keys(): array {
        return array( 'language', 'html', 'css', 'javascript', 'target', 'target_page', 'elementor_post', 'enabled' );
    }

    public function register_post_type(): void {
        register_post_type( self::POST_TYPE, array(
            'labels' => array(
                'name' => __( 'JS Arena', 'cb-codetizer' ),
                'singular_name' => __( 'JS Arena Item', 'cb-codetizer' ),
                'add_new_item' => __( 'Create Code Item', 'cb-codetizer' ),
                'edit_item' => __( 'Edit Code Item', 'cb-codetizer' ),
            ),
            'public' => false,
            'show_ui' => false,
            'show_in_menu' => false,
            'show_in_rest' => false,
            'supports' => array( 'title' ),
            'capability_type' => array( 'cb_code_item', 'cb_code_items' ),
            'map_meta_cap' => true,
        ) );
    }

    public function register_meta_box(): void {
        add_meta_box( 'cb-codetizer-arena-meta', __( 'JS Arena Code', 'cb-codetizer' ), array( $this, 'render_meta_box' ), self::POST_TYPE, 'normal', 'high' );
    }

    public function render_meta_box( WP_Post $post ): void {
        wp_nonce_field( 'cb_codetizer_arena_meta', 'cb_codetizer_arena_meta_nonce' );
        foreach ( self::meta_keys() as $key ) {
            $value = get_post_meta( $post->ID, '_cb_arena_' . $key, true );
            if ( is_scalar( $value ) ) {
                printf( '<input type="hidden" name="cb_arena_%s" value="%s" />', esc_attr( $key ), esc_attr( (string) $value ) );
            }
        }
        echo '<p>' . esc_html__( 'Managed from the CB Codetizer → JS Arena screen.', 'cb-codetizer' ) . '</p>';
    }

    public function save_meta( int $post_id, WP_Post $post ): void {
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) { return; }
        if ( ! current_user_can( 'manage_options' ) ) { return; }
        if ( ! isset( $_POST['cb_codetizer_arena_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['cb_codetizer_arena_meta_nonce'] ) ), 'cb_codetizer_arena_meta' ) ) { return; }
        foreach ( self::meta_keys() as $key ) {
            if ( isset( $_POST[ 'cb_arena_' . $key ] ) ) {
                update_post_meta( $post_id, '_cb_arena_' . $key, wp_unslash( $_POST[ 'cb_arena_' . $key ] ) );
            }
        }
    }

    public function handle_save(): void {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( esc_html__( 'Permission denied.', 'cb-codetizer' ), 403 ); }
        check_admin_referer( 'cb_codetizer_arena_save', 'cb_codetizer_arena_nonce' );
        $id = isset( $_POST['item_id'] ) ? absint( $_POST['item_id'] ) : 0;
        $title = isset( $_POST['name'] ) ? sanitize_text_field( wp_unslash( $_POST['name'] ) ) : '';
        if ( '' === $title ) { $title = __( 'Untitled Code', 'cb-codetizer' ); }
        $postarr = array( 'post_type' => self::POST_TYPE, 'post_status' => 'publish', 'post_title' => $title );
        if ( $id ) { $postarr['ID'] = $id; }
        $post_id = wp_insert_post( $postarr, true );
        if ( is_wp_error( $post_id ) ) { wp_die( esc_html( $post_id->get_error_message() ), 500 ); }

        $fields = array(
            'language' => isset( $_POST['language'] ) ? sanitize_key( wp_unslash( $_POST['language'] ) ) : 'html',
            'html' => isset( $_POST['html'] ) ? wp_unslash( $_POST['html'] ) : '',
            'css' => isset( $_POST['css'] ) ? wp_unslash( $_POST['css'] ) : '',
            'javascript' => isset( $_POST['javascript'] ) ? wp_unslash( $_POST['javascript'] ) : '',
            'target' => isset( $_POST['target'] ) ? sanitize_key( wp_unslash( $_POST['target'] ) ) : 'global',
            'target_page' => isset( $_POST['target_page'] ) ? absint( $_POST['target_page'] ) : 0,
            'elementor_post' => isset( $_POST['elementor_post'] ) ? absint( $_POST['elementor_post'] ) : 0,
            'enabled' => ! empty( $_POST['enabled'] ) ? '1' : '0',
        );
        if ( 'elementor' === $fields['target'] && $fields['elementor_post'] ) {
            $fields['target_page'] = $fields['elementor_post'];
        }
        foreach ( $fields as $key => $value ) { update_post_meta( $post_id, '_cb_arena_' . $key, $value ); }

        wp_safe_redirect( admin_url( 'admin.php?page=cb-codetizer-js-arena&item=' . $post_id . '&saved=1' ) );
        exit;
    }

    public function handle_delete(): void {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( esc_html__( 'Permission denied.', 'cb-codetizer' ), 403 ); }
        check_admin_referer( 'cb_codetizer_arena_delete', 'cb_codetizer_arena_nonce' );
        $id = isset( $_POST['item_id'] ) ? absint( $_POST['item_id'] ) : 0;
        if ( $id ) { wp_delete_post( $id, true ); }
        wp_safe_redirect( admin_url( 'admin.php?page=cb-codetizer-js-arena&deleted=1' ) );
        exit;
    }

    public function handle_sync_elementor(): void {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( esc_html__( 'Permission denied.', 'cb-codetizer' ), 403 ); }
        check_admin_referer( 'cb_codetizer_arena_sync_elementor', 'cb_codetizer_arena_nonce' );
        $item_id = isset( $_POST['item_id'] ) ? absint( $_POST['item_id'] ) : 0;
        $post_id = isset( $_POST['elementor_post'] ) ? absint( $_POST['elementor_post'] ) : 0;
        if ( ! class_exists( 'CB_Codetizer_Elementor_Integration' ) ) { wp_die( esc_html__( 'Elementor integration is not loaded. Activate Elementor and try again.', 'cb-codetizer' ), 409 ); }
        $item = $this->get_item( $item_id );
        if ( ! $item || ! $post_id ) { wp_die( esc_html__( 'Code item or Elementor page is missing.', 'cb-codetizer' ), 400 ); }
        $service = new CB_Codetizer_Elementor_Integration( new CB_Codetizer_Backups() );
        $result = $service->apply_arena_item( $post_id, $item, true );
        if ( is_wp_error( $result ) ) { wp_die( esc_html( $result->get_error_message() ), 500 ); }
        wp_safe_redirect( admin_url( 'admin.php?page=cb-codetizer-js-arena&item=' . $item_id . '&synced=1' ) );
        exit;
    }

    public function get_item( int $id ): ?array {
        $post = get_post( $id );
        if ( ! $post || self::POST_TYPE !== $post->post_type ) { return null; }
        $item = array( 'id' => $id, 'name' => $post->post_title );
        foreach ( self::meta_keys() as $key ) { $item[ $key ] = get_post_meta( $id, '_cb_arena_' . $key, true ); }
        return $item;
    }

    public function get_items(): array {
        $posts = get_posts( array( 'post_type' => self::POST_TYPE, 'post_status' => 'publish', 'posts_per_page' => -1, 'orderby' => 'modified', 'order' => 'DESC' ) );
        $items = array();
        foreach ( $posts as $post ) { $items[] = $this->get_item( $post->ID ); }
        return array_values( array_filter( $items ) );
    }

    public function render_head(): void {
        if ( is_admin() ) { return; }
        foreach ( $this->matching_items( 'head' ) as $item ) {
            if ( '' !== trim( (string) $item['css'] ) ) { echo "\n<style data-cb-codetizer=\"" . esc_attr( $item['id'] ) . "\">" . $this->safe_css( $item['css'] ) . "</style>\n"; }
            if ( '' !== trim( (string) $item['html'] ) && 'global' === $item['target'] ) { echo "\n" . wp_kses_post( $item['html'] ) . "\n"; }
        }
    }

    public function render_footer(): void {
        if ( is_admin() ) { return; }
        foreach ( $this->matching_items( 'footer' ) as $item ) {
            if ( '' !== trim( (string) $item['html'] ) ) { echo "\n" . wp_kses_post( $item['html'] ) . "\n"; }
            if ( '' !== trim( (string) $item['javascript'] ) ) { echo "\n<script data-cb-codetizer=\"" . esc_attr( $item['id'] ) . "\">\n" . $this->safe_js( $item['javascript'] ) . "\n</script>\n"; }
        }
    }

    private function matching_items( string $position ): array {
        $items = $this->get_items();
        $out = array();
        $page_id = get_queried_object_id();
        foreach ( $items as $item ) {
            if ( '1' !== (string) $item['enabled'] ) { continue; }
            $target = (string) $item['target'];
            if ( 'global' === $target && 'head' === $position ) { $out[] = $item; continue; }
            if ( 'header' === $target && 'head' === $position ) { $out[] = $item; continue; }
            if ( 'footer' === $target && 'footer' === $position ) { $out[] = $item; continue; }
            if ( 'page' === $target && (int) $item['target_page'] === (int) $page_id ) { $out[] = $item; continue; }
        }
        return $out;
    }

    private function safe_css( string $css ): string { return preg_replace( '/<\/?style[^>]*>/i', '', $css ) ?? ''; }
    private function safe_js( string $js ): string { return preg_replace( '/<\/?script[^>]*>/i', '', $js ) ?? ''; }
}
