<?php
/**
 * CB CODETIZER - CSV Export
 *
 * Generates CSV files from report data for download.
 * Uses php://temp and fputcsv for proper escaping.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CB_Codetizer_CSV_Export
 *
 * Produces a UTF-8 BOM–prefixed CSV from an array of report
 * objects and can send it directly as a file download.
 */
class CB_Codetizer_CSV_Export {

	/**
	 * Column headers for the CSV output.
	 *
	 * @var string[]
	 */
	private array $columns = array(
		'ID',
		'Type',
		'Language',
		'Input Summary',
		'Threats Found',
		'Severity Summary',
		'Date',
	);

	/**
	 * Generate CSV content from an array of report objects.
	 *
	 * Includes a UTF-8 BOM (﻿) so that Excel on Windows
	 * correctly detects the encoding.
	 *
	 * @param array<int, object> $reports Array of report row objects.
	 * @return string The complete CSV content.
	 */
	public function generate( array $reports ): string {
		// php://temp stores in memory until a configurable limit, then uses a temp file.
		$handle = fopen( 'php://temp', 'r+' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_fopen

		if ( false === $handle ) {
			return '';
		}

		// Write BOM for Excel UTF-8 compatibility.
		fwrite( $handle, "\xEF\xBB\xBF" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_fwrite

		// Write header row.
		fputcsv( $handle, $this->columns ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_fputcsv

		// Write data rows.
		foreach ( $reports as $report ) {
			// Normalise both WP report objects and array-shaped test/import data.
			// Production callers normally provide objects from CB_Codetizer_Reports,
			// but accepting arrays here makes the exporter safer to reuse and test.
			$id              = $this->get_report_value( $report, 'id' );
			$scan_type       = $this->get_report_value( $report, 'scan_type', 'type' );
			$language        = $this->get_report_value( $report, 'language' );
			$input_summary   = $this->get_report_value( $report, 'input_summary', 'content' );
			$threats_found   = $this->get_report_value( $report, 'threats_found' );
			$severity        = $this->get_report_value( $report, 'severity_summary', 'reason' );
			$created_at      = $this->get_report_value( $report, 'created_at', 'date' );

			$row = array(
				'' !== (string) $id ? (int) $id : '',
				$this->escape_csv_formula( sanitize_text_field( (string) $scan_type ) ),
				$this->escape_csv_formula( sanitize_text_field( (string) $language ) ),
				$this->escape_csv_formula( sanitize_textarea_field( (string) $input_summary ) ),
				'' !== (string) $threats_found ? (int) $threats_found : 0,
				$this->escape_csv_formula( sanitize_text_field( (string) $severity ) ),
				$this->escape_csv_formula( sanitize_text_field( (string) $created_at ) ),
			);

			fputcsv( $handle, $row ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_fputcsv
		}

		// Read the full content back.
		rewind( $handle );
		$csv = stream_get_contents( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_stream_get_contents

		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_fclose

		return ( false === $csv ) ? '' : $csv;
	}

	/**
	 * Read a report field from either an object or an associative array.
	 *
	 * @param object|array $report   Report row.
	 * @param string       $key      Preferred field name.
	 * @param string|null  $fallback Optional alternate field name.
	 * @return mixed
	 */
	private function get_report_value( $report, string $key, ?string $fallback = null ) {
		if ( is_array( $report ) ) {
			if ( array_key_exists( $key, $report ) ) {
				return $report[ $key ];
			}
			if ( null !== $fallback && array_key_exists( $fallback, $report ) ) {
				return $report[ $fallback ];
			}
			return '';
		}

		if ( is_object( $report ) ) {
			if ( isset( $report->{$key} ) ) {
				return $report->{$key};
			}
			if ( null !== $fallback && isset( $report->{$fallback} ) ) {
				return $report->{$fallback};
			}
		}

		return '';
	}

	/**
	 * Neutralize CSV/formula injection (CWE-1236).
	 *
	 * 'Input Summary' is a truncation of arbitrary, user-submitted code
	 * (see CB_Codetizer_Helpers::truncate() usage in class-ajax.php). If
	 * a scanned snippet happens to start with =, +, -, or @, some
	 * spreadsheet applications (notably Excel) will interpret that cell
	 * as a formula when the CSV is opened, which can lead to unwanted
	 * command/DDE execution on the machine that opens the export.
	 * Prefixing such values with a leading apostrophe is the standard,
	 * widely-recommended mitigation — it forces the cell to be treated
	 * as literal text while remaining valid, readable CSV content.
	 *
	 * Applied to every string column defensively; only 'Input Summary'
	 * is genuinely attacker-influenced, but the others cost nothing to
	 * cover as well.
	 *
	 * @param string $value Cell value.
	 * @return string
	 */
	private function escape_csv_formula( string $value ): string {
		if ( '' === $value ) {
			return $value;
		}

		if ( in_array( $value[0], array( '=', '+', '-', '@', "\t", "\r" ), true ) ) {
			return "'" . $value;
		}

		return $value;
	}

	/**
	 * Generate a CSV file and send it as a download.
	 *
	 * Sets the appropriate headers and outputs the CSV content,
	 * then terminates the request with wp_die().
	 *
	 * @param array<int, object> $reports  Array of report row objects.
	 * @param string              $filename Download file name. Default 'cb-codetizer-reports.csv'.
	 * @return void
	 */
	public function download( array $reports, string $filename = 'cb-codetizer-reports.csv' ): void {
		$sanitized_filename = sanitize_file_name( $filename );
		$csv_content       = $this->generate( $reports );

		if ( empty( $csv_content ) ) {
			wp_die(
				esc_html__( 'Failed to generate CSV export.', 'cb-codetizer' ),
				'',
				array( 'response' => 500 )
			);
		}

		$downloader = new CB_Codetizer_Download();
		$downloader->send_file( $csv_content, $sanitized_filename, 'text/csv; charset=utf-8' );
	}
}
