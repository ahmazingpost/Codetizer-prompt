<?php
/**
 * CB CODETIZER - Installer
 *
 * Handles plugin activation tasks: creating database tables
 * and setting default configuration options.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CB_Codetizer_Installer
 *
 * Manages the installation process including database table creation
 * and default option seeding.
 */
class CB_Codetizer_Installer {

	/**
	 * Plugin activation callback.
	 *
	 * Creates the required database tables and sets default options.
	 * Existing options are never overwritten.
	 *
	 * @return void
	 */
	public static function activate(): void {
		self::create_tables();
		self::set_default_options();
		self::register_capabilities();
		self::schedule_backup_cleanup();
	}

	public static function schema_version(): string {
		return '1.1.0';
	}

	public static function schedule_backup_cleanup(): void {
		if ( ! wp_next_scheduled( 'cb_codetizer_cleanup_backups' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'cb_codetizer_cleanup_backups' );
		}
	}

	public static function unschedule_backup_cleanup(): void {
		wp_clear_scheduled_hook( 'cb_codetizer_cleanup_backups' );
	}

	public static function register_capabilities(): void {
		$role = get_role( 'administrator' );
		if ( ! $role ) { return; }
		foreach ( array( 'cb_codetizer_use_tools', 'cb_codetizer_manage_settings', 'cb_codetizer_view_reports' ) as $cap ) {
			$role->add_cap( $cap );
		}
	}

	/**
	 * Create the custom database table for scan reports.
	 *
	 * Uses dbDelta() for safe, incremental schema updates.
	 * Running activate() again on an existing install is safe —
	 * dbDelta adds only the missing columns/indexes.
	 *
	 * @return void
	 */
	private static function create_tables(): void {
		global $wpdb;

		$table_name      = $wpdb->prefix . 'cb_codetizer_reports';
		$backup_table    = $wpdb->prefix . 'cb_codetizer_backups';
		$charset_collate = $wpdb->get_charset_collate();

		// NOTE: score column added in v1.0.0 to persist security scores per report.
		$sql = "CREATE TABLE {$table_name} (
id               bigint(20)   NOT NULL AUTO_INCREMENT,
scan_type        varchar(20)  NOT NULL,
language         varchar(20)  NOT NULL DEFAULT 'html',
input_summary    text         NOT NULL,
output_summary   text         DEFAULT NULL,
results          longtext     DEFAULT NULL,
threats_found    int(11)      NOT NULL DEFAULT 0,
severity_summary varchar(255) DEFAULT NULL,
score            smallint(3)  NOT NULL DEFAULT 100,
created_at       datetime     NOT NULL DEFAULT CURRENT_TIMESTAMP,
user_id          bigint(20)   NOT NULL DEFAULT 0,
PRIMARY KEY  (id),
KEY scan_type (scan_type),
KEY language (language),
KEY created_at (created_at),
KEY user_id (user_id)
) {$charset_collate};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );

		$backup_sql = "CREATE TABLE {$backup_table} (
id           bigint(20) NOT NULL AUTO_INCREMENT,
source_type  varchar(30) NOT NULL,
language     varchar(20) NOT NULL DEFAULT 'html',
content      longtext NOT NULL,
content_hash char(64) NOT NULL,
meta         longtext DEFAULT NULL,
created_at   datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
user_id      bigint(20) NOT NULL DEFAULT 0,
PRIMARY KEY (id),
KEY source_type (source_type),
KEY content_hash (content_hash),
KEY created_at (created_at),
KEY user_id (user_id)
) {$charset_collate};";
		dbDelta( $backup_sql );

		update_option( 'cb_codetizer_db_version', self::schema_version() );
	}

	/**
	 * Set default plugin options.
	 *
	 * Uses add_option() which does not overwrite existing values,
	 * ensuring user customizations are preserved on reactivation.
	 *
	 * @return void
	 */
	private static function set_default_options(): void {
		$defaults = array(
			'cb_codetizer_max_upload_size' => 2097152,
			'cb_codetizer_max_input_bytes'  => 5242880,
			'cb_codetizer_default_language' => 'html',
			'cb_codetizer_scan_profile'     => 'standard',
			'cb_codetizer_indent_size'      => 4,
			'cb_codetizer_indent_type'      => 'spaces',
			'cb_codetizer_db_version'       => self::schema_version(),
			'cb_codetizer_backup_retention_days' => 30,
		);

		foreach ( $defaults as $option_name => $default_value ) {
			add_option( $option_name, $default_value );
		}

		// Set a transient to signal that the plugin was just activated.
		set_transient( 'cb_codetizer_activated', 1, 30 );
	}

	/**
	 * Run any database upgrades needed between versions.
	 *
	 * Called on every page load when the stored DB version differs from
	 * the current plugin version. Safe to call repeatedly.
	 *
	 * @return void
	 */
	public static function maybe_upgrade(): void {
		$stored_version = get_option( 'cb_codetizer_db_version', '0' );

		if ( version_compare( $stored_version, self::schema_version(), '<' ) ) {
			// Re-running create_tables() via dbDelta() handles schema additions safely.
			self::create_tables();
			self::register_capabilities();
			self::schedule_backup_cleanup();
		}
	}
}
