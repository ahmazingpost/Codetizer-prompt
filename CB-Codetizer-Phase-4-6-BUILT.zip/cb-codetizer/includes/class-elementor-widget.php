<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
if ( ! class_exists( '\Elementor\Widget_Base' ) ) { return; }
class CB_Codetizer_Elementor_Widget extends \Elementor\Widget_Base {
    public function get_name() { return 'cb_codetizer_code'; }
    public function get_title() { return __( 'CB Codetizer Code', 'cb-codetizer' ); }
    public function get_icon() { return 'eicon-code'; }
    public function get_categories() { return array( 'basic' ); }
    protected function register_controls() {
        $this->start_controls_section( 'section_code', array( 'label' => __( 'Code', 'cb-codetizer' ) ) );
        $this->add_control( 'html_code', array( 'label' => __( 'HTML', 'cb-codetizer' ), 'type' => \Elementor\Controls_Manager::CODE, 'language' => 'html', 'rows' => 12 ) );
        $this->add_control( 'css_code', array( 'label' => __( 'CSS', 'cb-codetizer' ), 'type' => \Elementor\Controls_Manager::CODE, 'language' => 'css', 'rows' => 12 ) );
        $this->add_control( 'js_code', array( 'label' => __( 'JavaScript', 'cb-codetizer' ), 'type' => \Elementor\Controls_Manager::CODE, 'language' => 'javascript', 'rows' => 12 ) );
        $this->end_controls_section();
    }
    protected function render() {
        $s = $this->get_settings_for_display();
        if ( ! empty( $s['css_code'] ) ) { echo '<style>' . wp_strip_all_tags( $s['css_code'] ) . '</style>'; }
        if ( ! empty( $s['html_code'] ) ) { echo wp_kses_post( $s['html_code'] ); }
        if ( ! empty( $s['js_code'] ) ) { echo '<script>' . preg_replace( '/<\/?script[^>]*>/i', '', $s['js_code'] ) . '</script>'; }
    }
}
