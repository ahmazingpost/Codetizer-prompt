# CB CODETIZER — Phase 4–6 Combined Implementation

## Baseline

This increment starts from the supplied Phase 3 v1.0.8 FIXED package. The Phase 3 source is preserved; the new work is additive.

## Phase 4 — Reports / History / Backup / Safe Transformation

- Added `CB_Codetizer_Backups` with an independently queryable backup table.
- Every sanitize operation creates a backup before mutation. Failure to create the backup aborts sanitization.
- Added a declarative `CB_Codetizer_Threat_Transformer_Engine`.
- Only narrowly defined, proven transformations are performed before the existing sanitizer fallback.
- Every transformation is re-inspected. If the transformed output still contains threats, the transformation is discarded and the original input is passed to the existing sanitizer.
- Backups support explicit, confirmation-gated restore and pre-restore Inspector verification.
- Added a daily retention cleanup event with configurable retention days (30 by default).

## Phase 5 — Elementor Integration

- Added `CB_Codetizer_Elementor_Integration`.
- Elementor integration is conditionally bootstrapped only when Elementor is available.
- No automatic Elementor save hook is registered.
- `_elementor_data` is parsed as JSON and only explicit HTML/CSS/JS sub-fields are passed to the existing sanitizer.
- A backup is mandatory before Elementor sanitization.
- Sanitized Elementor JSON is persisted only when the caller explicitly requests `persist=true`.

## Phase 6 — Permissions / REST API

- Added three granular capabilities only:
  - `cb_codetizer_use_tools`
  - `cb_codetizer_manage_settings`
  - `cb_codetizer_view_reports`
- Existing administrators continue to work through the `manage_options` fallback.
- Added REST namespace `cb-codetizer/v1` with real permission callbacks.
- REST validation reuses the existing size-limit, language-validation, rate-limit, backup, inspector and sanitizer services.
- Non-administrator report visibility is restricted to the current user's reports.
- Added explicit backup restore and Elementor sanitization REST endpoints.

## Verification principle

The transformation engine never executes rule-provided PHP. New transformations are declarative data/actions only. If a safe transformation cannot be verified, the transformation is abandoned and the existing sanitizer remains responsible for neutralization.

## Release status

This is an implementation/development increment, not a claim that the Phase 4–6 production acceptance criteria are fully certified. The WordPress/Laragon integration suite must be run against the installed site before release packaging.
