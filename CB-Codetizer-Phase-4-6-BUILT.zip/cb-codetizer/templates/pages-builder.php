<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
$builder = new CB_Codetizer_Pages_Builder();
$pages = $builder->get_pages();
$page_id = isset( $_GET['page_id'] ) ? absint( $_GET['page_id'] ) : 0;
$selected_page = $page_id ? get_post( $page_id ) : null;
$draft = $page_id ? $builder->get_draft( $page_id ) : array( 'page_id' => 0, 'blocks' => array() );
$elements = array();
$elementor_available = class_exists( 'CB_Codetizer_Elementor_Integration' ) && ( new CB_Codetizer_Elementor_Integration( new CB_Codetizer_Backups() ) )->available();
if ( $selected_page && $elementor_available ) {
    $found = ( new CB_Codetizer_Elementor_Integration( new CB_Codetizer_Backups() ) )->discover_elements( $page_id );
    if ( ! is_wp_error( $found ) ) { $elements = $found; }
}
$block_by_element = array();
foreach ( $draft['blocks'] as $block ) { $block_by_element[ (string) $block['element_id'] ] = $block; }
?>
<div class="wrap cb-codetizer-wrap cb-pages-builder">
    <div class="cb-pb-header">
        <div>
            <div class="cb-pb-title-row"><h1>Pages Builder</h1><span class="cb-pb-pill">Elementor</span></div>
            <p>Build named HTML, CSS and JavaScript blocks against the real Elementor HTML widgets on a WordPress page.</p>
        </div>
        <a class="cb-codetizer-btn cb-codetizer-btn-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=cb-codetizer-pages-builder' ) ); ?>">+ Create / Select Page</a>
    </div>
    <?php if ( isset( $_GET['saved'] ) ) : ?><div class="notice notice-success is-dismissible"><p>Pages Builder draft saved.</p></div><?php endif; ?>
    <?php if ( isset( $_GET['sent'] ) ) : ?><div class="notice notice-success is-dismissible"><p>Sent to Elementor. Updated <?php echo absint( $_GET['updated'] ?? 0 ); ?> real HTML widget(s).</p></div><?php endif; ?>

    <div class="cb-pb-layout">
        <aside class="cb-codetizer-card cb-pb-pages">
            <div class="cb-pb-pages-top"><strong><?php echo count( $pages ); ?> Pages</strong><input id="cb-pb-search" class="cb-codetizer-input" type="search" placeholder="Search pages..."></div>
            <div id="cb-pb-page-list">
            <?php foreach ( $pages as $page ) : ?>
                <a class="cb-pb-page <?php echo $page_id === $page['id'] ? 'is-active' : ''; ?>" data-name="<?php echo esc_attr( strtolower( $page['name'] ) ); ?>" href="<?php echo esc_url( admin_url( 'admin.php?page=cb-codetizer-pages-builder&page_id=' . $page['id'] ) ); ?>">
                    <span><strong><?php echo esc_html( $page['name'] ); ?></strong><small><?php echo esc_html( ucfirst( $page['status'] ) . ' · ' . $page['language'] ); ?></small></span>
                    <em><?php echo $page['elementor'] ? 'Elementor' : 'WordPress'; ?></em>
                </a>
            <?php endforeach; ?>
            </div>
        </aside>

        <main class="cb-codetizer-card cb-pb-editor">
        <?php if ( ! $selected_page ) : ?>
            <div class="cb-pb-empty"><h2>Choose a WordPress page</h2><p>Select a page from the left. If it has Elementor data, Pages Builder will discover the <strong>actual Elementor HTML widgets</strong> and let you map code to their existing IDs.</p></div>
        <?php else : ?>
            <div class="cb-pb-editor-head">
                <div><h2><?php echo esc_html( $selected_page->post_title ?: '(Untitled page)' ); ?></h2><p>Page ID <?php echo (int) $page_id; ?> · <?php echo $elementor_available ? 'Elementor loaded' : 'Elementor unavailable'; ?></p></div>
                <div class="cb-pb-actions">
                    <a class="cb-codetizer-btn cb-codetizer-btn-secondary" target="_blank" href="<?php echo esc_url( get_edit_post_link( $page_id, '' ) ); ?>">Open WordPress Page</a>
                    <?php if ( $elementor_available ) : ?><a class="cb-codetizer-btn cb-codetizer-btn-secondary" target="_blank" href="<?php echo esc_url( admin_url( 'post.php?post=' . $page_id . '&action=elementor' ) ); ?>">Open Elementor</a><?php endif; ?>
                </div>
            </div>

            <?php if ( ! $elementor_available ) : ?><div class="notice notice-warning"><p>Elementor is not loaded. The draft can still be viewed, but discovery and Send to Elementor require Elementor.</p></div><?php endif; ?>
            <?php if ( ! $elements && $elementor_available ) : ?><div class="notice notice-info"><p>No existing Elementor HTML widgets were found. Add an <strong>HTML widget</strong> in Elementor, save the page, then return here. Pages Builder deliberately targets real existing HTML widgets rather than fake containers.</p></div><?php endif; ?>

            <form id="cb-pb-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="cb_codetizer_pages_builder_save">
                <input type="hidden" name="page_id" value="<?php echo (int) $page_id; ?>">
                <?php wp_nonce_field( 'cb_codetizer_pages_builder_save', 'cb_codetizer_pages_builder_nonce' ); ?>
                <div id="cb-pb-blocks">
                <?php foreach ( $draft['blocks'] as $index => $block ) : ?>
                    <section class="cb-pb-block" data-block-id="<?php echo esc_attr( $block['id'] ); ?>">
                        <div class="cb-pb-block-head"><div><button type="button" class="cb-pb-collapse" aria-expanded="true">▾</button><strong class="cb-pb-block-title"><?php echo esc_html( $block['name'] ); ?></strong><span class="cb-pb-target">HTML #<?php echo esc_html( $block['element_id'] ); ?></span></div><button type="button" class="cb-pb-remove">Remove</button></div>
                        <div class="cb-pb-block-body">
                            <input type="hidden" name="blocks[<?php echo $index; ?>][id]" value="<?php echo esc_attr( $block['id'] ); ?>">
                            <input type="hidden" name="blocks[<?php echo $index; ?>][element_id]" value="<?php echo esc_attr( $block['element_id'] ); ?>">
                            <input type="hidden" name="blocks[<?php echo $index; ?>][element_type]" value="<?php echo esc_attr( $block['element_type'] ); ?>">
                            <div class="cb-pb-meta-grid"><label>Name<input class="cb-codetizer-input cb-pb-name" name="blocks[<?php echo $index; ?>][name]" value="<?php echo esc_attr( $block['name'] ); ?>"></label><label>Language<select class="cb-codetizer-select cb-pb-language" name="blocks[<?php echo $index; ?>][language]"><option value="html" <?php selected( $block['language'], 'html' ); ?>>HTML</option><option value="css" <?php selected( $block['language'], 'css' ); ?>>CSS</option><option value="javascript" <?php selected( $block['language'], 'javascript' ); ?>>JavaScript</option></select></label></div>
                            <textarea class="cb-codetizer-textarea cb-pb-code" name="blocks[<?php echo $index; ?>][code]" rows="16"><?php echo esc_textarea( $block['code'] ); ?></textarea>
                            <div class="cb-pb-count">0 characters · 0 lines</div>
                        </div>
                    </section>
                <?php endforeach; ?>
                </div>

                <details class="cb-pb-more"><summary>+ Select more containers</summary><div class="cb-pb-picker"><select id="cb-pb-element-picker" class="cb-codetizer-select"><option value="">Choose an actual Elementor HTML widget...</option><?php foreach ( $elements as $element ) : if ( isset( $block_by_element[ $element['id'] ] ) ) { continue; } ?><option value="<?php echo esc_attr( $element['id'] ); ?>" data-label="<?php echo esc_attr( $element['label'] ); ?>" data-parent="<?php echo esc_attr( $element['parent'] ); ?>"><?php echo esc_html( $element['label'] . ' · #' . $element['id'] . ' · ' . $element['parent'] ); ?></option><?php endforeach; ?></select><button type="button" id="cb-pb-add" class="cb-codetizer-btn cb-codetizer-btn-secondary">Add Container</button></div></details>
                <div class="cb-pb-footer-actions"><button class="cb-codetizer-btn cb-codetizer-btn-primary" type="submit">Save to Pages Builder</button></div>
            </form>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="cb-pb-send-form"><?php wp_nonce_field( 'cb_codetizer_pages_builder_send', 'cb_codetizer_pages_builder_nonce' ); ?><input type="hidden" name="action" value="cb_codetizer_pages_builder_send"><input type="hidden" name="page_id" value="<?php echo (int) $page_id; ?>"><button type="submit" class="cb-codetizer-btn cb-codetizer-btn-primary" <?php disabled( ! $elementor_available || ! $elements ); ?>>Send to Elementor</button><span>Creates a backup first, then writes only to the selected real Elementor HTML widget IDs.</span></form>
        <?php endif; ?>
        </main>
    </div>
</div>
