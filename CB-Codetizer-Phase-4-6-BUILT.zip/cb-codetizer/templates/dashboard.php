<?php
/**
 * Dashboard template for CB Codetizer.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
        exit;
}
?>

<div class="cb-codetizer-wrap">
        <h1><?php echo esc_html__( 'CB Codetizer Dashboard', 'cb-codetizer' ); ?></h1>

        <div class="cb-codetizer-stats-grid">
                <div class="cb-codetizer-stat-card">
                        <div class="cb-codetizer-stat-value" id="cb-codetizer-security-score">--</div>
                        <div class="cb-codetizer-stat-label"><?php echo esc_html__( 'Security Score', 'cb-codetizer' ); ?></div>
                </div>
                <div class="cb-codetizer-stat-card">
                        <div class="cb-codetizer-stat-value" id="cb-codetizer-files-scanned">--</div>
                        <div class="cb-codetizer-stat-label"><?php echo esc_html__( 'Files Scanned', 'cb-codetizer' ); ?></div>
                </div>
                <div class="cb-codetizer-stat-card">
                        <div class="cb-codetizer-stat-value" id="cb-codetizer-threats-found">--</div>
                        <div class="cb-codetizer-stat-label"><?php echo esc_html__( 'Threats Found', 'cb-codetizer' ); ?></div>
                </div>
                <div class="cb-codetizer-stat-card">
                        <div class="cb-codetizer-stat-value">9</div>
                        <div class="cb-codetizer-stat-label"><?php echo esc_html__( 'Languages Supported', 'cb-codetizer' ); ?></div>
                </div>
        </div>

        <h2><?php echo esc_html__( 'Recent Activity', 'cb-codetizer' ); ?></h2>
        <table class="cb-codetizer-table" id="cb-codetizer-recent-activity-table">
                <thead>
                        <tr>
                                <th><?php echo esc_html__( 'Date', 'cb-codetizer' ); ?></th>
                                <th><?php echo esc_html__( 'Type', 'cb-codetizer' ); ?></th>
                                <th><?php echo esc_html__( 'Language', 'cb-codetizer' ); ?></th>
                                <th><?php echo esc_html__( 'Threats', 'cb-codetizer' ); ?></th>
                                <th><?php echo esc_html__( 'Severity', 'cb-codetizer' ); ?></th>
                        </tr>
                </thead>
                <tbody id="cb-codetizer-recent-activity-tbody">
                        <tr>
                                <td colspan="5" class="cb-codetizer-no-data"><?php echo esc_html__( 'Loading recent activity...', 'cb-codetizer' ); ?></td>
                        </tr>
                </tbody>
        </table>

        <h2><?php echo esc_html__( 'Quick Actions', 'cb-codetizer' ); ?></h2>
        <div class="cb-codetizer-quick-actions">
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=cb-codetizer-inspector' ) ); ?>" class="cb-codetizer-btn cb-codetizer-btn-primary">
                        <?php echo esc_html__( 'Inspector', 'cb-codetizer' ); ?>
                </a>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=cb-codetizer-sanitizer' ) ); ?>" class="cb-codetizer-btn cb-codetizer-btn-primary">
                        <?php echo esc_html__( 'Sanitizer', 'cb-codetizer' ); ?>
                </a>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=cb-codetizer-beautifier' ) ); ?>" class="cb-codetizer-btn cb-codetizer-btn-primary">
                        <?php echo esc_html__( 'Beautifier', 'cb-codetizer' ); ?>
                </a>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=cb-codetizer-js-arena' ) ); ?>" class="cb-codetizer-btn cb-codetizer-btn-primary">
                        <?php echo esc_html__( 'JS Arena', 'cb-codetizer' ); ?>
                </a>
        </div>

        <?php wp_nonce_field( 'cb_codetizer_get_dashboard_stats', 'cb_codetizer_nonce' ); ?>

        <script>
        /* global CBCodeTizer, ajaxurl */
        (function() {
            'use strict';
            function loadDashboardStats() {
                if (typeof CBCodeTizer === 'undefined') {
                    setTimeout(loadDashboardStats, 100);
                    return;
                }
                CBCodeTizer.ajax('cb_codetizer_get_dashboard_stats', {}).then(function(res) {
                    if (!res.success || !res.data) return;
                    var d = res.data;
                    var stats = d.stats || {};
                    var scoreEl = document.getElementById('cb-codetizer-security-score');
                    if (scoreEl) scoreEl.textContent = stats.average_score || '100';
                    var scansEl = document.getElementById('cb-codetizer-files-scanned');
                    if (scansEl) scansEl.textContent = stats.total_scans || '0';
                    var threatsEl = document.getElementById('cb-codetizer-threats-found');
                    if (threatsEl) threatsEl.textContent = stats.total_threats || '0';
                    var tbody = document.getElementById('cb-codetizer-recent-activity-tbody');
                    var recentScans = stats.recent_scans || [];
                    if (tbody && recentScans.length > 0) {
                        tbody.innerHTML = '';
                        recentScans.forEach(function(scan) {
                            var tr = document.createElement('tr');
                            var tdDate = document.createElement('td');
                            tdDate.textContent = scan.created_at || '';
                            tr.appendChild(tdDate);
                            var tdType = document.createElement('td');
                            tdType.textContent = scan.scan_type || '';
                            tr.appendChild(tdType);
                            var tdLang = document.createElement('td');
                            tdLang.textContent = scan.language || '';
                            tr.appendChild(tdLang);
                            var tdThreats = document.createElement('td');
                            tdThreats.textContent = scan.threats_found || '0';
                            tr.appendChild(tdThreats);
                            var tdSev = document.createElement('td');
                            tdSev.textContent = scan.severity_summary || '';
                            tr.appendChild(tdSev);
                            tbody.appendChild(tr);
                        });
                    } else if (tbody) {
                        tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#50575e;">No activity yet.</td></tr>';
                    }
                });
            }
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', loadDashboardStats);
            } else {
                loadDashboardStats();
            }
        })();
        </script>
</div>
