<?php
/**
 * Settings template for CB Codetizer.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
        exit;
}

$settings = array();
if ( class_exists( 'CB_Codetizer_Settings' ) ) {
        $settings_instance = new CB_Codetizer_Settings();
        $settings          = $settings_instance->get_all();
}

$max_upload     = isset( $settings['max_upload_size'] ) ? (int) $settings['max_upload_size'] / 1024 : 2048;
$max_paste      = isset( $settings['max_input_bytes'] ) ? (int) $settings['max_input_bytes'] / 1024 : 5120;
$default_lang   = isset( $settings['default_language'] ) ? $settings['default_language'] : 'html';
$scan_profile   = isset( $settings['scan_profile'] ) ? $settings['scan_profile'] : 'standard';
$indent_size    = isset( $settings['indent_size'] ) ? (int) $settings['indent_size'] : 4;
$indent_type    = isset( $settings['indent_type'] ) ? $settings['indent_type'] : 'spaces';
?>

<div class="cb-codetizer-wrap">
        <h1><?php echo esc_html__( 'Settings', 'cb-codetizer' ); ?></h1>

        <form id="cb-codetizer-settings-form">
                <div class="cb-codetizer-form-group">
                        <label for="cb-codetizer-max-upload" class="cb-codetizer-label"><?php echo esc_html__( 'Maximum Upload Size (KB)', 'cb-codetizer' ); ?></label>
                        <input type="number" id="cb-codetizer-max-upload" class="cb-codetizer-input" min="100" max="10240" step="100" value="<?php echo esc_attr( $max_upload ); ?>" />
                </div>

                <div class="cb-codetizer-form-group">
                        <label for="cb-codetizer-max-paste" class="cb-codetizer-label"><?php echo esc_html__( 'Maximum Pasted Code Size (KB)', 'cb-codetizer' ); ?></label>
                        <input type="number" id="cb-codetizer-max-paste" class="cb-codetizer-input" min="100" max="10240" step="100" value="<?php echo esc_attr( $max_paste ); ?>" />
                </div>

                <div class="cb-codetizer-form-group">
                        <label for="cb-codetizer-default-lang" class="cb-codetizer-label"><?php echo esc_html__( 'Default Language', 'cb-codetizer' ); ?></label>
                        <select id="cb-codetizer-default-lang" class="cb-codetizer-select">
                                <option value="html"<?php selected( $default_lang, 'html' ); ?>><?php echo esc_html__( 'HTML', 'cb-codetizer' ); ?></option>
                                <option value="svg"<?php selected( $default_lang, 'svg' ); ?>><?php echo esc_html__( 'SVG', 'cb-codetizer' ); ?></option>
                                <option value="css"<?php selected( $default_lang, 'css' ); ?>><?php echo esc_html__( 'CSS', 'cb-codetizer' ); ?></option>
                                <option value="javascript"<?php selected( $default_lang, 'javascript' ); ?>><?php echo esc_html__( 'JavaScript', 'cb-codetizer' ); ?></option>
                                <option value="php"<?php selected( $default_lang, 'php' ); ?>><?php echo esc_html__( 'PHP', 'cb-codetizer' ); ?></option>
                                <option value="json"<?php selected( $default_lang, 'json' ); ?>><?php echo esc_html__( 'JSON', 'cb-codetizer' ); ?></option>
                                <option value="xml"<?php selected( $default_lang, 'xml' ); ?>><?php echo esc_html__( 'XML', 'cb-codetizer' ); ?></option>
                                <option value="markdown"<?php selected( $default_lang, 'markdown' ); ?>><?php echo esc_html__( 'Markdown', 'cb-codetizer' ); ?></option>
                                <option value="txt"<?php selected( $default_lang, 'txt' ); ?>><?php echo esc_html__( 'TXT', 'cb-codetizer' ); ?></option>
                        </select>
                </div>

                <div class="cb-codetizer-form-group">
                        <label for="cb-codetizer-scan-profile" class="cb-codetizer-label"><?php echo esc_html__( 'Scan Profile', 'cb-codetizer' ); ?></label>
                        <select id="cb-codetizer-scan-profile" class="cb-codetizer-select">
                                <option value="standard"<?php selected( $scan_profile, 'standard' ); ?>><?php echo esc_html__( 'Standard', 'cb-codetizer' ); ?></option>
                                <option value="strict"<?php selected( $scan_profile, 'strict' ); ?>><?php echo esc_html__( 'Strict', 'cb-codetizer' ); ?></option>
                                <option value="custom"<?php selected( $scan_profile, 'custom' ); ?>><?php echo esc_html__( 'Custom', 'cb-codetizer' ); ?></option>
                        </select>
                </div>

                <div class="cb-codetizer-form-row">
                        <div class="cb-codetizer-form-group">
                                <label for="cb-codetizer-indent-size" class="cb-codetizer-label"><?php echo esc_html__( 'Indent Size', 'cb-codetizer' ); ?></label>
                                <input type="number" id="cb-codetizer-indent-size" class="cb-codetizer-input" min="2" max="8" value="<?php echo esc_attr( $indent_size ); ?>" />
                        </div>

                        <div class="cb-codetizer-form-group">
                                <label for="cb-codetizer-indent-type" class="cb-codetizer-label"><?php echo esc_html__( 'Indent Type', 'cb-codetizer' ); ?></label>
                                <select id="cb-codetizer-indent-type" class="cb-codetizer-select">
                                        <option value="spaces"<?php selected( $indent_type, 'spaces' ); ?>><?php echo esc_html__( 'Spaces', 'cb-codetizer' ); ?></option>
                                        <option value="tabs"<?php selected( $indent_type, 'tabs' ); ?>><?php echo esc_html__( 'Tabs', 'cb-codetizer' ); ?></option>
                                </select>
                        </div>
                </div>

                <div class="cb-codetizer-settings-actions">
                        <button type="button" id="cb-codetizer-save-settings-btn" class="cb-codetizer-btn cb-codetizer-btn-primary">
                                <?php echo esc_html__( 'Save Settings', 'cb-codetizer' ); ?>
                        </button>
                        <button type="button" id="cb-codetizer-reset-settings-btn" class="cb-codetizer-btn cb-codetizer-btn-secondary">
                                <?php echo esc_html__( 'Reset Settings', 'cb-codetizer' ); ?>
                        </button>
                        <button type="button" id="cb-codetizer-clear-reports-btn" class="cb-codetizer-btn cb-codetizer-btn-danger">
                                <?php echo esc_html__( 'Clear All Reports', 'cb-codetizer' ); ?>
                        </button>
                </div>

                <?php wp_nonce_field( 'cb_codetizer_settings_page', 'cb_codetizer_nonce' ); ?>
        </form>
</div>
