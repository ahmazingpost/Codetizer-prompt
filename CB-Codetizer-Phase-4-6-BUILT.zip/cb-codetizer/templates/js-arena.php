<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
$arena = new CB_Codetizer_JS_Arena();
$items = $arena->get_items();
$item_id = isset( $_GET['item'] ) ? absint( $_GET['item'] ) : 0;
$item = $item_id ? $arena->get_item( $item_id ) : null;
$pages = get_pages( array( 'sort_column' => 'post_title', 'post_status' => array( 'publish', 'draft' ) ) );
$elementor_pages = array();
if ( class_exists( '\Elementor\Plugin' ) ) {
    foreach ( $pages as $page ) {
        if ( get_post_meta( $page->ID, '_elementor_edit_mode', true ) ) { $elementor_pages[] = $page; }
    }
}
if ( ! $item ) {
    $item = array( 'id' => 0, 'name' => '', 'language' => 'html', 'html' => '', 'css' => '', 'javascript' => '', 'target' => 'global', 'target_page' => 0, 'elementor_post' => 0, 'enabled' => '1' );
}
?>
<div class="cb-codetizer-wrap cb-codetizer-arena">
    <div class="cb-arena-header">
        <div><h1>JS Arena</h1><p>Manage reusable HTML, CSS and JavaScript independently from Elementor.</p></div>
        <a class="cb-codetizer-btn cb-codetizer-btn-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=cb-codetizer-js-arena' ) ); ?>">+ Add Code</a>
    </div>
    <?php if ( isset( $_GET['saved'] ) ) : ?><div class="cb-codetizer-notice cb-codetizer-notice-success">Code item saved.</div><?php endif; ?>
    <?php if ( isset( $_GET['synced'] ) ) : ?><div class="cb-codetizer-notice cb-codetizer-notice-success">Code was synced into Elementor. Open Elementor to continue visual editing.</div><?php endif; ?>
    <div class="cb-arena-layout">
        <aside class="cb-codetizer-card cb-arena-list">
            <div class="cb-arena-list-head"><h2>Code Files</h2><strong><?php echo count( $items ); ?></strong></div>
            <input id="cb-arena-search" class="cb-codetizer-input" type="search" placeholder="Search code files...">
            <?php if ( ! $items ) : ?><p>No code items yet. Create your first one.</p><?php endif; ?>
            <?php foreach ( $items as $row ) : ?>
                <a class="cb-arena-item <?php echo $row['id'] === $item['id'] ? 'is-active' : ''; ?>" data-search="<?php echo esc_attr( strtolower( $row['name'] . ' ' . $row['language'] . ' ' . $row['target'] ) ); ?>" href="<?php echo esc_url( admin_url( 'admin.php?page=cb-codetizer-js-arena&item=' . (int) $row['id'] ) ); ?>">
                    <strong><?php echo esc_html( $row['name'] ); ?></strong><span><?php echo esc_html( strtoupper( $row['language'] ) . ' · ' . ucfirst( $row['target'] ) . ' · ' . get_post( $row['id'] )->post_modified ); ?></span>
                </a>
            <?php endforeach; ?>
        </aside>
        <main class="cb-codetizer-card">
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="cb_codetizer_arena_save">
                <input type="hidden" name="item_id" value="<?php echo (int) $item['id']; ?>">
                <?php wp_nonce_field( 'cb_codetizer_arena_save', 'cb_codetizer_arena_nonce' ); ?>
                <div class="cb-arena-grid">
                    <div><label class="cb-codetizer-label">Name</label><input class="cb-codetizer-input" name="name" value="<?php echo esc_attr( $item['name'] ); ?>" placeholder="Hero Animation"></div>
                    <div><label class="cb-codetizer-label">Language</label><select class="cb-codetizer-select" name="language"><option value="html" <?php selected( $item['language'], 'html' ); ?>>HTML</option><option value="css" <?php selected( $item['language'], 'css' ); ?>>CSS</option><option value="javascript" <?php selected( $item['language'], 'javascript' ); ?>>JavaScript</option><option value="bundle" <?php selected( $item['language'], 'bundle' ); ?>>HTML + CSS + JS</option></select></div>
                </div>
                <div class="cb-arena-grid cb-arena-code-grid">
                    <div><label class="cb-codetizer-label">HTML container</label><textarea class="cb-codetizer-textarea cb-arena-code" name="html" placeholder="Paste HTML here..."><?php echo esc_textarea( $item['html'] ); ?></textarea></div>
                    <div><label class="cb-codetizer-label">CSS container</label><textarea class="cb-codetizer-textarea cb-arena-code" name="css" placeholder="Paste CSS here..."><?php echo esc_textarea( $item['css'] ); ?></textarea></div>
                </div>
                <div class="cb-codetizer-form-group"><label class="cb-codetizer-label">JavaScript</label><textarea class="cb-codetizer-textarea cb-arena-code" name="javascript" placeholder="Paste JavaScript here..."><?php echo esc_textarea( $item['javascript'] ); ?></textarea></div>
                <div class="cb-arena-counts"><span>HTML <b data-count="html">0</b></span><span>CSS <b data-count="css">0</b></span><span>JS <b data-count="javascript">0</b></span><span>Total <b data-count="total">0</b></span></div>
                <div class="cb-arena-grid">
                    <div><label class="cb-codetizer-label">Where is it needed?</label><select class="cb-codetizer-select" name="target" id="cb-arena-target"><option value="global" <?php selected( $item['target'], 'global' ); ?>>Global site</option><option value="header" <?php selected( $item['target'], 'header' ); ?>>Header</option><option value="footer" <?php selected( $item['target'], 'footer' ); ?>>Footer</option><option value="page" <?php selected( $item['target'], 'page' ); ?>>Specific WordPress page</option><option value="elementor" <?php selected( $item['target'], 'elementor' ); ?>>Elementor page</option></select></div>
                    <div><label class="cb-codetizer-label">WordPress page</label><select class="cb-codetizer-select" name="target_page"><option value="0">Select page</option><?php foreach ( $pages as $page ) : ?><option value="<?php echo (int) $page->ID; ?>" <?php selected( (int) $item['target_page'], $page->ID ); ?>><?php echo esc_html( $page->post_title . ' (#' . $page->ID . ')' ); ?></option><?php endforeach; ?></select></div>
                </div>
                <div class="cb-arena-grid">
                    <div><label class="cb-codetizer-label">Elementor page to receive this code</label><select class="cb-codetizer-select" name="elementor_post"><?php if ( ! $elementor_pages ) : ?><option value="0">No Elementor pages detected</option><?php endif; ?><?php foreach ( $elementor_pages as $page ) : ?><option value="<?php echo (int) $page->ID; ?>" <?php selected( (int) $item['elementor_post'], $page->ID ); ?>><?php echo esc_html( $page->post_title . ' (#' . $page->ID . ')' ); ?></option><?php endforeach; ?></select></div>
                    <div class="cb-arena-toggle"><label><input type="checkbox" name="enabled" value="1" <?php checked( $item['enabled'], '1' ); ?>> Active</label></div>
                </div>
                <div class="cb-codetizer-actions"><button class="cb-codetizer-btn cb-codetizer-btn-primary" type="submit">Save Code</button><?php if ( $item['id'] ) : ?><a class="cb-codetizer-btn cb-codetizer-btn-secondary" target="_blank" href="<?php echo esc_url( admin_url( 'post.php?post=' . (int) $item['id'] . '&action=edit' ) ); ?>">Open Item</a><?php endif; ?></div>
            </form>
            <?php if ( $item['id'] && class_exists( '\Elementor\Plugin' ) ) : ?>
            <hr>
            <h2>Elementor Integration</h2>
            <p class="cb-codetizer-description">Sync this saved code into the selected Elementor page. Codetizer creates the default HTML and CSS containers in the page structure when needed, then leaves you to finish the layout in Elementor.</p>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="cb_codetizer_arena_sync_elementor"><input type="hidden" name="item_id" value="<?php echo (int) $item['id']; ?>"><input type="hidden" name="elementor_post" value="<?php echo (int) $item['elementor_post']; ?>"><?php wp_nonce_field( 'cb_codetizer_arena_sync_elementor', 'cb_codetizer_arena_nonce' ); ?><button class="cb-codetizer-btn cb-codetizer-btn-primary" type="submit" <?php disabled( ! $item['elementor_post'] ); ?>>Send Code to Elementor</button>
            </form>
            <?php endif; ?>
            <?php if ( $item['id'] ) : ?><form class="cb-arena-delete" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"><input type="hidden" name="action" value="cb_codetizer_arena_delete"><input type="hidden" name="item_id" value="<?php echo (int) $item['id']; ?>"><?php wp_nonce_field( 'cb_codetizer_arena_delete', 'cb_codetizer_arena_nonce' ); ?><button class="cb-codetizer-btn cb-codetizer-btn-danger" type="submit" data-confirm="Delete this code item permanently?">Delete</button></form><?php endif; ?>
        </main>
    </div>
</div>
