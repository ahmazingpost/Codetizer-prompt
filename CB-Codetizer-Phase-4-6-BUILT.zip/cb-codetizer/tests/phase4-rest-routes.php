<?php

$wp_load = 'C:/laragon/www/cb-codetizer-qwen/wp-load.php';

require_once $wp_load;

echo "=== PHASE 4 REST API ROUTE TEST ===" . PHP_EOL;

$failures = 0;

function rest_pass( $name ) {
    echo "PASS: " . $name . PHP_EOL;
}

function rest_fail( $name, $detail = '' ) {
    global $failures;

    $failures++;

    echo "FAIL: " . $name;

    if ( $detail !== '' ) {
        echo " | " . $detail;
    }

    echo PHP_EOL;
}

if ( ! class_exists( 'CB_Codetizer_REST_API' ) ) {
    rest_fail( 'REST API class loaded' );
    exit(1);
}

try {

    $api = new CB_Codetizer_REST_API();

    rest_pass( 'REST API instantiated' );

    /*
     * register() should attach routes through WordPress.
     */
    $api->register();

    rest_pass( 'register() executed without exception' );

    /*
     * Ask WordPress for all registered REST routes.
     */
    $server = rest_get_server();

    $routes = $server->get_routes();

    if ( is_array( $routes ) ) {

        rest_pass(
            'WordPress REST server returned route collection'
        );

    } else {

        rest_fail(
            'WordPress REST server returned route collection'
        );
    }

    /*
     * Display CB CODETIZER routes.
     */
    $cb_routes = array();

    foreach ( $routes as $route => $handlers ) {

        if (
            stripos( $route, 'codetizer' ) !== false ||
            stripos( $route, 'arena' ) !== false
        ) {
            $cb_routes[ $route ] = $handlers;
        }
    }

    echo PHP_EOL;
    echo "CB_CODETIZER_ROUTES=" . count( $cb_routes ) . PHP_EOL;

    foreach ( $cb_routes as $route => $handlers ) {

        echo "ROUTE=" . $route . PHP_EOL;

        if ( is_array( $handlers ) ) {

            echo "HANDLERS=" . count( $handlers ) . PHP_EOL;

        } else {

            echo "HANDLERS=UNKNOWN" . PHP_EOL;
        }
    }

    /*
     * We don't assume the exact route names yet.
     * First prove that at least one plugin route exists.
     */
    if ( count( $cb_routes ) > 0 ) {

        rest_pass(
            'CB CODETIZER REST routes registered'
        );

    } else {

        rest_fail(
            'CB CODETIZER REST routes registered',
            'No matching routes found'
        );
    }

    /*
     * Inspect WordPress REST namespace information.
     */
    $namespaces = $server->get_namespaces();

    if ( is_array( $namespaces ) ) {

        rest_pass(
            'REST namespaces available'
        );

        foreach ( $namespaces as $namespace ) {

            if (
                stripos( $namespace, 'codetizer' ) !== false ||
                stripos( $namespace, 'cb' ) !== false
            ) {
                echo "NAMESPACE=" . $namespace . PHP_EOL;
            }
        }

    } else {

        rest_fail(
            'REST namespaces available'
        );
    }

} catch ( Throwable $e ) {

    rest_fail(
        'Unexpected exception',
        get_class( $e ) . ': ' . $e->getMessage()
    );
}

echo PHP_EOL;

if ( 0 === $failures ) {

    echo "PHASE4_REST_ROUTE_REGISTRATION=PASS" . PHP_EOL;

} else {

    echo "PHASE4_REST_ROUTE_REGISTRATION=FAIL" . PHP_EOL;
    echo "FAILURES=" . $failures . PHP_EOL;

    exit(1);
}
