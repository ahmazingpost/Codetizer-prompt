<?php

$wp_load = 'C:/laragon/www/cb-codetizer-qwen/wp-load.php';

require_once $wp_load;

echo "=== PHASE 4 BACKUP ENGINE FUNCTIONAL TEST ===" . PHP_EOL;

$failures = 0;

function phase4_pass( $name ) {
    echo "PASS: " . $name . PHP_EOL;
}

function phase4_fail( $name, $detail = '' ) {
    global $failures;

    $failures++;

    echo "FAIL: " . $name;

    if ( $detail !== '' ) {
        echo " | " . $detail;
    }

    echo PHP_EOL;
}

if ( ! class_exists( 'CB_Codetizer_Backups' ) ) {
    phase4_fail( 'Backup class loaded' );
    exit(1);
}

try {
    $backup = new CB_Codetizer_Backups();

    phase4_pass( 'Backup engine instantiated' );

    /*
     * CREATE
     */
    $test_content = '<?php echo "CB CODETIZER PHASE 4 TEST";';

    $test_meta = array(
        'test'       => true,
        'phase'      => '4',
        'created_by' => 'phase4-functional-test',
    );

    $id = $backup->create(
        'phase4-test',
        'php',
        $test_content,
        $test_meta
    );

    if ( is_int( $id ) && $id > 0 ) {
        phase4_pass( 'create() returned valid backup ID: ' . $id );
    } else {
        phase4_fail(
            'create() returned valid backup ID',
            var_export( $id, true )
        );

        exit(1);
    }

    /*
     * GET
     */
    $row = $backup->get( $id );

    if ( is_object( $row ) ) {
        phase4_pass( 'get() returned backup object' );
    } else {
        phase4_fail(
            'get() returned backup object',
            var_export( $row, true )
        );
    }

    /*
     * CONTENT
     */
    if ( is_object( $row ) ) {

        $serialized = wp_json_encode( $row );

        if ( strpos( $serialized, 'CB CODETIZER PHASE 4 TEST' ) !== false ) {
            phase4_pass( 'Stored backup content verified' );
        } else {
            phase4_fail(
                'Stored backup content verified',
                $serialized
            );
        }
    }

    /*
     * GET ALL
     *
     * Important:
     * get_all() returns a wrapper array:
     *
     * [
     *     'backups'      => array(...),
     *     'total'        => int,
     *     'pages'        => int,
     *     'current_page' => int
     * ]
     */
    $all = $backup->get_all( 20, 1, null );

    if ( is_array( $all ) ) {
        phase4_pass( 'get_all() returned array' );
    } else {
        phase4_fail(
            'get_all() returned array',
            var_export( $all, true )
        );
    }

    $backup_items = array();

    if (
        is_array( $all ) &&
        isset( $all['backups'] ) &&
        is_array( $all['backups'] )
    ) {
        $backup_items = $all['backups'];
    }

    $found = false;

    foreach ( $backup_items as $item ) {

        if (
            is_object( $item ) &&
            isset( $item->id ) &&
            (int) $item->id === (int) $id
        ) {
            $found = true;
            break;
        }

        if (
            is_array( $item ) &&
            isset( $item['id'] ) &&
            (int) $item['id'] === (int) $id
        ) {
            $found = true;
            break;
        }
    }

    if ( $found ) {
        phase4_pass( 'Created backup appears in get_all()' );
    } else {
        phase4_fail(
            'Created backup appears in get_all()',
            'Expected backup ID ' . $id . ' was not found'
        );
    }

    /*
     * VERIFY PAGINATION METADATA
     */
    if (
        isset( $all['total'] ) &&
        isset( $all['pages'] ) &&
        isset( $all['current_page'] )
    ) {
        phase4_pass( 'get_all() pagination metadata present' );
    } else {
        phase4_fail( 'get_all() pagination metadata present' );
    }

    /*
     * RESTORE WITHOUT CONFIRMATION
     */
    $verifier = function( $backup_data ) {
        return true;
    };

    $restore_unconfirmed = $backup->restore(
        $id,
        $verifier,
        false
    );

    if ( is_wp_error( $restore_unconfirmed ) ) {
        phase4_pass( 'restore() rejects unconfirmed restore' );
    } else {
        phase4_fail(
            'restore() rejects unconfirmed restore',
            'Returned: ' . var_export( $restore_unconfirmed, true )
        );
    }

    /*
     * RESTORE WITH CONFIRMATION
     */
    $restore_confirmed = $backup->restore(
        $id,
        $verifier,
        true
    );

    if ( is_wp_error( $restore_confirmed ) ) {
        phase4_fail(
            'restore() confirmed operation',
            $restore_confirmed->get_error_message()
        );
    } elseif ( is_array( $restore_confirmed ) ) {
        phase4_pass( 'restore() confirmed operation returned array' );
    } else {
        phase4_fail(
            'restore() confirmed operation returned expected result',
            var_export( $restore_confirmed, true )
        );
    }

    /*
     * PURGE
     *
     * 99999 days means the newly-created test backup should
     * not qualify for deletion.
     */
    $purged = $backup->purge_older_than_days( 99999 );

    if ( is_int( $purged ) ) {
        phase4_pass(
            'purge_older_than_days() returned integer: ' . $purged
        );
    } else {
        phase4_fail(
            'purge_older_than_days() returned integer',
            var_export( $purged, true )
        );
    }

} catch ( Throwable $e ) {

    phase4_fail(
        'Unexpected exception',
        get_class( $e ) . ': ' . $e->getMessage()
    );
}

echo PHP_EOL;

if ( $failures === 0 ) {

    echo "PHASE4_BACKUP_FUNCTIONAL=PASS" . PHP_EOL;

} else {

    echo "PHASE4_BACKUP_FUNCTIONAL=FAIL" . PHP_EOL;
    echo "FAILURES=" . $failures . PHP_EOL;

    exit(1);
}
