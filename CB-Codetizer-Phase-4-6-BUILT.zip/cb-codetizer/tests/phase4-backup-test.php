<?php

$wp_load = 'C:/laragon/www/cb-codetizer-qwen/wp-load.php';

require_once $wp_load;

echo "=== PHASE 4 BACKUP ENGINE TEST ===" . PHP_EOL;

echo "CLASS=" .
    ( class_exists( 'CB_Codetizer_Backups' ) ? 'LOADED' : 'MISSING' )
    . PHP_EOL;

if ( ! class_exists( 'CB_Codetizer_Backups' ) ) {
    exit(1);
}

$reflection = new ReflectionClass( 'CB_Codetizer_Backups' );

echo "ABSTRACT=" . ( $reflection->isAbstract() ? 'YES' : 'NO' ) . PHP_EOL;
echo "INSTANTIABLE=" . ( $reflection->isInstantiable() ? 'YES' : 'NO' ) . PHP_EOL;

echo "METHODS=" . PHP_EOL;

foreach ( $reflection->getMethods() as $method ) {
    if ( $method->getDeclaringClass()->getName() === 'CB_Codetizer_Backups' ) {
        echo " - " . $method->getName() . PHP_EOL;
    }
}

echo "CONSTANTS=" . PHP_EOL;

foreach ( $reflection->getConstants() as $name => $value ) {
    echo " - " . $name . "=" . var_export( $value, true ) . PHP_EOL;
}

echo "PHASE4_BACKUP_REFLECTION=PASS" . PHP_EOL;
