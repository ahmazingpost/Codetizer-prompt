<?php

$wp_load = 'C:/laragon/www/cb-codetizer-qwen/wp-load.php';

require_once $wp_load;

echo "=== PHASE 4 REPORTS ENGINE FUNCTIONAL TEST ===" . PHP_EOL;

$failures = 0;

function reports_pass( $name ) {
    echo "PASS: " . $name . PHP_EOL;
}

function reports_fail( $name, $detail = '' ) {
    global $failures;

    $failures++;

    echo "FAIL: " . $name;

    if ( $detail !== '' ) {
        echo " | " . $detail;
    }

    echo PHP_EOL;
}

if ( ! class_exists( 'CB_Codetizer_Reports' ) ) {
    reports_fail( 'Reports class loaded' );
    exit(1);
}

try {

    $reports = new CB_Codetizer_Reports();

    reports_pass( 'Reports engine instantiated' );

    /*
     * ---------------------------------------------------------
     * SAVE
     * ---------------------------------------------------------
     */

    $test_data = array(
        'source_type' => 'phase4-test',
        'language'    => 'php',
        'score'       => 87,
        'issues'      => 3,
        'warnings'    => 2,
        'errors'      => 1,
        'meta'        => array(
            'test'       => true,
            'phase'      => '4',
            'created_by' => 'phase4-functional-test',
        ),
    );

    $id = $reports->save( $test_data );

    if ( is_int( $id ) && $id > 0 ) {

        reports_pass(
            'save() returned valid report ID: ' . $id
        );

    } else {

        reports_fail(
            'save() returned valid report ID',
            var_export( $id, true )
        );

        exit(1);
    }

    /*
     * ---------------------------------------------------------
     * GET BY ID
     * ---------------------------------------------------------
     */

    $row = $reports->get_by_id( $id );

    if ( is_object( $row ) ) {

        reports_pass(
            'get_by_id() returned report object'
        );

    } else {

        reports_fail(
            'get_by_id() returned report object',
            var_export( $row, true )
        );
    }

    /*
     * ---------------------------------------------------------
     * VERIFY STORED DATA
     * ---------------------------------------------------------
     */

    if ( is_object( $row ) ) {

        $serialized = wp_json_encode( $row );

        if (
            strpos( $serialized, 'phase4-test' ) !== false ||
            strpos( $serialized, '87' ) !== false
        ) {

            reports_pass(
                'Stored report data verified'
            );

        } else {

            reports_fail(
                'Stored report data verified',
                $serialized
            );
        }
    }

    /*
     * ---------------------------------------------------------
     * GET ALL
     * ---------------------------------------------------------
     */

    $all = $reports->get_all();

    if ( is_array( $all ) ) {

        reports_pass(
            'get_all() returned array'
        );

    } else {

        reports_fail(
            'get_all() returned array',
            var_export( $all, true )
        );
    }

    /*
     * Verify our report appears somewhere in the
     * get_all() result without assuming its exact
     * return structure.
     */

    $all_json = wp_json_encode( $all );

    if (
        strpos( $all_json, '"id":' . $id ) !== false ||
        strpos( $all_json, '"id":"' . $id . '"' ) !== false
    ) {

        reports_pass(
            'Created report appears in get_all()'
        );

    } else {

        reports_fail(
            'Created report appears in get_all()',
            'Report ID ' . $id . ' not found in result'
        );
    }

    /*
     * ---------------------------------------------------------
     * AVERAGE SCORE
     * ---------------------------------------------------------
     */

    $average = $reports->get_average_score();

    if ( is_int( $average ) ) {

        reports_pass(
            'get_average_score() returned integer: ' . $average
        );

    } else {

        reports_fail(
            'get_average_score() returned integer',
            var_export( $average, true )
        );
    }

    /*
     * ---------------------------------------------------------
     * STATS
     * ---------------------------------------------------------
     */

    $stats = $reports->get_stats();

    if ( is_array( $stats ) ) {

        reports_pass(
            'get_stats() returned array'
        );

        echo "STATS=" . wp_json_encode( $stats ) . PHP_EOL;

    } else {

        reports_fail(
            'get_stats() returned array',
            var_export( $stats, true )
        );
    }

    /*
     * ---------------------------------------------------------
     * DELETE OUR TEST REPORT
     * ---------------------------------------------------------
     */

    $deleted = $reports->delete( $id );

    if ( true === $deleted ) {

        reports_pass(
            'delete() removed test report'
        );

    } else {

        reports_fail(
            'delete() removed test report',
            var_export( $deleted, true )
        );
    }

    /*
     * ---------------------------------------------------------
     * VERIFY DELETION
     * ---------------------------------------------------------
     */

    $after_delete = $reports->get_by_id( $id );

    if ( null === $after_delete ) {

        reports_pass(
            'Deleted report no longer retrievable'
        );

    } else {

        reports_fail(
            'Deleted report no longer retrievable',
            'Report still returned'
        );
    }

} catch ( Throwable $e ) {

    reports_fail(
        'Unexpected exception',
        get_class( $e ) . ': ' . $e->getMessage()
    );
}

echo PHP_EOL;

if ( 0 === $failures ) {

    echo "PHASE4_REPORTS_FUNCTIONAL=PASS" . PHP_EOL;

} else {

    echo "PHASE4_REPORTS_FUNCTIONAL=FAIL" . PHP_EOL;
    echo "FAILURES=" . $failures . PHP_EOL;

    exit(1);
}
