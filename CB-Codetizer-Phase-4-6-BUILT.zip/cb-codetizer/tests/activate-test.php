<?php
$wp_load = 'C:/laragon/www/cb-codetizer-qwen/wp-load.php';

require_once $wp_load;

$plugin = 'cb-codetizer/cb-codetizer.php';

echo "PLUGIN_FILE=" .
    ( file_exists(WP_PLUGIN_DIR . '/' . $plugin) ? 'YES' : 'NO' )
    . PHP_EOL;

echo "WP_PLUGIN_DIR=" . WP_PLUGIN_DIR . PHP_EOL;

echo "PLUGIN_ACTIVE_BEFORE=" .
    ( is_plugin_active($plugin) ? 'YES' : 'NO' )
    . PHP_EOL;

if ( ! function_exists('activate_plugin') ) {
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
}

echo "ACTIVATION_FUNCTION=" .
    ( function_exists('activate_plugin') ? 'AVAILABLE' : 'MISSING' )
    . PHP_EOL;

$result = activate_plugin($plugin, '', false, true);

if ( is_wp_error($result) ) {
    echo "ACTIVATION=FAILED" . PHP_EOL;
    echo "ERROR_CODE=" . $result->get_error_code() . PHP_EOL;
    echo "ERROR_MESSAGE=" . $result->get_error_message() . PHP_EOL;
} else {
    echo "ACTIVATION=SUCCESS" . PHP_EOL;
}

echo "PLUGIN_ACTIVE_AFTER=" .
    ( is_plugin_active($plugin) ? 'YES' : 'NO' )
    . PHP_EOL;

echo "ACTIVE_PLUGINS=" . PHP_EOL;

foreach ( (array) get_option('active_plugins', array()) as $p ) {
    echo " - " . $p . PHP_EOL;
}
