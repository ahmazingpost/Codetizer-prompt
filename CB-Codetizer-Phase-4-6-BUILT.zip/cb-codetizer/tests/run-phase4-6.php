<?php

$wp_load = 'C:/laragon/www/cb-codetizer-qwen/wp-load.php';

require_once $wp_load;

echo "BOOTSTRAP_OK" . PHP_EOL;

$active = get_option( 'active_plugins', array() );

echo "PLUGIN_ACTIVE=" .
    ( in_array( 'cb-codetizer/cb-codetizer.php', (array) $active, true ) ? 'YES' : 'NO' )
    . PHP_EOL;

echo "BOOT_FUNCTION=" .
    ( function_exists( 'cb_codetizer_boot' ) ? 'DEFINED' : 'MISSING' )
    . PHP_EOL;

echo "CLASS_LOADER=" .
    ( class_exists( 'CB_Codetizer_Loader' ) ? 'LOADED' : 'MISSING' )
    . PHP_EOL;

$classes = array(
    'CB_Codetizer_Backups',
    'CB_Codetizer_Reports',
    'CB_Codetizer_REST_API',
    'CB_Codetizer_JS_Arena',
    'CB_Codetizer_Services',
);

foreach ( $classes as $class ) {
    echo $class . "=" .
        ( class_exists( $class ) ? 'LOADED' : 'MISSING' )
        . PHP_EOL;
}

echo "WP_REWRITE=" .
    ( is_object( $GLOBALS['wp_rewrite'] ?? null )
        ? get_class( $GLOBALS['wp_rewrite'] )
        : gettype( $GLOBALS['wp_rewrite'] ?? null ) )
    . PHP_EOL;
