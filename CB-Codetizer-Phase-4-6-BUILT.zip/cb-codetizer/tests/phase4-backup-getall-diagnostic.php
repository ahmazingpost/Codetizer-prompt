<?php

$wp_load = 'C:/laragon/www/cb-codetizer-qwen/wp-load.php';

require_once $wp_load;

echo "=== PHASE 4 BACKUP GET_ALL DIAGNOSTIC ===" . PHP_EOL;

$backup = new CB_Codetizer_Backups();

echo "CURRENT_USER_ID=" . get_current_user_id() . PHP_EOL;

echo PHP_EOL . "--- GET ID 1 ---" . PHP_EOL;

$row = $backup->get(1);

if ( is_object($row) ) {
    echo "GET_RESULT=OBJECT" . PHP_EOL;
    echo "GET_OBJECT=" . print_r($row, true) . PHP_EOL;
} else {
    echo "GET_RESULT=" . var_export($row, true) . PHP_EOL;
}

echo PHP_EOL . "--- GET_ALL DEFAULT ---" . PHP_EOL;

$result = $backup->get_all();

echo "RESULT_TYPE=" . gettype($result) . PHP_EOL;
echo "COUNT=" . count($result) . PHP_EOL;
echo "RESULT=" . print_r($result, true) . PHP_EOL;

echo PHP_EOL . "--- GET_ALL 20, PAGE 1, NULL USER ---" . PHP_EOL;

$result2 = $backup->get_all(20, 1, null);

echo "RESULT_TYPE=" . gettype($result2) . PHP_EOL;
echo "COUNT=" . count($result2) . PHP_EOL;
echo "RESULT=" . print_r($result2, true) . PHP_EOL;

echo PHP_EOL . "--- DATABASE TABLES ---" . PHP_EOL;

global $wpdb;

$tables = $wpdb->get_results(
    "SHOW TABLES LIKE '%codetizer%'",
    ARRAY_N
);

echo print_r($tables, true);

echo PHP_EOL . "--- DB ERROR ---" . PHP_EOL;
echo $wpdb->last_error . PHP_EOL;

echo PHP_EOL . "DIAGNOSTIC_COMPLETE=PASS" . PHP_EOL;
