<?php

$wp_load = 'C:/laragon/www/cb-codetizer-qwen/wp-load.php';

require_once $wp_load;

echo "=== PHASE 4 REST AUTHORIZED REPORTS TEST ===" . PHP_EOL;

$failures = 0;

function auth_pass( $name, $detail = '' ) {
    echo "PASS: " . $name;

    if ( $detail !== '' ) {
        echo " | " . $detail;
    }

    echo PHP_EOL;
}

function auth_fail( $name, $detail = '' ) {
    global $failures;

    $failures++;

    echo "FAIL: " . $name;

    if ( $detail !== '' ) {
        echo " | " . $detail;
    }

    echo PHP_EOL;
}

/*
 * Load plugin API.
 */
if ( ! class_exists( 'CB_Codetizer_REST_API' ) ) {

    auth_fail( 'REST API class loaded' );
    exit(1);
}

/*
 * Load WordPress user functions.
 */
if ( ! function_exists( 'wp_set_current_user' ) ) {

    auth_fail( 'WordPress user API available' );
    exit(1);
}

/*
 * Find an administrator account.
 */
$admins = get_users(
    array(
        'role'   => 'administrator',
        'number' => 1,
        'fields' => array( 'ID', 'user_login' ),
    )
);

if ( empty( $admins ) ) {

    auth_fail(
        'Administrator user available',
        'No administrator account found'
    );

    exit(1);
}

$admin = $admins[0];

echo "TEST_USER_ID=" . $admin->ID . PHP_EOL;
echo "TEST_USER_LOGIN=" . $admin->user_login . PHP_EOL;

/*
 * Establish authenticated WordPress context.
 */
wp_set_current_user( $admin->ID );

if ( get_current_user_id() === (int) $admin->ID ) {

    auth_pass(
        'Authenticated WordPress user established'
    );

} else {

    auth_fail(
        'Authenticated WordPress user established'
    );

    exit(1);
}

/*
 * Verify relevant capabilities.
 */
echo "CAN_MANAGE_OPTIONS=" .
    ( current_user_can( 'manage_options' ) ? 'YES' : 'NO' )
    . PHP_EOL;

echo "CAN_EDIT_POSTS=" .
    ( current_user_can( 'edit_posts' ) ? 'YES' : 'NO' )
    . PHP_EOL;

/*
 * Register the plugin routes.
 */
$api = new CB_Codetizer_REST_API();

$api->register();

auth_pass(
    'REST API registered for authenticated test'
);

/*
 * Get REST server.
 */
$server = rest_get_server();

/*
 * Test reports endpoint.
 */
$request = new WP_REST_Request(
    'GET',
    '/cb-codetizer/v1/reports'
);

try {

    $response = $server->dispatch( $request );

    if ( $response instanceof WP_Error ) {

        auth_fail(
            'Authorized reports request',
            $response->get_error_code() . ': ' .
            $response->get_error_message()
        );

    } else {

        $status = $response->get_status();

        echo "REPORTS_STATUS=" . $status . PHP_EOL;

        if ( $status >= 200 && $status < 300 ) {

            auth_pass(
                'Authorized reports request accepted',
                'HTTP ' . $status
            );

            $data = $response->get_data();

            echo "REPORTS_RESPONSE_TYPE=" .
                gettype( $data ) .
                PHP_EOL;

            if ( is_array( $data ) ) {

                auth_pass(
                    'Reports response returned array'
                );

            } else {

                auth_fail(
                    'Reports response returned array',
                    gettype( $data )
                );
            }

        } else {

            auth_fail(
                'Authorized reports request accepted',
                'HTTP ' . $status
            );
        }
    }

} catch ( Throwable $e ) {

    auth_fail(
        'Reports endpoint dispatch',
        get_class( $e ) . ': ' . $e->getMessage()
    );
}

echo PHP_EOL;

if ( 0 === $failures ) {

    echo "PHASE4_REST_AUTHORIZED_REPORTS=PASS" . PHP_EOL;

} else {

    echo "PHASE4_REST_AUTHORIZED_REPORTS=FAIL" . PHP_EOL;
    echo "FAILURES=" . $failures . PHP_EOL;

    exit(1);
}
