<?php

$wp_load = 'C:/laragon/www/cb-codetizer-qwen/wp-load.php';

require_once $wp_load;

echo "=== PHASE 4 REST API PERMISSION TEST ===" . PHP_EOL;

$failures = 0;

function perm_pass( $name, $detail = '' ) {
    echo "PASS: " . $name;

    if ( $detail !== '' ) {
        echo " | " . $detail;
    }

    echo PHP_EOL;
}

function perm_fail( $name, $detail = '' ) {
    global $failures;

    $failures++;

    echo "FAIL: " . $name;

    if ( $detail !== '' ) {
        echo " | " . $detail;
    }

    echo PHP_EOL;
}

if ( ! class_exists( 'CB_Codetizer_REST_API' ) ) {
    perm_fail( 'REST API class loaded' );
    exit(1);
}

try {

    $api = new CB_Codetizer_REST_API();

    perm_pass( 'REST API instantiated' );

    /*
     * Test capability helper methods directly.
     */
    $methods = array(
        'can_use_tools',
        'can_view_reports',
        'can_manage_settings',
        );

    foreach ( $methods as $method ) {

        if ( ! method_exists( $api, $method ) ) {

            perm_fail(
                $method . '() exists'
            );

            continue;
        }

        try {

            if ( 'capability' === $method ) {

                $result = $api->$method();

            } else {

                $result = $api->$method();
            }

            echo $method . "_RESULT=" .
                var_export( $result, true ) .
                PHP_EOL;

            if (
                is_bool( $result ) ||
                is_string( $result ) ||
                is_array( $result )
            ) {

                perm_pass(
                    $method . '() returned expected scalar/array type'
                );

            } else {

                perm_fail(
                    $method . '() returned unexpected type',
                    gettype( $result )
                );
            }

        } catch ( Throwable $e ) {

            perm_fail(
                $method . '() executed',
                get_class( $e ) . ': ' . $e->getMessage()
            );
        }
    }

    /*
     * Test the REST endpoints through WP_REST_Server.
     *
     * This deliberately runs while the CLI request is not
     * authenticated as a WordPress user.
     */
    $server = rest_get_server();

    $tests = array(
        array(
            'name'   => 'reports',
            'method' => 'GET',
            'route'  => '/cb-codetizer/v1/reports',
        ),
        array(
            'name'   => 'sanitize',
            'method' => 'POST',
            'route'  => '/cb-codetizer/v1/sanitize',
        ),
        array(
            'name'   => 'arena_items',
            'method' => 'GET',
            'route'  => '/cb-codetizer/v1/arena/items',
        ),
    );

    foreach ( $tests as $test ) {

        $request = new WP_REST_Request(
            $test['method'],
            $test['route']
        );

        if ( 'POST' === $test['method'] ) {

            $request->set_header(
                'Content-Type',
                'application/json'
            );

            $request->set_body(
                wp_json_encode(
                    array(
                        'code'     => '<?php echo "test";',
                        'language' => 'php',
                    )
                )
            );
        }

        try {

            $response = $server->dispatch( $request );

            if ( $response instanceof WP_Error ) {

                perm_pass(
                    $test['name'] . ' returned WP_Error',
                    $response->get_error_code()
                );

                continue;
            }

            $status = $response->get_status();

            echo strtoupper( $test['name'] ) .
                "_STATUS=" .
                $status .
                PHP_EOL;

            /*
             * For an unauthenticated request, a protected
             * endpoint should normally reject access with
             * 401/403 rather than execute successfully.
             */
            if ( in_array( $status, array( 401, 403 ), true ) ) {

                perm_pass(
                    $test['name'] . ' rejects unauthenticated access',
                    'HTTP ' . $status
                );

            } else {

                perm_fail(
                    $test['name'] . ' rejects unauthenticated access',
                    'HTTP ' . $status
                );
            }

        } catch ( Throwable $e ) {

            perm_fail(
                $test['name'] . ' dispatch',
                get_class( $e ) . ': ' . $e->getMessage()
            );
        }
    }

} catch ( Throwable $e ) {

    perm_fail(
        'Unexpected exception',
        get_class( $e ) . ': ' . $e->getMessage()
    );
}

echo PHP_EOL;

if ( 0 === $failures ) {

    echo "PHASE4_REST_PERMISSIONS=PASS" . PHP_EOL;

} else {

    echo "PHASE4_REST_PERMISSIONS=FAIL" . PHP_EOL;
    echo "FAILURES=" . $failures . PHP_EOL;

    exit(1);
}

