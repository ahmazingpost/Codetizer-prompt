<?php

$wp_load = 'C:/laragon/www/cb-codetizer-qwen/wp-load.php';

require_once $wp_load;

echo "=== PHASE 4 REST AUTHORIZED SANITIZE TEST ===" . PHP_EOL;

$failures = 0;

function sanitize_pass( $name, $detail = '' ) {
    echo "PASS: " . $name;

    if ( $detail !== '' ) {
        echo " | " . $detail;
    }

    echo PHP_EOL;
}

function sanitize_fail( $name, $detail = '' ) {
    global $failures;

    $failures++;

    echo "FAIL: " . $name;

    if ( $detail !== '' ) {
        echo " | " . $detail;
    }

    echo PHP_EOL;
}

/*
 * Verify API class.
 */
if ( ! class_exists( 'CB_Codetizer_REST_API' ) ) {

    sanitize_fail( 'REST API class loaded' );
    exit(1);
}

/*
 * Find administrator.
 */
$admins = get_users(
    array(
        'role'   => 'administrator',
        'number' => 1,
        'fields' => array( 'ID', 'user_login' ),
    )
);

if ( empty( $admins ) ) {

    sanitize_fail(
        'Administrator user available',
        'No administrator account found'
    );

    exit(1);
}

$admin = $admins[0];

wp_set_current_user( $admin->ID );

if ( get_current_user_id() === (int) $admin->ID ) {

    sanitize_pass(
        'Authenticated administrator established'
    );

} else {

    sanitize_fail(
        'Authenticated administrator established'
    );

    exit(1);
}

/*
 * Register API.
 */
$api = new CB_Codetizer_REST_API();

$api->register();

sanitize_pass(
    'REST API registered'
);

/*
 * Deliberately unsafe test code.
 *
 * This is test input only. The endpoint should process
 * the code rather than execute it.
 */
$test_code = <<<'CODE'
<?php

echo "safe test";

<script>alert("xss");</script>

eval($_GET["code"]);

CODE;

/*
 * Build REST request.
 */
$request = new WP_REST_Request(
    'POST',
    '/cb-codetizer/v1/sanitize'
);

$request->set_header(
    'Content-Type',
    'application/json'
);

$request->set_body(
    wp_json_encode(
        array(
            'code'     => $test_code,
            'language' => 'php',
        )
    )
);

/*
 * Dispatch.
 */
$server = rest_get_server();

try {

    $response = $server->dispatch( $request );

    if ( $response instanceof WP_Error ) {

        sanitize_fail(
            'Sanitize endpoint returned REST response',
            $response->get_error_code() . ': ' .
            $response->get_error_message()
        );

    } else {

        $status = $response->get_status();

        echo "SANITIZE_STATUS=" . $status . PHP_EOL;

        if ( $status >= 200 && $status < 300 ) {

            sanitize_pass(
                'Authorized sanitize request accepted',
                'HTTP ' . $status
            );

        } else {

            sanitize_fail(
                'Authorized sanitize request accepted',
                'HTTP ' . $status
            );
        }

        $data = $response->get_data();

        echo "RESPONSE_TYPE=" .
            gettype( $data ) .
            PHP_EOL;

        echo "RESPONSE=" .
            wp_json_encode( $data ) .
            PHP_EOL;

        if ( is_array( $data ) ) {

            sanitize_pass(
                'Sanitize response returned array'
            );

        } else {

            sanitize_fail(
                'Sanitize response returned array',
                gettype( $data )
            );
        }

        /*
         * Ensure the endpoint did not simply echo the exact
         * malicious payload back as an unchanged result.
         */
        $response_json = wp_json_encode( $data );

        if ( $response_json !== wp_json_encode(
            array(
                'code'     => $test_code,
                'language' => 'php',
            )
        ) ) {

            sanitize_pass(
                'Sanitize response differs from raw request payload'
            );

        } else {

            sanitize_fail(
                'Sanitize response differs from raw request payload'
            );
        }
    }

} catch ( Throwable $e ) {

    sanitize_fail(
        'Sanitize endpoint dispatch',
        get_class( $e ) . ': ' . $e->getMessage()
    );
}

echo PHP_EOL;

if ( 0 === $failures ) {

    echo "PHASE4_REST_AUTHORIZED_SANITIZE=PASS" . PHP_EOL;

} else {

    echo "PHASE4_REST_AUTHORIZED_SANITIZE=FAIL" . PHP_EOL;
    echo "FAILURES=" . $failures . PHP_EOL;

    exit(1);
}
