<?php
/**
 * CB CODETIZER Phase 4-6 integration smoke test.
 */

$wp_load = 'C:/laragon/www/cb-codetizer-qwen/wp-load.php';

if ( ! file_exists( $wp_load ) ) {
    fwrite( STDERR, "FAIL: WordPress wp-load.php not found at {$wp_load}\n" );
    exit( 2 );
}

/*
 * Diagnostic: determine whether wp_rewrite is already corrupted
 * before WordPress finishes loading.
 */
register_shutdown_function(
    function () {
        $v = $GLOBALS['wp_rewrite'] ?? null;

        fwrite(
            STDERR,
            "\n[SHUTDOWN] wp_rewrite type=" . gettype( $v ) . "\n"
        );

        if ( is_object( $v ) ) {
            fwrite( STDERR, "[SHUTDOWN] class=" . get_class( $v ) . "\n" );
        } else {
            fwrite( STDERR, "[SHUTDOWN] value=" . var_export( $v, true ) . "\n" );
        }
    }
);

require_once $wp_load;

echo "BOOTSTRAP_OK\n";
echo "WP_REWRITE_TYPE=" . gettype( $GLOBALS['wp_rewrite'] ) . "\n";

if ( is_object( $GLOBALS['wp_rewrite'] ) ) {
    echo "WP_REWRITE_CLASS=" . get_class( $GLOBALS['wp_rewrite'] ) . "\n";
} else {
    echo "WP_REWRITE_VALUE=" . var_export( $GLOBALS['wp_rewrite'], true ) . "\n";
}

exit( 0 );
