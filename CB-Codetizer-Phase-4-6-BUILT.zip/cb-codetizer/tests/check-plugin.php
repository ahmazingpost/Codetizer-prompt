<?php
$wp_load = 'C:/laragon/www/cb-codetizer-qwen/wp-load.php';

require_once $wp_load;

echo "PLUGIN_FILE=" .
    ( file_exists('C:/laragon/www/cb-codetizer-qwen/wp-content/plugins/cb-codetizer/cb-codetizer.php') ? 'YES' : 'NO' )
    . PHP_EOL;

echo "PLUGIN_DIR=" .
    ( is_dir('C:/laragon/www/cb-codetizer-qwen/wp-content/plugins/cb-codetizer') ? 'YES' : 'NO' )
    . PHP_EOL;

echo "ACTIVE_COUNT=" . count((array) get_option('active_plugins', array())) . PHP_EOL;

echo "ACTIVE_PLUGINS=" . PHP_EOL;
foreach ((array) get_option('active_plugins', array()) as $p) {
    echo " - " . $p . PHP_EOL;
}
