<?php

$wp_load = 'C:/laragon/www/cb-codetizer-qwen/wp-load.php';

require_once $wp_load;

echo "=== PHASE 4 REPORTS ENGINE TEST ===" . PHP_EOL;

if ( ! class_exists( 'CB_Codetizer_Reports' ) ) {
    echo "CLASS=MISSING" . PHP_EOL;
    exit(1);
}

echo "CLASS=LOADED" . PHP_EOL;

$reflection = new ReflectionClass( 'CB_Codetizer_Reports' );

echo "ABSTRACT=" .
    ( $reflection->isAbstract() ? 'YES' : 'NO' ) . PHP_EOL;

echo "INSTANTIABLE=" .
    ( $reflection->isInstantiable() ? 'YES' : 'NO' ) . PHP_EOL;

echo "METHODS=" . PHP_EOL;

foreach ( $reflection->getMethods() as $method ) {

    if ( $method->getDeclaringClass()->getName() === 'CB_Codetizer_Reports' ) {
        echo " - " . $method->getName() . PHP_EOL;
    }
}

echo "REPORTS_REFLECTION=PASS" . PHP_EOL;
