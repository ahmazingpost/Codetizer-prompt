<?php

$wp_load = 'C:/laragon/www/cb-codetizer-qwen/wp-load.php';

require_once $wp_load;

echo "=== PHASE 4 REST BACKUP RESTORE TEST ===" . PHP_EOL;

$failures = 0;

function restore_pass( $name, $detail = '' ) {
    echo "PASS: " . $name;

    if ( $detail !== '' ) {
        echo " | " . $detail;
    }

    echo PHP_EOL;
}

function restore_fail( $name, $detail = '' ) {
    global $failures;

    $failures++;

    echo "FAIL: " . $name;

    if ( $detail !== '' ) {
        echo " | " . $detail;
    }

    echo PHP_EOL;
}

/*
 * Verify API classes.
 */
if (
    ! class_exists( 'CB_Codetizer_REST_API' ) ||
    ! class_exists( 'CB_Codetizer_Backups' )
) {
    restore_fail( 'Required REST/Backup classes loaded' );
    exit(1);
}

/*
 * Find administrator.
 */
$admins = get_users(
    array(
        'role'   => 'administrator',
        'number' => 1,
        'fields' => array( 'ID', 'user_login' ),
    )
);

if ( empty( $admins ) ) {

    restore_fail(
        'Administrator user available',
        'No administrator account found'
    );

    exit(1);
}

$admin = $admins[0];

wp_set_current_user( $admin->ID );

if ( get_current_user_id() === (int) $admin->ID ) {

    restore_pass(
        'Authenticated administrator established'
    );

} else {

    restore_fail(
        'Authenticated administrator established'
    );

    exit(1);
}

/*
 * Register REST API.
 */
$api = new CB_Codetizer_REST_API();

$api->register();

restore_pass(
    'REST API registered'
);

/*
 * Find an existing backup created by our Phase 4 tests.
 */
$backups = new CB_Codetizer_Backups();

$all = $backups->get_all(
    20,
    1,
    null
);

$items = array();

if (
    is_array( $all ) &&
    isset( $all['backups'] ) &&
    is_array( $all['backups'] )
) {
    $items = $all['backups'];
}

$backup_id = 0;

foreach ( $items as $item ) {

    if (
        is_object( $item ) &&
        isset( $item->id )
    ) {
        $backup_id = (int) $item->id;
        break;
    }

    if (
        is_array( $item ) &&
        isset( $item['id'] )
    ) {
        $backup_id = (int) $item['id'];
        break;
    }
}

if ( $backup_id <= 0 ) {

    restore_fail(
        'Existing backup available',
        'No backup found'
    );

    exit(1);
}

echo "TEST_BACKUP_ID=" . $backup_id . PHP_EOL;

/*
 * Build restore request WITHOUT confirmation.
 */
$request = new WP_REST_Request(
    'POST',
    '/cb-codetizer/v1/backups/' . $backup_id . '/restore'
);

$request->set_header(
    'Content-Type',
    'application/json'
);

$request->set_body(
    wp_json_encode(
        array(
            'confirmed' => false,
        )
    )
);

$server = rest_get_server();

try {

    $response = $server->dispatch( $request );

    if ( $response instanceof WP_Error ) {

        restore_pass(
            'Unconfirmed restore rejected with WP_Error',
            $response->get_error_code()
        );

    } else {

        $status = $response->get_status();

        echo "UNCONFIRMED_STATUS=" . $status . PHP_EOL;

        if ( in_array( $status, array( 400, 403, 409 ), true ) ) {

            restore_pass(
                'Unconfirmed restore rejected',
                'HTTP ' . $status
            );

        } else {

            restore_fail(
                'Unconfirmed restore rejected',
                'HTTP ' . $status
            );
        }

        echo "UNCONFIRMED_RESPONSE=" .
            wp_json_encode( $response->get_data() ) .
            PHP_EOL;
    }

} catch ( Throwable $e ) {

    restore_fail(
        'Unconfirmed restore dispatch',
        get_class( $e ) . ': ' . $e->getMessage()
    );
}

echo PHP_EOL;

if ( 0 === $failures ) {

    echo "PHASE4_REST_BACKUP_RESTORE=PASS" . PHP_EOL;

} else {

    echo "PHASE4_REST_BACKUP_RESTORE=FAIL" . PHP_EOL;
    echo "FAILURES=" . $failures . PHP_EOL;

    exit(1);
}
