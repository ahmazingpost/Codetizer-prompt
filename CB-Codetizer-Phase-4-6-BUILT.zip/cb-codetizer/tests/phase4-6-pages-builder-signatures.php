<?php
/**
 * Static/WordPress-runtime signature smoke test for the Pages Builder increment.
 */
$wp_load = 'C:/laragon/www/cb-codetizer-qwen/wp-load.php';
if ( ! file_exists( $wp_load ) ) { fwrite( STDERR, "SKIP: wp-load.php not found.\n" ); exit( 0 ); }
require_once $wp_load;
echo "BOOTSTRAP_OK\n";
$checks = array(
    'CB_Codetizer_Pages_Builder' => array( 'get_pages', 'get_draft', 'save_draft', 'handle_save', 'handle_send' ),
    'CB_Codetizer_Elementor_Integration' => array( 'is_elementor_page', 'discover_elements', 'apply_page_builder_blocks' ),
    'CB_Codetizer_REST_API' => array( 'pages', 'page_elements', 'page_builder_get', 'page_builder_save', 'page_builder_send' ),
);
$failed = 0;
foreach ( $checks as $class => $methods ) {
    echo $class . '=' . ( class_exists( $class ) ? 'LOADED' : 'MISSING' ) . "\n";
    if ( ! class_exists( $class ) ) { $failed++; continue; }
    foreach ( $methods as $method ) {
        $ok = method_exists( $class, $method );
        echo '  ' . $method . '=' . ( $ok ? 'OK' : 'MISSING' ) . "\n";
        if ( ! $ok ) { $failed++; }
    }
}
exit( $failed ? 1 : 0 );
