<?php

$wp_load = 'C:/laragon/www/cb-codetizer-qwen/wp-load.php';

require_once $wp_load;

echo "=== PHASE 4 REST API ENGINE TEST ===" . PHP_EOL;

if ( ! class_exists( 'CB_Codetizer_REST_API' ) ) {
    echo "CLASS=MISSING" . PHP_EOL;
    exit(1);
}

echo "CLASS=LOADED" . PHP_EOL;

$reflection = new ReflectionClass( 'CB_Codetizer_REST_API' );

echo "ABSTRACT=" .
    ( $reflection->isAbstract() ? 'YES' : 'NO' ) . PHP_EOL;

echo "INSTANTIABLE=" .
    ( $reflection->isInstantiable() ? 'YES' : 'NO' ) . PHP_EOL;

echo "METHODS=" . PHP_EOL;

foreach ( $reflection->getMethods() as $method ) {

    if (
        $method->getDeclaringClass()->getName()
        === 'CB_Codetizer_REST_API'
    ) {
        echo " - " . $method->getName() . PHP_EOL;
    }
}

echo "REST_API_REFLECTION=PASS" . PHP_EOL;
