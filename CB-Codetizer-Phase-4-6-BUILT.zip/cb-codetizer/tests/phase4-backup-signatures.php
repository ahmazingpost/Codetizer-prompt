<?php

$wp_load = 'C:/laragon/www/cb-codetizer-qwen/wp-load.php';

require_once $wp_load;

echo "=== PHASE 4 BACKUP API SIGNATURES ===" . PHP_EOL;

$reflection = new ReflectionClass( 'CB_Codetizer_Backups' );

$methods = array(
    'create',
    'get',
    'get_all',
    'restore',
    'purge_older_than_days',
);

foreach ( $methods as $name ) {

    $method = $reflection->getMethod( $name );

    echo PHP_EOL;
    echo "METHOD=" . $name . PHP_EOL;
    echo "VISIBILITY=" .
        ( $method->isPublic() ? 'public' :
        ( $method->isProtected() ? 'protected' : 'private' ) )
        . PHP_EOL;

    echo "PARAMETERS=" . $method->getNumberOfParameters() . PHP_EOL;
    echo "REQUIRED_PARAMETERS=" . $method->getNumberOfRequiredParameters() . PHP_EOL;

    foreach ( $method->getParameters() as $index => $parameter ) {

        echo "PARAM_" . $index . "_NAME=" . $parameter->getName() . PHP_EOL;

        echo "PARAM_" . $index . "_TYPE=" .
            ( $parameter->hasType() ? (string) $parameter->getType() : 'none' )
            . PHP_EOL;

        echo "PARAM_" . $index . "_OPTIONAL=" .
            ( $parameter->isOptional() ? 'YES' : 'NO' )
            . PHP_EOL;

        if ( $parameter->isDefaultValueAvailable() ) {
            echo "PARAM_" . $index . "_DEFAULT=" .
                var_export( $parameter->getDefaultValue(), true )
                . PHP_EOL;
        }
    }

    echo "RETURN_TYPE=" .
        ( $method->hasReturnType() ? (string) $method->getReturnType() : 'none' )
        . PHP_EOL;
}

echo PHP_EOL;
echo "API_SIGNATURE_TEST=PASS" . PHP_EOL;
