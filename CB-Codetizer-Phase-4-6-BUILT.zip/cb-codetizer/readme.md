=== CB CODETIZER ===
Contributors: cbcodetizer
Tags: code inspector, code sanitizer, code beautifier, html, css, javascript, php, security, code formatter
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 8.1
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A comprehensive code inspection, sanitization, and beautification tool for WordPress administrators.

== Description ==

CB Codetizer is a powerful WordPress plugin that provides three essential code tools in one package:

**Code Inspector** - Scan your code for security vulnerabilities, malicious patterns, and potential threats. Supports HTML, SVG, CSS, JavaScript, PHP, JSON, XML, Markdown, and plain text. Provides severity-rated findings with actionable recommendations.

**Code Sanitizer** - Remove dangerous code elements including script tags, event handlers, XSS vectors, XXE patterns, prototype pollution keys, and more. Get a before/after comparison with a detailed list of removed items.

**Code Beautifier** - Format and pretty-print your code with configurable indentation. Supports all major web languages with language-specific formatting rules.

= Features =

* Real-time code inspection with 30+ threat detection patterns
* Automatic code sanitization for 9 programming languages
* Code beautification with configurable indentation (spaces or tabs)
* File upload support or paste code directly
* Automatic language detection
* Scan history and reporting
* CSV export for reports
* Security scoring (0-100)
* WordPress admin integration
* Lightweight - no external dependencies
* Responsive design for desktop, tablet, and mobile

== Installation ==

1. Upload the `cb-codetizer` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Navigate to 'CB Codetizer' in the admin sidebar

== Frequently Asked Questions ==

= Does this plugin modify my theme or plugin files? =
No. CB Codetizer operates entirely within the WordPress admin. It does not modify any files on your server. You paste or upload code, and the plugin processes it in memory.

= Is my code sent to any external service? =
No. All code processing happens entirely on your server. No data is sent to external APIs or services.

= What languages are supported? =
HTML, SVG, CSS, JavaScript, PHP, JSON, XML, Markdown, and plain text.

= Can I customize the scan sensitivity? =
Yes. Go to Settings and choose between Standard and Strict scan profiles.

== Changelog ==

= 1.0.0 =
* Initial release
* Code Inspector with 30+ threat patterns
* Code Sanitizer for 9 languages
* Code Beautifier with configurable indentation
* Reports with search, filter, and CSV export
* Settings management
* Responsive admin interface

== Upgrade Notice ==

= 1.0.0 =
Initial release of CB Codetizer.


## Phase 4-6 Builder increment

Version 1.2.0 adds the Pages Builder workflow. It stores drafts per WordPress page and maps named HTML/CSS/JavaScript blocks to existing Elementor HTML widget IDs. Sending to Elementor is explicit and creates a backup before writing. The JS Arena screen also adds search and live code counters.
