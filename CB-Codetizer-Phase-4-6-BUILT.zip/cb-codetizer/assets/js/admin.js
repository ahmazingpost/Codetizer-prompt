'use strict';

(function () {
    /**
     * CBCodeTizer global — initialised as soon as this script loads (footer).
     * All page-specific scripts (inspector.js, sanitizer.js, etc.) rely on
     * window.CBCodeTizer being set before DOMContentLoaded fires on their own
     * modules; loading admin.js first (registered without deps but in footer)
     * ensures this is always the case.
     */
    var wrap = document.querySelector('.cb-codetizer-wrap');

    var CBCodeTizer = {

        /**
         * Show a transient notice inside .cb-codetizer-wrap.
         *
         * @param {string} message Text to display.
         * @param {string} type    'success' | 'error' | 'warning' | 'info'
         */
        showToast: function (message, type) {
            var container = document.querySelector('.cb-codetizer-wrap') || document.body;
            var el = document.createElement('div');
            el.className = 'cb-codetizer-notice cb-codetizer-notice-' + (type || 'success');
            el.setAttribute('role', 'alert');
            el.textContent = message;
            container.prepend(el);
            setTimeout(function () {
                if (el.parentNode) el.parentNode.removeChild(el);
            }, 5000);
        },

        /**
         * Perform a WordPress AJAX request, automatically attaching the
         * nonce from whichever nonce field is present on the page.
         *
         * @param  {string} action AJAX action name (without leading wp_ajax_).
         * @param  {Object} data   Key/value pairs to append to the form data.
         * @return {Promise}       Resolves with the parsed JSON response.
         */
        ajax: function (action, data) {
            var formData = new FormData();
            formData.append('action', action);

            // Prefer the explicit action->nonce map localized via
            // wp_localize_script() (see class-assets.php::localize_admin_script()).
            // This is unambiguous even on pages that call multiple AJAX
            // actions bound to different nonce actions. Fall back to the
            // legacy "first nonce field on the page" lookup if the
            // localized data object is unavailable for any reason, so
            // nothing breaks.
            var nonceValue = null;
            if (typeof CBCodeTizerData !== 'undefined' && CBCodeTizerData.nonces && CBCodeTizerData.nonces[action]) {
                nonceValue = CBCodeTizerData.nonces[action];
            } else {
                var nonceField = document.querySelector('[name="cb_codetizer_nonce"]');
                if (nonceField) {
                    nonceValue = nonceField.value;
                }
            }
            if (nonceValue) {
                formData.append('cb_codetizer_nonce', nonceValue);
            }

            if (data && typeof data === 'object') {
                for (var key in data) {
                    if (Object.prototype.hasOwnProperty.call(data, key)) {
                        var val = data[key];
                        if (val !== null && val !== undefined) {
                            formData.append(key, val);
                        }
                    }
                }
            }

            // ajaxurl is always available in WP admin; CBCodeTizerData.ajaxUrl
            // is the same value, localized explicitly as a second source.
            var endpoint = (typeof CBCodeTizerData !== 'undefined' && CBCodeTizerData.ajaxUrl)
                ? CBCodeTizerData.ajaxUrl
                : (typeof ajaxurl !== 'undefined' ? ajaxurl : '/wp-admin/admin-ajax.php');

            return fetch(endpoint, { method: 'POST', body: formData })
                .then(function (response) {
                    // Attempt to parse the JSON body regardless of HTTP status.
                    // WordPress AJAX endpoints return meaningful error messages
                    // (e.g. "Security verification failed…") in the body even on
                    // 403/429/500 responses; we want to surface those to the
                    // user instead of masking them as "Network error: HTTP N".
                    return response.json().then(
                        function (json) {
                            // If the body parsed as valid JSON, return it as-is.
                            // Downstream .then() handlers inspect res.success and
                            // res.data.message. This covers both 2xx (success)
                            // and 4xx/5xx (error with JSON body) responses.
                            return json;
                        },
                        function () {
                            // Body was not valid JSON. This typically means a
                            // fatal PHP error, a 0-byte response, or a network
                            // interruption mid-stream. Fall back to a synthetic
                            // error object so downstream .then() can handle it.
                            var status = response.status || 0;
                            var msg = (status > 0)
                                ? ('Server returned HTTP ' + status + ' with a non-JSON body.')
                                : 'Unable to reach the server. Please check your connection and try again.';
                            return { success: false, data: { message: msg, _http_status: status } };
                        }
                    );
                })
                .catch(function (err) {
                    // True network-level failure (DNS, CORS preflight, offline).
                    var msg = (err && err.message) ? err.message : 'Unknown network error.';
                    CBCodeTizer.showToast('Network error: ' + msg, 'error');
                    return { success: false, data: { message: 'Network error: ' + msg } };
                });
        },

        /**
         * Download a string as a file without a server round-trip.
         *
         * @param {string} content  File content.
         * @param {string} filename Suggested filename.
         * @param {string} mime     MIME type.
         */
        downloadText: function (content, filename, mime) {
            var blob = new Blob([content], { type: mime || 'text/plain' });
            var url  = URL.createObjectURL(blob);
            var a    = document.createElement('a');
            a.href   = url;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        },
    };

    window.CBCodeTizer = CBCodeTizer;

    // ── Danger-button confirmation guard ─────────────────────────────────
    // Intercepts clicks on any .cb-codetizer-btn-danger and requires
    // confirmation before letting the event propagate.
    document.addEventListener('click', function (e) {
        var btn = e.target.closest
            ? e.target.closest('.cb-codetizer-btn-danger')
            : null;

        if (!btn) return;

        var msg = btn.getAttribute('data-confirm') || 'Are you sure?';

        // If the handler is attached inline (e.g., reports clear button),
        // we let its own listener handle confirm. Only intercept buttons
        // that don't already have a click listener with confirm logic.
        // Check for a data-auto-confirm attribute to skip guard.
        if (btn.getAttribute('data-auto-confirm') === 'true') return;

        if (!confirm(msg)) {
            e.preventDefault();
            e.stopImmediatePropagation();
        }
    }, true);

})();
