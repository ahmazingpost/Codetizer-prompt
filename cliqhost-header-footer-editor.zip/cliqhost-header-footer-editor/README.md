# Cliqhost Header & Footer Editor

A small companion plugin for the **Cliqhost Child** theme. Gives you an
admin screen to edit every header/footer link, label, the logo link,
contact info, social links, and legal links — no code editing required.

## Install

1. Upload the `cliqhost-header-footer-editor` folder to
   `/wp-content/plugins/`, or upload it as a zip via
   Plugins → Add New → Upload Plugin.
2. Activate **Cliqhost Header & Footer Editor**.
3. Go to **Settings → Header & Footer** to edit content.

## What you can edit

- **Logo** — logo text and logo link.
- **Header** — the "Talk to an Expert" button's label and link, and all
  7 header navigation links (label + URL, one per line).
- **Footer navigation columns** — all 5 columns (Solutions, Services,
  Industries, Resources, Company), each as one link per line.
- **Footer text** — tagline, newsletter heading/description, copyright.
- **Contact info** — email, phone (both the displayed text and the
  `tel:` link value), and address.
- **Social links** — LinkedIn, X, GitHub, YouTube URLs.
- **Legal links** — Privacy Policy, Terms of Service, Cookie Policy
  (label + URL, one per line).

## Link fields format

Every navigation field is a simple textarea — one link per line, written
as:

```
Label | https://example.com/page/
```

Blank lines and lines without a `|` are ignored. This keeps editing
straightforward (no drag-and-drop builder to break) while still letting
you rename any label or change any URL.

## If the plugin is deactivated

The theme falls back to the original design's content automatically —
nothing breaks, nothing goes blank. Your saved settings stay in the
database and come back the next time you reactivate the plugin.
