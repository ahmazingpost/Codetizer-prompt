<?php
/**
 * Plugin Name:       Cliqhost Header & Footer Editor
 * Description:       Edit the Cliqhost theme's header & footer links, labels, logo link, contact info, social links and legal links from the WordPress admin — no code editing required.
 * Version:           1.0.0
 * Requires PHP:      7.4
 * Author:            Cliqhost
 * Text Domain:       cliqhost-hf-editor
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'CLIQHOST_HF_OPTION_GROUP', 'cliqhost_hf_settings' );

/**
 * All editable fields, grouped for the admin screen.
 * type: text | url | email | textarea | links (one "Label | URL" per line)
 */
function cliqhost_hf_fields() {
	return array(
		'logo' => array(
			'title'  => 'Logo',
			'fields' => array(
				'cliqhost_logo_text' => array( 'label' => 'Logo text', 'type' => 'text', 'default' => 'CLIQHOST' ),
				'cliqhost_logo_link' => array( 'label' => 'Logo link', 'type' => 'url', 'default' => home_url( '/' ) ),
			),
		),
		'header' => array(
			'title'  => 'Header',
			'fields' => array(
				'cliqhost_header_cta_label' => array( 'label' => 'Header button label', 'type' => 'text', 'default' => 'Talk to an Expert' ),
				'cliqhost_header_cta_link'  => array( 'label' => 'Header button link', 'type' => 'url', 'default' => 'contact_page.html' ),
				'cliqhost_nav_header'       => array(
					'label'       => 'Header navigation links',
					'type'        => 'links',
					'description' => 'One link per line, formatted as: Label | URL',
					'default'     => "Solutions | solutions_archive.html\nServices | services_archive.html\nIndustries | industries_archive.html\nCase Studies | case_studies_archive.html\nInsights | insights_archive.html\nAbout | about_page.html\nContact | contact_page.html",
				),
			),
		),
		'footer_nav' => array(
			'title'  => 'Footer navigation columns',
			'fields' => array(
				'cliqhost_nav_footer_solutions'  => array(
					'label'       => 'Solutions column links',
					'type'        => 'links',
					'description' => 'One link per line, formatted as: Label | URL',
					'default'     => "Digital Transformation | solutions_archive.html\nCloud Solutions | solutions_archive.html\nData & Analytics | solutions_archive.html\nCybersecurity | solutions_archive.html\nAI & Automation | solutions_archive.html\nManaged Services | solutions_archive.html",
				),
				'cliqhost_nav_footer_services'   => array(
					'label'       => 'Services column links',
					'type'        => 'links',
					'description' => 'One link per line, formatted as: Label | URL',
					'default'     => "Software Engineering | services_archive.html\nCloud Engineering | services_archive.html\nAI & Machine Learning | services_archive.html\nCybersecurity | services_archive.html\nData Engineering | services_archive.html\nIT Consulting | services_archive.html\nDevOps | services_archive.html\nSupport & Maintenance | services_archive.html",
				),
				'cliqhost_nav_footer_industries' => array(
					'label'       => 'Industries column links',
					'type'        => 'links',
					'description' => 'One link per line, formatted as: Label | URL',
					'default'     => "Finance | industries_archive.html\nHealthcare | industries_archive.html\nRetail | industries_archive.html\nLogistics | industries_archive.html\nEducation | industries_archive.html\nProfessional Services | industries_archive.html",
				),
				'cliqhost_nav_footer_resources'  => array(
					'label'       => 'Resources column links',
					'type'        => 'links',
					'description' => 'One link per line, formatted as: Label | URL',
					'default'     => "Insights | insights_archive.html\nCase Studies | case_studies_archive.html\nCareers | careers_jobs_archive.html\nContact | contact_page.html",
				),
				'cliqhost_nav_footer_company'    => array(
					'label'       => 'Company column links',
					'type'        => 'links',
					'description' => 'One link per line, formatted as: Label | URL',
					'default'     => "About | about_page.html\nContact | contact_page.html\nCareers | careers_jobs_archive.html",
				),
			),
		),
		'footer_copy' => array(
			'title'  => 'Footer text',
			'fields' => array(
				'cliqhost_footer_tagline'         => array( 'label' => 'Footer tagline', 'type' => 'textarea', 'default' => 'CLIQHOST is a global technology consultancy helping organizations build, modernize and scale with confidence.' ),
				'cliqhost_newsletter_heading'     => array( 'label' => 'Newsletter heading', 'type' => 'text', 'default' => 'Stay ahead of the curve' ),
				'cliqhost_newsletter_description' => array( 'label' => 'Newsletter description', 'type' => 'textarea', 'default' => 'Monthly insights on cloud, data, AI and security. No spam — unsubscribe anytime.' ),
				'cliqhost_copyright_text'         => array( 'label' => 'Copyright text', 'type' => 'text', 'default' => '© CLIQHOST. All rights reserved.' ),
			),
		),
		'contact' => array(
			'title'  => 'Contact info',
			'fields' => array(
				'cliqhost_contact_email'       => array( 'label' => 'Contact email', 'type' => 'email', 'default' => 'info@cliqhost.com' ),
				'cliqhost_contact_phone_display' => array( 'label' => 'Contact phone (as displayed)', 'type' => 'text', 'default' => '+1 (555) 013-2456' ),
				'cliqhost_contact_phone_tel'   => array( 'label' => 'Contact phone (tel: link, digits only)', 'type' => 'text', 'default' => '+15550132456' ),
				'cliqhost_contact_address'     => array( 'label' => 'Contact address', 'type' => 'textarea', 'default' => "500 Harbor Boulevard, Suite 900,\nNew York, NY 10005" ),
			),
		),
		'social' => array(
			'title'  => 'Social links',
			'fields' => array(
				'cliqhost_social_linkedin' => array( 'label' => 'LinkedIn URL', 'type' => 'url', 'default' => '' ),
				'cliqhost_social_x'        => array( 'label' => 'X (Twitter) URL', 'type' => 'url', 'default' => '' ),
				'cliqhost_social_github'   => array( 'label' => 'GitHub URL', 'type' => 'url', 'default' => '' ),
				'cliqhost_social_youtube'  => array( 'label' => 'YouTube URL', 'type' => 'url', 'default' => '' ),
			),
		),
		'legal' => array(
			'title'  => 'Legal links',
			'fields' => array(
				'cliqhost_legal_links' => array(
					'label'       => 'Legal links',
					'type'        => 'links',
					'description' => 'One link per line, formatted as: Label | URL',
					'default'     => "Privacy Policy | #\nTerms of Service | #\nCookie Policy | #",
				),
			),
		),
	);
}

/**
 * Get a saved option value, falling back to its declared default.
 */
function cliqhost_hf_get( $key ) {
	foreach ( cliqhost_hf_fields() as $group ) {
		if ( isset( $group['fields'][ $key ] ) ) {
			$default = $group['fields'][ $key ]['default'];
			$value   = get_option( $key, $default );
			return ( '' === $value || null === $value ) ? $default : $value;
		}
	}
	return '';
}

/**
 * Parse a "Label | URL" per-line textarea value into an array of
 * [ 'label' => ..., 'url' => ... ], skipping blank or malformed lines.
 */
function cliqhost_hf_parse_links( $text ) {
	$links = array();
	$lines = preg_split( '/\r\n|\r|\n/', (string) $text );
	foreach ( $lines as $line ) {
		$line = trim( $line );
		if ( '' === $line ) {
			continue;
		}
		if ( false === strpos( $line, '|' ) ) {
			continue;
		}
		list( $label, $url ) = array_map( 'trim', explode( '|', $line, 2 ) );
		if ( '' === $label ) {
			continue;
		}
		$links[] = array(
			'label' => $label,
			'url'   => '' !== $url ? $url : '#',
		);
	}
	return $links;
}

/** Convenience wrapper: get an already-parsed links array for a field. */
function cliqhost_hf_get_links( $key ) {
	return cliqhost_hf_parse_links( cliqhost_hf_get( $key ) );
}

/* -----------------------------------------------------------------------
 * Admin settings screen
 * --------------------------------------------------------------------- */

add_action( 'admin_menu', function () {
	add_options_page(
		'Cliqhost Header & Footer',
		'Header & Footer',
		'manage_options',
		'cliqhost-hf-editor',
		'cliqhost_hf_render_settings_page'
	);
} );

function cliqhost_hf_render_settings_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		return;
	}

	$saved = false;

	if ( isset( $_POST['cliqhost_hf_submit'] ) ) {
		check_admin_referer( 'cliqhost_hf_save', 'cliqhost_hf_nonce' );

		foreach ( cliqhost_hf_fields() as $group ) {
			foreach ( $group['fields'] as $key => $field ) {
				if ( ! isset( $_POST[ $key ] ) ) {
					continue;
				}
				$raw = wp_unslash( $_POST[ $key ] );
				switch ( $field['type'] ) {
					case 'url':
						$clean = esc_url_raw( $raw );
						break;
					case 'email':
						$clean = sanitize_email( $raw );
						break;
					case 'textarea':
						$clean = sanitize_textarea_field( $raw );
						break;
					case 'links':
						// Preserve line breaks; sanitize each line as plain text.
						$clean = implode( "\n", array_map( 'sanitize_text_field', preg_split( '/\r\n|\r|\n/', $raw ) ) );
						break;
					default:
						$clean = sanitize_text_field( $raw );
				}
				update_option( $key, $clean );
			}
		}
		$saved = true;
	}
	?>
	<div class="wrap">
		<h1>Cliqhost Header &amp; Footer</h1>
		<p>Edit the site header and footer content below — logo link, navigation links (label + URL), contact info, social links, and legal links. Changes apply immediately across every page.</p>

		<?php if ( $saved ) : ?>
			<div class="notice notice-success is-dismissible"><p>Saved.</p></div>
		<?php endif; ?>

		<form method="post">
			<?php wp_nonce_field( 'cliqhost_hf_save', 'cliqhost_hf_nonce' ); ?>

			<?php foreach ( cliqhost_hf_fields() as $group ) : ?>
				<h2 class="title"><?php echo esc_html( $group['title'] ); ?></h2>
				<table class="form-table" role="presentation">
					<tbody>
					<?php foreach ( $group['fields'] as $key => $field ) : ?>
						<tr>
							<th scope="row">
								<label for="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $field['label'] ); ?></label>
							</th>
							<td>
								<?php
								$value = cliqhost_hf_get( $key );
								if ( 'textarea' === $field['type'] || 'links' === $field['type'] ) {
									$rows = 'links' === $field['type'] ? 6 : 3;
									printf(
										'<textarea class="large-text code" rows="%d" id="%s" name="%s">%s</textarea>',
										(int) $rows,
										esc_attr( $key ),
										esc_attr( $key ),
										esc_textarea( $value )
									);
								} else {
									$type = in_array( $field['type'], array( 'url', 'email', 'text' ), true ) ? $field['type'] : 'text';
									printf(
										'<input class="regular-text" type="%s" id="%s" name="%s" value="%s">',
										esc_attr( $type ),
										esc_attr( $key ),
										esc_attr( $key ),
										esc_attr( $value )
									);
								}
								if ( ! empty( $field['description'] ) ) {
									printf( '<p class="description">%s</p>', esc_html( $field['description'] ) );
								}
								?>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php endforeach; ?>

			<?php submit_button( 'Save Changes', 'primary', 'cliqhost_hf_submit' ); ?>
		</form>
	</div>
	<?php
}
