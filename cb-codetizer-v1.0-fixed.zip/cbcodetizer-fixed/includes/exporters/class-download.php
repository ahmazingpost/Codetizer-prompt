<?php
/**
 * CB CODETIZER - Download
 *
 * Sends files to the browser as downloads with proper HTTP headers.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CB_Codetizer_Download
 *
 * Utility class that outputs raw content with Content-Disposition
 * headers so the browser treats it as a file download.
 */
class CB_Codetizer_Download {

	/**
	 * Send file content as a browser download.
	 *
	 * Sets Content-Type, Content-Disposition (attachment),
	 * Content-Length, Cache-Control, and Expires headers,
	 * then outputs the content and terminates the request.
	 *
	 * @param string $content   The full file content to send.
	 * @param string $filename  The filename presented to the user.
	 * @param string $mime_type The MIME type. Default 'text/plain'.
	 * @return void
	 */
	public function send_file( string $content, string $filename, string $mime_type = 'text/plain' ): void {
		if ( '' === $content ) {
			wp_die(
				esc_html__( 'No content to download.', 'cb-codetizer' ),
				'',
				array( 'response' => 400 )
			);
		}

		$safe_filename = sanitize_file_name( $filename );

		// phpcs:disable WordPress.Security.Headers
		header( 'Content-Type: ' . $mime_type );
		header( 'Content-Disposition: attachment; filename="' . $safe_filename . '"' );
		header( 'Content-Length: ' . (string) strlen( $content ) );
		header( 'Cache-Control: no-cache, no-store, must-revalidate' );
		header( 'Pragma: no-cache' );
		header( 'Expires: 0' );
		// phpcs:enable WordPress.Security.Headers

		// Clear any output buffering that may interfere.
		while ( ob_get_level() > 0 ) {
			ob_end_clean();
		}

		echo $content; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- raw file content.

		wp_die();
	}

	/**
	 * Generate a filename from the language and send code as a download.
	 *
	 * Uses CB_Codetizer_Helpers::get_language_extensions() to determine
	 * the file extension and CB_Codetizer_Helpers::generate_unique_filename()
	 * for a unique name.
	 *
	 * @param string $code     The code content to send.
	 * @param string $language The language identifier.
	 * @param string $prefix   A filename prefix. Default 'cb-codetizer'.
	 * @return void
	 */
	public function send_code_file( string $code, string $language, string $prefix = 'cb-codetizer' ): void {
		$language    = strtolower( sanitize_text_field( $language ) );
		$extensions  = CB_Codetizer_Helpers::get_language_extensions();
		$ext         = isset( $extensions[ $language ] ) ? $extensions[ $language ][0] : 'txt';
		$filename    = CB_Codetizer_Helpers::generate_unique_filename( $prefix, $ext );

		// Determine MIME type from extension.
		$mime_types = array(
			'html' => 'text/html; charset=utf-8',
			'htm'  => 'text/html; charset=utf-8',
			'svg'  => 'image/svg+xml; charset=utf-8',
			'css'  => 'text/css; charset=utf-8',
			'js'   => 'text/javascript; charset=utf-8',
			'mjs'  => 'text/javascript; charset=utf-8',
			'cjs'  => 'text/javascript; charset=utf-8',
			'php'  => 'application/x-httpd-php; charset=utf-8',
			'json' => 'application/json; charset=utf-8',
			'xml'  => 'text/xml; charset=utf-8',
			'xsl'  => 'text/xml; charset=utf-8',
			'xsd'  => 'text/xml; charset=utf-8',
			'rss'  => 'application/rss+xml; charset=utf-8',
			'atom' => 'application/atom+xml; charset=utf-8',
			'md'   => 'text/markdown; charset=utf-8',
			'txt'  => 'text/plain; charset=utf-8',
		);

		$mime = $mime_types[ $ext ] ?? 'text/plain; charset=utf-8';

		$this->send_file( $code, $filename, $mime );
	}
}
