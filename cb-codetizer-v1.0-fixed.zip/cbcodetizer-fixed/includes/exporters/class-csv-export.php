<?php
/**
 * CB CODETIZER - CSV Export
 *
 * Generates CSV files from report data for download.
 * Uses php://temp and fputcsv for proper escaping.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CB_Codetizer_CSV_Export
 *
 * Produces a UTF-8 BOM–prefixed CSV from an array of report
 * objects and can send it directly as a file download.
 */
class CB_Codetizer_CSV_Export {

	/**
	 * Column headers for the CSV output.
	 *
	 * @var string[]
	 */
	private array $columns = array(
		'ID',
		'Type',
		'Language',
		'Input Summary',
		'Threats Found',
		'Severity Summary',
		'Date',
	);

	/**
	 * Generate CSV content from an array of report objects.
	 *
	 * Includes a UTF-8 BOM (﻿) so that Excel on Windows
	 * correctly detects the encoding.
	 *
	 * @param array<int, object> $reports Array of report row objects.
	 * @return string The complete CSV content.
	 */
	public function generate( array $reports ): string {
		// php://temp stores in memory until a configurable limit, then uses a temp file.
		$handle = fopen( 'php://temp', 'r+' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_fopen

		if ( false === $handle ) {
			return '';
		}

		// Write BOM for Excel UTF-8 compatibility.
		fwrite( $handle, "\xEF\xBB\xBF" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_fwrite

		// Write header row.
		fputcsv( $handle, $this->columns ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_fputcsv

		// Write data rows.
		foreach ( $reports as $report ) {
			$row = array(
				isset( $report->id ) ? (int) $report->id : '',
				isset( $report->scan_type ) ? sanitize_text_field( $report->scan_type ) : '',
				isset( $report->language ) ? sanitize_text_field( $report->language ) : '',
				isset( $report->input_summary ) ? sanitize_textarea_field( $report->input_summary ) : '',
				isset( $report->threats_found ) ? (int) $report->threats_found : 0,
				isset( $report->severity_summary ) ? sanitize_text_field( $report->severity_summary ) : '',
				isset( $report->created_at ) ? sanitize_text_field( $report->created_at ) : '',
			);

			fputcsv( $handle, $row ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_fputcsv
		}

		// Read the full content back.
		rewind( $handle );
		$csv = stream_get_contents( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_stream_get_contents

		fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_read_fclose

		return ( false === $csv ) ? '' : $csv;
	}

	/**
	 * Generate a CSV file and send it as a download.
	 *
	 * Sets the appropriate headers and outputs the CSV content,
	 * then terminates the request with wp_die().
	 *
	 * @param array<int, object> $reports  Array of report row objects.
	 * @param string              $filename Download file name. Default 'cb-codetizer-reports.csv'.
	 * @return void
	 */
	public function download( array $reports, string $filename = 'cb-codetizer-reports.csv' ): void {
		$sanitized_filename = sanitize_file_name( $filename );
		$csv_content       = $this->generate( $reports );

		if ( empty( $csv_content ) ) {
			wp_die(
				esc_html__( 'Failed to generate CSV export.', 'cb-codetizer' ),
				'',
				array( 'response' => 500 )
			);
		}

		$downloader = new CB_Codetizer_Download();
		$downloader->send_file( $csv_content, $sanitized_filename, 'text/csv; charset=utf-8' );
	}
}
