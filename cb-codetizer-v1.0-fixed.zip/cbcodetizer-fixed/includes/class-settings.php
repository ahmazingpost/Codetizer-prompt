<?php
/**
 * CB CODETIZER - Settings
 *
 * Manages all plugin settings with defaults, retrieval, persistence,
 * and bulk save/reset operations.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
        exit;
}

/**
 * Class CB_Codetizer_Settings
 *
 * Provides a centralized interface for reading and writing
 * CB Codetizer plugin settings stored as individual WordPress options.
 */
class CB_Codetizer_Settings {

        /**
         * Array of default values for all plugin settings.
         *
         * @var array<string, mixed>
         */
        private array $defaults;

        /**
         * Mapping of internal setting keys to WordPress option names.
         *
         * @var array<string, string>
         */
        private array $option_keys;

        /**
         * Constructor.
         *
         * Initializes the default settings array and the option-key mapping.
         * No hooks are registered here; this class is used directly by other components.
         */
        public function __construct() {
                $this->defaults = array(
                        'max_upload_size'  => 2097152,
                        'default_language' => 'html',
                        'scan_profile'     => 'standard',
                        'indent_size'      => 4,
                        'indent_type'      => 'spaces',
                        'db_version'       => '1.0.0',
                );

                $this->option_keys = array(
                        'max_upload_size'  => 'cb_codetizer_max_upload_size',
                        'default_language' => 'cb_codetizer_default_language',
                        'scan_profile'     => 'cb_codetizer_scan_profile',
                        'indent_size'      => 'cb_codetizer_indent_size',
                        'indent_type'      => 'cb_codetizer_indent_type',
                        'db_version'       => 'cb_codetizer_db_version',
                );
        }

        /**
         * Retrieve a single setting value by key.
         *
         * Looks up the WordPress option corresponding to the given key.
         * Falls back to the default value when the option is not stored.
         *
         * @param string $key The setting key (e.g., 'max_upload_size').
         * @return mixed The setting value.
         */
        public function get( string $key ): mixed {
                if ( ! isset( $this->option_keys[ $key ] ) ) {
                        return null;
                }

                $option_name = $this->option_keys[ $key ];
                $value       = get_option( $option_name );

                if ( false === $value ) {
                        return $this->defaults[ $key ] ?? null;
                }

                return $value;
        }

        /**
         * Retrieve all settings as an associative array.
         *
         * Each key maps to its current stored value or the default
         * if the option has never been saved.
         *
         * @return array<string, mixed> All settings key => value pairs.
         */
        public function get_all(): array {
                $settings = array();

                foreach ( array_keys( $this->option_keys ) as $key ) {
                        $settings[ $key ] = $this->get( $key );
                }

                return $settings;
        }

        /**
         * Save an array of settings to the database.
         *
         * Each value is sanitized according to its key before being
         * persisted via update_option(). The db_version key is not
         * writable through this method.
         *
         * @param array<string, mixed> $settings Associative array of key => value pairs to save.
         * @return array{success: bool, message: string, updated: int} Result summary.
         */
        public function save( array $settings ): array {
                $protected_keys   = array( 'db_version' );
                $valid_keys       = array_keys( $this->option_keys );
                $updated_count    = 0;

                foreach ( $settings as $key => $value ) {
                        // Skip keys that don't belong to this plugin or are protected.
                        if ( ! in_array( $key, $valid_keys, true ) ) {
                                continue;
                        }

                        if ( in_array( $key, $protected_keys, true ) ) {
                                continue;
                        }

                        $sanitized_value = $this->sanitize_setting( $key, $value );
                        $option_name     = $this->option_keys[ $key ];

                        update_option( $option_name, $sanitized_value );
                        $updated_count++;
                }

                if ( $updated_count > 0 ) {
                        CB_Codetizer_Helpers::log_activity(
                                sprintf(
                                        /* translators: %d: Number of settings updated */
                                        esc_html__( 'Settings updated: %d setting(s) changed.', 'cb-codetizer' ),
                                        $updated_count
                                )
                        );
                }

                return array(
                        'success' => true,
                        'message' => sprintf(
                                /* translators: %d: Number of settings updated */
                                esc_html__( '%d setting(s) saved successfully.', 'cb-codetizer' ),
                                $updated_count
                        ),
                        'updated' => $updated_count,
                );
        }

        /**
         * Reset all settings to their default values.
         *
         * Deletes every option from the database and re-inserts it
         * with the default value. The db_version key is excluded
         * from the reset.
         *
         * @return array{success: bool, message: string} Result summary.
         */
        public function reset(): array {
                $protected_keys = array( 'db_version' );

                foreach ( $this->option_keys as $key => $option_name ) {
                        // Never reset the database version.
                        if ( in_array( $key, $protected_keys, true ) ) {
                                continue;
                        }

                        // Delete the option, then re-add it with the default.
                        delete_option( $option_name );
                        add_option( $option_name, $this->defaults[ $key ] );
                }

                CB_Codetizer_Helpers::log_activity(
                        esc_html__( 'All settings reset to defaults.', 'cb-codetizer' )
                );

                return array(
                        'success' => true,
                        'message' => esc_html__( 'All settings have been reset to their default values.', 'cb-codetizer' ),
                );
        }

        /**
         * Retrieve the default values for all settings.
         *
         * @return array<string, mixed> Defaults array.
         */
        public function get_defaults(): array {
                return $this->defaults;
        }

        /**
         * Sanitize a single setting value based on its key.
         *
         * Applies the appropriate sanitization strategy:
         * - max_upload_size: integer, minimum 1024, maximum 104857600 (100 MB).
         * - default_language: validated against supported languages.
         * - scan_profile: validated against allowed profiles.
         * - indent_size: integer, minimum 1, maximum 8.
         * - indent_type: validated against 'spaces' or 'tabs'.
         * - db_version: sanitized text field.
         *
         * @param string $key   The setting key.
         * @param mixed  $value The raw value to sanitize.
         * @return mixed The sanitized value.
         */
        private function sanitize_setting( string $key, mixed $value ): mixed {
                return match ( $key ) {
                        'max_upload_size' => $this->sanitize_max_upload_size( $value ),
                        'default_language' => $this->sanitize_default_language( $value ),
                        'scan_profile' => $this->sanitize_scan_profile( $value ),
                        'indent_size' => $this->sanitize_indent_size( $value ),
                        'indent_type' => $this->sanitize_indent_type( $value ),
                        'db_version' => sanitize_text_field( (string) $value ),
                        default => sanitize_text_field( (string) $value ),
                };
        }

        /**
         * Sanitize the max upload size setting.
         *
         * @param mixed $value Raw value.
         * @return int Sanitized byte count.
         */
        private function sanitize_max_upload_size( mixed $value ): int {
                // Value is sent in KB from the frontend, convert to bytes.
                $kb    = absint( $value );
                $bytes = $kb * 1024;
                $min   = 102400;   // 100 KB.
                $max   = 10485760; // 10 MB.

                if ( $bytes < $min ) {
                        return $min;
                }

                if ( $bytes > $max ) {
                        return $max;
                }

                return $bytes;
        }

        /**
         * Sanitize the default language setting.
         *
         * @param mixed $value Raw value.
         * @return string A validated language identifier.
         */
        private function sanitize_default_language( mixed $value ): string {
                return CB_Codetizer_Security::validate_language( (string) $value );
        }

        /**
         * Sanitize the scan profile setting.
         *
         * @param mixed $value Raw value.
         * @return string A validated profile identifier.
         */
        private function sanitize_scan_profile( mixed $value ): string {
                $allowed = array( 'standard', 'strict', 'custom' );
                $sanitized = strtolower( sanitize_text_field( (string) $value ) );

                return in_array( $sanitized, $allowed, true ) ? $sanitized : 'standard';
        }

        /**
         * Sanitize the indent size setting.
         *
         * @param mixed $value Raw value.
         * @return int A validated indent size (1-8).
         */
        private function sanitize_indent_size( mixed $value ): int {
                $size = absint( $value );

                if ( $size < 1 ) {
                        return 1;
                }

                if ( $size > 8 ) {
                        return 8;
                }

                return $size;
        }

        /**
         * Sanitize the indent type setting.
         *
         * @param mixed $value Raw value.
         * @return string Either 'spaces' or 'tabs'.
         */
        private function sanitize_indent_type( mixed $value ): string {
                $allowed   = array( 'spaces', 'tabs' );
                $sanitized = strtolower( sanitize_text_field( (string) $value ) );

                return in_array( $sanitized, $allowed, true ) ? $sanitized : 'spaces';
        }
}
