<?php
/**
 * CB CODETIZER - Helpers
 *
 * General-purpose utility methods for language handling, time formatting,
 * file operations, activity logging, and display helpers.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CB_Codetizer_Helpers
 *
 * Static utility class providing helper methods used across
 * the CB Codetizer plugin.
 */
class CB_Codetizer_Helpers {

	/**
	 * Get the list of supported programming/markup languages.
	 *
	 * Returns an associative array mapping internal language identifiers
	 * to their human-readable display labels.
	 *
	 * @return array<string, string> Associative array of language key => label.
	 */
	public static function get_supported_languages(): array {
		return array(
			'html'      => esc_html__( 'HTML', 'cb-codetizer' ),
			'svg'       => esc_html__( 'SVG', 'cb-codetizer' ),
			'css'       => esc_html__( 'CSS', 'cb-codetizer' ),
			'javascript' => esc_html__( 'JavaScript', 'cb-codetizer' ),
			'php'       => esc_html__( 'PHP', 'cb-codetizer' ),
			'json'      => esc_html__( 'JSON', 'cb-codetizer' ),
			'xml'       => esc_html__( 'XML', 'cb-codetizer' ),
			'markdown'  => esc_html__( 'Markdown', 'cb-codetizer' ),
			'txt'       => esc_html__( 'Plain Text', 'cb-codetizer' ),
		);
	}

	/**
	 * Detect the language of a code snippet using simple heuristics.
	 *
	 * Analyzes the code content for characteristic patterns to guess
	 * the programming or markup language.
	 *
	 * @param string $code The code snippet to analyze.
	 * @return string The detected language identifier.
	 */
	public static function detect_language( string $code ): string {
		if ( empty( $code ) ) {
			return 'txt';
		}

		$trimmed = trim( $code );

		// PHP: look for opening PHP tag.
		if ( str_contains( $code, '<?php' ) || str_contains( $code, '<?=' ) ) {
			return 'php';
		}

		// HTML: look for HTML document structure.
		if ( str_contains( $code, '<html' ) || str_contains( $code, '<!DOCTYPE' ) || str_contains( $code, '<HTML' ) || str_contains( $code, '<!doctype' ) ) {
			return 'html';
		}

		// SVG: look for SVG element.
		if ( str_contains( $code, '<svg' ) || str_contains( $code, '<SVG' ) ) {
			return 'svg';
		}

		// CSS: look for CSS-like patterns (selectors with braces).
		if (
			str_contains( $code, '{' )
			&& str_contains( $code, '}' )
			&& (
				preg_match( '/[.#][a-zA-Z][\w-]*\s*\{/', $code )
				|| preg_match( '/@media\s/i', $code )
				|| preg_match( '/body\s*\{|html\s*\{|\*\s*\{/', $code )
				|| preg_match( '/[a-zA-Z-]+\s*:\s*[a-zA-Z0-9#()\s,.-]+;/', $code )
			)
		) {
			return 'css';
		}

		// JavaScript: look for function keywords and JS-specific syntax.
		if (
			( str_contains( $code, 'function' ) && ( str_contains( $code, '=>' ) || preg_match( '/\bvar\s+/', $code ) || preg_match( '/\blet\s+/', $code ) || preg_match( '/\bconst\s+/', $code ) ) )
			|| preg_match( '/\bconsole\.(log|error|warn|info)\s*\(/', $code )
			|| preg_match( '/\bdocument\.(getElementById|querySelector|createElement)\s*\(/', $code )
			|| preg_match( '/\bwindow\.(addEventListener|location|navigator)\b/', $code )
			|| preg_match( '/\brequire\s*\(/', $code )
			|| preg_match( '/\bmodule\.exports\b/', $code )
		) {
			return 'javascript';
		}

		// JSON: starts with { or [ and has typical JSON structure.
		$first_char = substr( $trimmed, 0, 1 );
		if ( ( '{' === $first_char || '[' === $first_char ) ) {
			$last_char = substr( $trimmed, -1 );
			if ( ( '{' === $first_char && '}' === $last_char ) || ( '[' === $first_char && ']' === $last_char ) ) {
				$decoded = json_decode( $code );
				if ( null !== $decoded || json_last_error() === JSON_ERROR_NONE ) {
					return 'json';
				}
			}
		}

		// XML: look for XML declaration or root elements.
		if ( str_contains( $code, '<?xml' ) || preg_match( '/<\?xml\s/i', $code ) ) {
			return 'xml';
		}

		// Markdown: look for Markdown-specific patterns.
		if (
			preg_match( '/^#{1,6}\s+/m', $code )
			|| preg_match( '/^\*\s+/m', $code )
			|| preg_match( '/^-\s+/m', $code )
			|| preg_match( '/```/', $code )
			|| preg_match( '/\*\*.*?\*\*/', $code )
			|| preg_match( '/\[.*?\]\(.*?\)/', $code )
		) {
			return 'markdown';
		}

		// Fallback: treat as plain text.
		return 'txt';
	}

	/**
	 * Format a byte count into a human-readable file size string.
	 *
	 * @param int $bytes The file size in bytes.
	 * @return string Formatted size string, e.g., '2 KB', '1.5 MB'.
	 */
	public static function format_file_size( int $bytes ): string {
		if ( $bytes < 0 ) {
			$bytes = 0;
		}

		if ( $bytes < 1024 ) {
			return sprintf(
				/* translators: %d: Number of bytes */
				__( '%d B', 'cb-codetizer' ),
				$bytes
			);
		}

		if ( $bytes < 1048576 ) {
			$kb = round( $bytes / 1024, 1 );
			return sprintf(
				/* translators: %s: Size in kilobytes */
				__( '%s KB', 'cb-codetizer' ),
				number_format_i18n( $kb, 1 )
			);
		}

		if ( $bytes < 1073741824 ) {
			$mb = round( $bytes / 1048576, 1 );
			return sprintf(
				/* translators: %s: Size in megabytes */
				__( '%s MB', 'cb-codetizer' ),
				number_format_i18n( $mb, 1 )
			);
		}

		$gb = round( $bytes / 1073741824, 2 );
		return sprintf(
			/* translators: %s: Size in gigabytes */
			__( '%s GB', 'cb-codetizer' ),
			number_format_i18n( $gb, 2 )
		);
	}

	/**
	 * Get the CSS class name for a severity badge based on severity level.
	 *
	 * @param string $severity The severity level string (e.g., 'high', 'medium', 'low', 'info').
	 * @return string The CSS class name for the badge.
	 */
	public static function get_severity_color( string $severity ): string {
		$severity_lower = strtolower( sanitize_text_field( $severity ) );

		return match ( $severity_lower ) {
			'high', 'critical' => 'cb-codetizer-badge-high',
			'medium', 'warning' => 'cb-codetizer-badge-medium',
			'low'              => 'cb-codetizer-badge-low',
			'info'             => 'cb-codetizer-badge-info',
			default            => 'cb-codetizer-badge-info',
		};
	}

	/**
	 * Get the human-readable label for a scan type.
	 *
	 * @param string $type The scan type identifier.
	 * @return string The display label for the scan type.
	 */
	public static function get_scan_type_label( string $type ): string {
		return match ( strtolower( sanitize_text_field( $type ) ) ) {
			'inspector'  => esc_html__( 'Inspector', 'cb-codetizer' ),
			'sanitizer'  => esc_html__( 'Sanitizer', 'cb-codetizer' ),
			'beautifier' => esc_html__( 'Beautifier', 'cb-codetizer' ),
			default      => esc_html__( 'Unknown', 'cb-codetizer' ),
		};
	}

	/**
	 * Convert a MySQL datetime string to a human-readable relative time.
	 *
	 * Examples: '2 minutes ago', '1 hour ago', '3 days ago', 'just now'.
	 *
	 * @param string $datetime The MySQL datetime string.
	 * @return string The relative time string.
	 */
	public static function time_ago( string $datetime ): string {
		$timestamp = strtotime( $datetime );

		if ( false === $timestamp ) {
			return esc_html__( 'Invalid date', 'cb-codetizer' );
		}

		$diff = current_time( 'timestamp' ) - $timestamp;

		if ( $diff < 0 ) {
			return esc_html__( 'Just now', 'cb-codetizer' );
		}

		if ( $diff < 60 ) {
			return esc_html__( 'Just now', 'cb-codetizer' );
		}

		$minutes = (int) floor( $diff / 60 );

		if ( $minutes < 60 ) {
			return sprintf(
				/* translators: %d: Number of minutes */
				_n( '%d minute ago', '%d minutes ago', $minutes, 'cb-codetizer' ),
				$minutes
			);
		}

		$hours = (int) floor( $minutes / 60 );

		if ( $hours < 24 ) {
			return sprintf(
				/* translators: %d: Number of hours */
				_n( '%d hour ago', '%d hours ago', $hours, 'cb-codetizer' ),
				$hours
			);
		}

		$days = (int) floor( $hours / 24 );

		if ( $days < 30 ) {
			return sprintf(
				/* translators: %d: Number of days */
				_n( '%d day ago', '%d days ago', $days, 'cb-codetizer' ),
				$days
			);
		}

		$months = (int) floor( $days / 30 );

		if ( $months < 12 ) {
			return sprintf(
				/* translators: %d: Number of months */
				_n( '%d month ago', '%d months ago', $months, 'cb-codetizer' ),
				$months
			);
		}

		$years = (int) floor( $days / 365 );
		return sprintf(
			/* translators: %d: Number of years */
			_n( '%d year ago', '%d years ago', $years, 'cb-codetizer' ),
			$years
		);
	}

	/**
	 * Truncate a string to a specified length and append an ellipsis.
	 *
	 * @param string $text   The text to truncate.
	 * @param int    $length Maximum character length before truncation. Default 100.
	 * @return string The truncated string.
	 */
	public static function truncate( string $text, int $length = 100 ): string {
		if ( mb_strlen( $text ) <= $length ) {
			return $text;
		}

		return mb_substr( $text, 0, $length ) . '&hellip;';
	}

	/**
	 * Get a mapping of supported languages to their common file extensions.
	 *
	 * @return array<string, string[]> Associative array of language => array of extensions.
	 */
	public static function get_language_extensions(): array {
		return array(
			'html'      => array( 'html', 'htm' ),
			'svg'       => array( 'svg' ),
			'css'       => array( 'css' ),
			'javascript' => array( 'js', 'mjs', 'cjs' ),
			'php'       => array( 'php', 'phtml' ),
			'json'      => array( 'json' ),
			'xml'       => array( 'xml', 'xsl', 'xsd', 'rss', 'atom' ),
			'markdown'  => array( 'md', 'markdown', 'mdown', 'mkd' ),
			'txt'       => array( 'txt', 'text', 'log' ),
		);
	}

	/**
	 * Generate a unique filename using a prefix, current timestamp, and extension.
	 *
	 * @param string $prefix    The filename prefix.
	 * @param string $extension The file extension without a leading dot.
	 * @return string The generated unique filename.
	 */
	public static function generate_unique_filename( string $prefix, string $extension ): string {
		$sanitized_prefix    = sanitize_file_name( $prefix );
		$sanitized_extension = sanitize_file_name( strtolower( $extension ) );
		$timestamp           = wp_date( 'Y-m-d-His' );
		$random              = wp_generate_password( 6, false, false );

		return sprintf( '%s-%s-%s.%s', $sanitized_prefix, $timestamp, $random, $sanitized_extension );
	}

	/**
	 * Log an activity message to a transient-based activity log.
	 *
	 * Stores the most recent 20 activity entries in a WordPress transient.
	 * Each entry includes a timestamp and the message text.
	 *
	 * @param string $message The activity message to log.
	 * @return void
	 */
	public static function log_activity( string $message ): void {
		$log = get_transient( 'cb_codetizer_activity_log' );

		if ( ! is_array( $log ) ) {
			$log = array();
		}

		$log[] = array(
			'timestamp' => current_time( 'mysql' ),
			'message'   => $message,
		);

		// Keep only the 20 most recent entries.
		if ( count( $log ) > 20 ) {
			$log = array_slice( $log, -20 );
		}

		// Store for 24 hours.
		set_transient( 'cb_codetizer_activity_log', $log, DAY_IN_SECONDS );
	}

	/**
	 * Retrieve the activity log from the transient.
	 *
	 * Returns an array of activity entries, each containing a
	 * 'timestamp' and 'message' key. Entries are ordered chronologically.
	 *
	 * @return array<int, array{timestamp: string, message: string}> The activity log entries.
	 */
	public static function get_activity_log(): array {
		$log = get_transient( 'cb_codetizer_activity_log' );

		if ( ! is_array( $log ) ) {
			return array();
		}

		return $log;
	}
}
