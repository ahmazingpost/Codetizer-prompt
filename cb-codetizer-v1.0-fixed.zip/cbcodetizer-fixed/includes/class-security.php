<?php
/**
 * CB CODETIZER - Security
 *
 * Provides security utilities for nonce verification, capability checks,
 * input sanitization, file upload validation, and output escaping.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CB_Codetizer_Security
 *
 * Static utility class encapsulating all security-related operations
 * for the CB Codetizer plugin.
 */
class CB_Codetizer_Security {

	/**
	 * Verify a WordPress nonce for AJAX or form submissions.
	 *
	 * Retrieves the nonce value from the request and verifies it
	 * against the expected action. Sends a JSON error response and
	 * terminates execution on failure.
	 *
	 * @param string $action      The nonce action string.
	 * @param string $nonce_field The key used to retrieve the nonce from the request. Default 'cb_codetizer_nonce'.
	 * @return void
	 */
	public static function verify_nonce( string $action, string $nonce_field = 'cb_codetizer_nonce' ): void {
		$nonce = isset( $_REQUEST[ $nonce_field ] ) ? sanitize_text_field( wp_unslash( $_REQUEST[ $nonce_field ] ) ) : '';

		if ( 1 !== wp_verify_nonce( $nonce, $action ) ) {
			wp_send_json_error(
				array(
					'message' => esc_html__( 'Security verification failed. Please refresh the page and try again.', 'cb-codetizer' ),
				),
				403
			);
		}
	}

	/**
	 * Verify that the current user has a specific capability.
	 *
	 * Sends a JSON error response and terminates execution
	 * if the user lacks the required capability.
	 *
	 * @param string $capability The capability to check. Default 'manage_options'.
	 * @return void
	 */
	public static function verify_capability( string $capability = 'manage_options' ): void {
		if ( ! current_user_can( $capability ) ) {
			wp_send_json_error(
				array(
					'message' => esc_html__( 'You do not have permission to perform this action.', 'cb-codetizer' ),
				),
				403
			);
		}
	}

	/**
	 * Recursively sanitize input data.
	 *
	 * Applies appropriate sanitization based on value type:
	 * - Strings: wp_kses_post
	 * - Integers: intval
	 * - Other scalars: sanitize_text_field
	 * - Arrays: recursive map
	 *
	 * @param mixed $data The input data to sanitize.
	 * @return mixed The sanitized data.
	 */
	public static function sanitize_input( mixed $data ): mixed {
		if ( is_array( $data ) ) {
			return array_map( array( __CLASS__, 'sanitize_input' ), $data );
		}

		if ( is_int( $data ) ) {
			return intval( $data );
		}

		if ( is_string( $data ) ) {
			return wp_kses_post( $data );
		}

		if ( is_numeric( $data ) ) {
			return sanitize_text_field( (string) $data );
		}

		return sanitize_text_field( (string) $data );
	}

	/**
	 * Sanitize raw code input for safe processing.
	 *
	 * Strips null bytes, normalizes line endings to \n,
	 * and trims whitespace from both ends.
	 *
	 * @param string $code The raw code string.
	 * @return string The sanitized code string.
	 */
	public static function sanitize_code_input( string $code ): string {
		// Remove null bytes.
		$code = str_replace( "\0", '', $code );

		// Normalize line endings: \r\n -> \n, \r -> \n.
		$code = str_replace( array( "\r\n", "\r" ), "\n", $code );

		// Trim leading/trailing whitespace.
		$code = trim( $code );

		return $code;
	}

	/**
	 * Validate an uploaded file.
	 *
	 * Checks that the file was actually uploaded, is not empty,
	 * is within the configured maximum upload size, and has an
	 * allowed file extension.
	 *
	 * @param array $file The file entry from the $_FILES superglobal.
	 * @return string|WP_Error The sanitized file path on success, WP_Error on failure.
	 */
	public static function check_file_upload( array $file ): string|WP_Error {
		// Verify the file was uploaded via HTTP POST.
		if ( ! isset( $file['tmp_name'] ) || ! is_uploaded_file( $file['tmp_name'] ) ) {
			return new WP_Error(
				'invalid_upload',
				esc_html__( 'No file was uploaded or the upload was intercepted.', 'cb-codetizer' )
			);
		}

		// Check for upload errors.
		if ( isset( $file['error'] ) && UPLOAD_ERR_OK !== $file['error'] ) {
			$upload_errors = array(
				UPLOAD_ERR_INI_SIZE   => esc_html__( 'The uploaded file exceeds the upload_max_filesize directive in php.ini.', 'cb-codetizer' ),
				UPLOAD_ERR_FORM_SIZE  => esc_html__( 'The uploaded file exceeds the MAX_FILE_SIZE directive specified in the HTML form.', 'cb-codetizer' ),
				UPLOAD_ERR_PARTIAL    => esc_html__( 'The uploaded file was only partially uploaded.', 'cb-codetizer' ),
				UPLOAD_ERR_NO_FILE    => esc_html__( 'No file was uploaded.', 'cb-codetizer' ),
				UPLOAD_ERR_NO_TMP_DIR => esc_html__( 'Missing a temporary folder.', 'cb-codetizer' ),
				UPLOAD_ERR_CANT_WRITE => esc_html__( 'Failed to write file to disk.', 'cb-codetizer' ),
				UPLOAD_ERR_EXTENSION  => esc_html__( 'A PHP extension stopped the file upload.', 'cb-codetizer' ),
			);
			$error_message = $upload_errors[ $file['error'] ] ?? esc_html__( 'An unknown upload error occurred.', 'cb-codetizer' );

			return new WP_Error( 'upload_error', $error_message );
		}

		// Check file size against plugin setting.
		$max_size   = (int) get_option( 'cb_codetizer_max_upload_size', 2097152 );
		$file_size  = filesize( $file['tmp_name'] );

		if ( false === $file_size || $file_size > $max_size ) {
			$max_readable = size_format( $max_size );
			return new WP_Error(
				'file_too_large',
				sprintf(
					/* translators: %s: Maximum allowed file size */
					esc_html__( 'The uploaded file exceeds the maximum allowed size of %s.', 'cb-codetizer' ),
					esc_html( $max_readable )
				)
			);
		}

		// Check for empty file.
		if ( 0 === $file_size ) {
			return new WP_Error(
				'file_empty',
				esc_html__( 'The uploaded file is empty.', 'cb-codetizer' )
			);
		}

		// Validate file extension.
		$allowed_extensions = array(
			'html', 'htm', 'svg', 'css', 'js',
			'json', 'xml', 'md', 'txt', 'php',
		);

		$file_info      = wp_check_filetype( $file['name'] );
		$file_extension = strtolower( $file_info['ext'] ?? '' );

		if ( empty( $file_extension ) || ! in_array( $file_extension, $allowed_extensions, true ) ) {
			$allowed_list = implode( ', ', array_map( 'strtoupper', $allowed_extensions ) );
			return new WP_Error(
				'invalid_extension',
				sprintf(
					/* translators: %s: Comma-separated list of allowed extensions */
					esc_html__( 'File type not allowed. Supported extensions: %s.', 'cb-codetizer' ),
					esc_html( $allowed_list )
				)
			);
		}

		// Sanitize and return the file path.
		return sanitize_file_path( $file['tmp_name'] );
	}

	/**
	 * Escape output for safe HTML display.
	 *
	 * Applies esc_html() to strings and recursively maps
	 * over arrays to escape each element.
	 *
	 * @param mixed $data The data to escape.
	 * @return mixed The escaped data.
	 */
	public static function escape_output( mixed $data ): mixed {
		if ( is_array( $data ) ) {
			return array_map( array( __CLASS__, 'escape_output' ), $data );
		}

		if ( is_string( $data ) ) {
			return esc_html( $data );
		}

		return $data;
	}

	/**
	 * Validate a language identifier against the supported list.
	 *
	 * @param string $lang The language identifier to validate.
	 * @return string The validated language identifier, or 'html' as default.
	 */
	public static function validate_language( string $lang ): string {
		$supported = array(
			'html',
			'svg',
			'css',
			'javascript',
			'php',
			'json',
			'xml',
			'markdown',
			'txt',
		);

		$sanitized = strtolower( sanitize_text_field( $lang ) );

		return in_array( $sanitized, $supported, true ) ? $sanitized : 'html';
	}
}
