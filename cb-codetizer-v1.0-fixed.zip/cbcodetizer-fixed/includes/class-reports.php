<?php
/**
 * CB CODETIZER - Reports
 *
 * Handles persistence and retrieval of scan reports stored in the
 * custom database table `{prefix}cb_codetizer_reports`.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CB_Codetizer_Reports
 *
 * Provides CRUD operations and aggregate statistics for scan reports.
 * All database queries use prepared statements via $wpdb.
 */
class CB_Codetizer_Reports {

	/**
	 * WordPress database instance.
	 *
	 * @var wpdb
	 */
	private wpdb $db;

	/**
	 * Full table name including prefix.
	 *
	 * @var string
	 */
	private string $table_name;

	/**
	 * Constructor.
	 */
	public function __construct() {
		global $wpdb;
		$this->db         = $wpdb;
		$this->table_name = $wpdb->prefix . 'cb_codetizer_reports';
	}

	/**
	 * Save a new scan report to the database.
	 *
	 * @param array $data Report data array. Keys:
	 *   - scan_type        (string)
	 *   - language         (string)
	 *   - input_summary    (string)
	 *   - output_summary   (string)
	 *   - results          (array|string — array is JSON-encoded automatically)
	 *   - threats_found    (int)
	 *   - severity_summary (string)
	 *   - score            (int, 0-100)
	 * @return int|false The insert ID on success, or false on failure.
	 */
	public function save( array $data ): int|false {
		$results_value = $data['results'] ?? array();
		if ( is_array( $results_value ) ) {
			$results_json = wp_json_encode( $results_value );
		} else {
			$results_json = is_string( $results_value ) ? $results_value : '{}';
		}

		$score = isset( $data['score'] ) ? max( 0, min( 100, absint( $data['score'] ) ) ) : 100;

		$inserted = $this->db->insert(
			$this->table_name,
			array(
				'scan_type'        => sanitize_text_field( $data['scan_type']        ?? 'inspector' ),
				'language'         => sanitize_text_field( $data['language']         ?? 'html' ),
				'input_summary'    => sanitize_textarea_field( $data['input_summary']  ?? '' ),
				'output_summary'   => sanitize_textarea_field( $data['output_summary'] ?? '' ),
				'results'          => $results_json,
				'threats_found'    => absint( $data['threats_found']    ?? 0 ),
				'severity_summary' => sanitize_text_field( $data['severity_summary'] ?? '' ),
				'score'            => $score,
				'created_at'       => current_time( 'mysql' ),
				'user_id'          => get_current_user_id(),
			),
			array( '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%d', '%s', '%d' )
		);

		if ( false === $inserted ) {
			return false;
		}

		return (int) $this->db->insert_id;
	}

	/**
	 * Retrieve reports with optional filtering, search, and pagination.
	 *
	 * @param array $args {
	 *   @type int    $per_page  Number of items per page. Default 20.
	 *   @type int    $page      Current page number. Default 1.
	 *   @type string $search    Search string against input_summary.
	 *   @type string $scan_type Filter by scan type.
	 * }
	 * @return array{ reports: array, total: int, pages: int, current_page: int }
	 */
	public function get_all( array $args = array() ): array {
		$per_page  = isset( $args['per_page'] ) ? max( 1, absint( $args['per_page'] ) ) : 20;
		$page      = isset( $args['page'] )     ? max( 1, absint( $args['page'] ) )     : 1;
		$offset    = ( $page - 1 ) * $per_page;
		$search    = isset( $args['search'] )   ? sanitize_text_field( wp_unslash( $args['search'] ) ) : '';
		$scan_type = isset( $args['scan_type'] ) ? sanitize_text_field( $args['scan_type'] ) : '';

		// Build WHERE clause.
		$conditions = array();
		$values     = array();

		if ( ! empty( $search ) ) {
			$like          = '%' . $this->db->esc_like( $search ) . '%';
			$conditions[]  = $this->db->prepare( 'input_summary LIKE %s', $like );
		}

		if ( ! empty( $scan_type ) ) {
			$conditions[] = $this->db->prepare( 'scan_type = %s', $scan_type );
		}

		$where = empty( $conditions ) ? '1=1' : implode( ' AND ', $conditions );

		// Total count.
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$total = (int) $this->db->get_var( "SELECT COUNT(*) FROM {$this->table_name} WHERE {$where}" );

		// Data query.
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$sql = $this->db->prepare(
			"SELECT * FROM {$this->table_name} WHERE {$where} ORDER BY created_at DESC LIMIT %d OFFSET %d",
			$per_page,
			$offset
		);

		// phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
		$reports = $this->db->get_results( $sql );

		$pages = $per_page > 0 ? (int) ceil( $total / $per_page ) : 1;

		return array(
			'reports'      => is_array( $reports ) ? $reports : array(),
			'total'        => $total,
			'pages'        => max( 1, $pages ),
			'current_page' => $page,
		);
	}

	/**
	 * Delete a single report by ID.
	 *
	 * @param int $id Report ID.
	 * @return bool True on success.
	 */
	public function delete( int $id ): bool {
		$result = $this->db->delete(
			$this->table_name,
			array( 'id' => $id ),
			array( '%d' )
		);

		return false !== $result;
	}

	/**
	 * Delete all reports (TRUNCATE).
	 *
	 * @return bool True on success.
	 */
	public function delete_all(): bool {
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$result = $this->db->query( "TRUNCATE TABLE {$this->table_name}" );

		if ( false !== $result ) {
			CB_Codetizer_Helpers::log_activity(
				esc_html__( 'All reports cleared.', 'cb-codetizer' )
			);
			return true;
		}

		return false;
	}

	/**
	 * Retrieve aggregate statistics across all reports.
	 *
	 * @return array{ total_scans: int, total_threats: int, most_scanned_language: string, recent_scans: array }
	 */
	public function get_stats(): array {
		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$total_scans = (int) $this->db->get_var( "SELECT COUNT(*) FROM {$this->table_name}" );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$total_threats = (int) $this->db->get_var( "SELECT COALESCE(SUM(threats_found), 0) FROM {$this->table_name}" );

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$most_scanned = $this->db->get_row(
			"SELECT language, COUNT(*) AS cnt FROM {$this->table_name} GROUP BY language ORDER BY cnt DESC LIMIT 1"
		);
		$most_scanned_language = ( $most_scanned && ! empty( $most_scanned->language ) )
			? $most_scanned->language
			: 'html';

		// phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$recent = $this->db->get_results(
			"SELECT id, scan_type, language, threats_found, severity_summary, score, created_at FROM {$this->table_name} ORDER BY created_at DESC LIMIT 5"
		);

		return array(
			'total_scans'           => $total_scans,
			'total_threats'         => $total_threats,
			'most_scanned_language' => $most_scanned_language,
			'recent_scans'          => is_array( $recent ) ? $recent : array(),
		);
	}
}
