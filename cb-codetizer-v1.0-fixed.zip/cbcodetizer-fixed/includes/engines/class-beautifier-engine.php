<?php
/**
 * CB CODETIZER - Beautifier Engine
 *
 * Formats and indents code across all supported languages
 * using language-appropriate strategies.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CB_Codetizer_Beautifier_Engine
 *
 * Provides real code formatting for HTML, SVG, CSS, JavaScript,
 * PHP, JSON, XML, Markdown, and plain text.
 */
class CB_Codetizer_Beautifier_Engine {

	/**
	 * The indentation string built from size and type.
	 *
	 * @var string
	 */
	private string $indent_str;

	/**
	 * Beautify the given code.
	 *
	 * @param string $code        The source code to beautify.
	 * @param string $language    The language identifier.
	 * @param int    $indent_size Number of spaces or 1 tab. Default 4.
	 * @param string $indent_type 'spaces' or 'tabs'. Default 'spaces'.
	 * @return array{beautified_code: string, stats: array{original_lines: int, beautified_lines: int}}
	 */
	public function beautify( string $code, string $language = 'html', int $indent_size = 4, string $indent_type = 'spaces' ): array {
		$this->indent_str = ( 'tabs' === $indent_type ) ? "\t" : str_repeat( ' ', max( 1, $indent_size ) );

		$language  = strtolower( $language );
		$original  = $code;
		$orig_lines = count( explode( "\n", $code ) );

		switch ( $language ) {
			case 'html':
				$code = $this->beautify_html( $code );
				break;
			case 'svg':
				$code = $this->beautify_svg( $code );
				break;
			case 'css':
				$code = $this->beautify_css( $code );
				break;
			case 'javascript':
				$code = $this->beautify_javascript( $code );
				break;
			case 'php':
				$code = $this->beautify_php( $code );
				break;
			case 'json':
				$code = $this->beautify_json( $code );
				break;
			case 'xml':
				$code = $this->beautify_xml( $code );
				break;
			case 'markdown':
				$code = $this->beautify_markdown( $code );
				break;
			case 'txt':
			default:
				$code = $this->beautify_txt( $code );
				break;
		}

		return array(
			'beautified_code' => $code,
			'stats' => array(
				'original_lines'   => $orig_lines,
				'beautified_lines' => count( explode( "\n", $code ) ),
			),
		);
	}

	/* ------------------------------------------------------------------
	 *  HTML beautifier.
	 * ----------------------------------------------------------------- */

	/**
	 * Beautify HTML using DOMDocument when available, with regex fallback.
	 *
	 * @param string $code Raw HTML.
	 * @return string Formatted HTML.
	 */
	private function beautify_html( string $code ): string {
		// Try DOMDocument approach.
		if ( class_exists( 'DOMDocument' ) ) {
			$result = $this->domdocument_beautify( $code, LIBXML_HTML_NOIMPLIED );
			if ( null !== $result ) {
				return $result;
			}
		}

		// Fallback to regex-based indentation.
		return $this->regex_html_beautify( $code );
	}

	/**
	 * Attempt DOMDocument-based HTML formatting.
	 *
	 * @param string $code Raw HTML.
	 * @param int    $options DOMDocument load options.
	 * @return string|null Formatted HTML or null on failure.
	 */
	private function domdocument_beautify( string $code, int $options ): ?string {
		$prev_errors = libxml_use_internal_errors( true );

		$dom = new DOMDocument( '1.0', 'UTF-8' );
		$loaded = $dom->loadHTML( '<?xml encoding="UTF-8">' . $code, $options );

		libxml_clear_errors();
		libxml_use_internal_errors( $prev_errors );

		if ( ! $loaded ) {
			return null;
		}

		$dom->preserveWhiteSpace = false;
		$dom->formatOutput = true;

		$output = $dom->saveXML( $dom->documentElement ?? $dom->firstChild ?? null );

		if ( false === $output ) {
			return null;
		}

		// Remove the XML declaration and the extra wrapping.
		$output = preg_replace( '/^<\?xml[^?]*\?>\s*/', '', $output );

		// Convert self-closing tags like <br/> back to <br>.
		$void_elements = array( 'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr' );
		foreach ( $void_elements as $void ) {
			$output = preg_replace( '/<(' . $void . ')(\s[^>]*)?\s*\/\s*>/i', '<$1$2>', $output );
		}

		// Re-apply our indent string.
		$lines = explode( "\n", $output );
		$result = array();
		foreach ( $lines as $line ) {
			if ( '' === trim( $line ) ) {
				continue;
			}
			// Count leading spaces (DOMDocument uses 2 spaces by default).
			$trimmed = ltrim( $line );
			$leading = strlen( $line ) - strlen( $trimmed );
			// Convert 2-space indent to our indent.
			$level    = (int) floor( $leading / 2 );
			$result[] = str_repeat( $this->indent_str, $level ) . $trimmed;
		}

		return implode( "\n", $result );
	}

	/**
	 * Regex-based HTML beautifier (fallback when DOMDocument fails).
	 *
	 * @param string $code Raw HTML.
	 * @return string Formatted HTML.
	 */
	private function regex_html_beautify( string $code ): string {
		// Normalize whitespace between tags.
		$code = preg_replace( '/>\s+</', ">\n<", $code );

		$lines  = explode( "\n", $code );
		$indent = 0;
		$result = array();

		$void_elements = array( 'area', 'base', 'br', 'col', 'embed', 'hr', 'img', 'input', 'link', 'meta', 'param', 'source', 'track', 'wbr' );

		foreach ( $lines as $line ) {
			$line = trim( $line );
			if ( '' === $line ) {
				continue;
			}

			// Closing tag: decrease indent before printing.
			if ( preg_match( '/^<\/(\w+)/', $line, $m ) ) {
				$tag = strtolower( $m[1] );
				if ( ! in_array( $tag, $void_elements, true ) ) {
					$indent = max( 0, $indent - 1 );
				}
			}

			$result[] = str_repeat( $this->indent_str, $indent ) . $line;

			// Opening tag (not self-closing, not void): increase indent after printing.
			if ( preg_match( '/^<(\w+)/', $line, $m ) ) {
				$tag = strtolower( $m[1] );
				// Skip self-closing and void elements.
				$is_self_closing = (bool) preg_match( '/\/>\s*$/', $line );
				if ( ! $is_self_closing && ! in_array( $tag, $void_elements, true ) ) {
					// Also skip tags that are opened and closed on the same line.
					if ( ! preg_match( '/<\/' . preg_quote( $tag, '/' ) . '\s*>/i', $line ) ) {
						$indent++;
					}
				}
			}
		}

		return implode( "\n", $result );
	}

	/* ------------------------------------------------------------------
	 *  SVG beautifier.
	 * ----------------------------------------------------------------- */

	/**
	 * Beautify SVG (similar approach to HTML).
	 *
	 * @param string $code Raw SVG.
	 * @return string Formatted SVG.
	 */
	private function beautify_svg( string $code ): string {
		if ( class_exists( 'DOMDocument' ) ) {
			$prev_errors = libxml_use_internal_errors( true );
			$dom = new DOMDocument( '1.0', 'UTF-8' );
			$loaded = $dom->loadXML( $code, LIBXML_NOERROR | LIBXML_NOWARNING );

			libxml_clear_errors();
			libxml_use_internal_errors( $prev_errors );

			if ( $loaded ) {
				$dom->preserveWhiteSpace = false;
				$dom->formatOutput = true;
				$output = $dom->saveXML();

				if ( false !== $output ) {
					$lines = explode( "\n", $output );
					$result = array();
					foreach ( $lines as $line ) {
						if ( '' === trim( $line ) ) {
							continue;
						}
						$trimmed = ltrim( $line );
						$leading = strlen( $line ) - strlen( $trimmed );
						$level   = (int) floor( $leading / 2 );
						$result[] = str_repeat( $this->indent_str, $level ) . $trimmed;
					}
					return implode( "\n", $result );
				}
			}
		}

		// Fallback: regex-based (same as HTML).
		return $this->regex_html_beautify( $code );
	}

	/* ------------------------------------------------------------------
	 *  CSS beautifier.
	 * ----------------------------------------------------------------- */

	/**
	 * Beautify CSS code.
	 *
	 * @param string $code Raw CSS.
	 * @return string Formatted CSS.
	 */
	private function beautify_css( string $code ): string {
		// Remove existing excessive whitespace.
		$code = preg_replace( '/\s+/', ' ', $code );

		// Normalize spaces around special characters.
		$code = preg_replace( '/\s*{\s*/', ' {\n', $code );
		$code = preg_replace( '/\s*}\s*/', '\n}\n\n', $code );
		$code = preg_replace( '/\s*;\s*/', ";\n", $code );
		$code = preg_replace( '/\s*,\s*/', ',\n', $code );

		$lines  = explode( "\n", $code );
		$indent = 0;
		$result = array();

		foreach ( $lines as $line ) {
			$line = trim( $line );
			if ( '' === $line ) {
				continue;
			}

			// Closing brace: decrease indent.
			if ( '}' === $line ) {
				$indent = max( 0, $indent - 1 );
				$result[] = str_repeat( $this->indent_str, $indent ) . '}';
				continue;
			}

			// Opening brace on the line: increase indent.
			if ( str_ends_with( $line, '{' ) ) {
				$result[] = str_repeat( $this->indent_str, $indent ) . $line;
				$indent++;
				continue;
			}

			// Selector line (has a comma or ends before a brace that was already split).
			$result[] = str_repeat( $this->indent_str, $indent ) . $line;
		}

		return trim( implode( "\n", $result ) );
	}

	/* ------------------------------------------------------------------
	 *  JavaScript beautifier (character-by-character tokenizer).
	 * ----------------------------------------------------------------- */

	/**
	 * Beautify JavaScript code using a character-level tokenizer.
	 *
	 * @param string $code Raw JS.
	 * @return string Formatted JS.
	 */
	private function beautify_javascript( string $code ): string {
		return $this->tokenize_and_indent( $code, false );
	}

	/* ------------------------------------------------------------------
	 *  PHP beautifier.
	 * ----------------------------------------------------------------- */

	/**
	 * Beautify PHP code.
	 *
	 * Handles <?php ?> tags, then uses the tokenizer on the PHP code.
	 *
	 * @param string $code Raw PHP.
	 * @return string Formatted PHP.
	 */
	private function beautify_php( string $code ): string {
		// Split on PHP tags.
		$parts = preg_split( '/(<\?php|<\?=|\?>)/', $code, -1, PREG_SPLIT_DELIM_CAPTURE );

		if ( false === $parts ) {
			return $this->tokenize_and_indent( $code, true );
		}

		$result  = array();
		$in_php  = false;

		foreach ( $parts as $part ) {
			if ( '' === trim( $part ) ) {
				continue;
			}

			if ( preg_match( '/^<\?(?:php|=)?$/', trim( $part ) ) ) {
				$result[] = trim( $part );
				$in_php = true;
				continue;
			}

			if ( '\?>' === trim( $part ) ) {
				$result[] = trim( $part );
				$in_php = false;
				continue;
			}

			if ( $in_php ) {
				$result[] = $this->tokenize_and_indent( $part, true );
			} else {
				// Outside PHP: return as-is (HTML context).
				$result[] = $part;
			}
		}

		return implode( "\n", $result );
	}

	/* ------------------------------------------------------------------
	 *  JSON beautifier.
	 * ----------------------------------------------------------------- */

	/**
	 * Beautify JSON using json_decode + json_encode.
	 *
	 * @param string $code Raw JSON.
	 * @return string Formatted JSON.
	 */
	private function beautify_json( string $code ): string {
		$decoded = json_decode( $code );

		if ( JSON_ERROR_NONE !== json_last_error() ) {
			// Return with an error comment prepended.
			return '/* CB Codetizer: Invalid JSON — ' . esc_html( json_last_error_msg() ) . ' */' . "\n" . $code;
		}

		$encoded = wp_json_encode( $decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );

		// Re-indent using our indent string.
		if ( false !== $encoded ) {
			return $this->reindent_json( $encoded );
		}

		return $code;
	}

	/**
	 * Re-indent JSON output to use our indent string.
	 *
	 * @param string $code Default 4-space indented JSON.
	 * @return string Re-indented JSON.
	 */
	private function reindent_json( string $code ): string {
		$lines  = explode( "\n", $code );
		$result = array();

		foreach ( $lines as $line ) {
			$trimmed = ltrim( $line );
			$leading = strlen( $line ) - strlen( $trimmed );
			// json_encode uses 4 spaces per level.
			$level   = (int) round( $leading / 4 );
			$result[] = str_repeat( $this->indent_str, $level ) . $trimmed;
		}

		return implode( "\n", $result );
	}

	/* ------------------------------------------------------------------
	 *  XML beautifier.
	 * ----------------------------------------------------------------- */

	/**
	 * Beautify XML using DOMDocument.
	 *
	 * @param string $code Raw XML.
	 * @return string Formatted XML.
	 */
	private function beautify_xml( string $code ): string {
		if ( class_exists( 'DOMDocument' ) ) {
			$prev_errors = libxml_use_internal_errors( true );
			$dom = new DOMDocument( '1.0', 'UTF-8' );
			$loaded = $dom->loadXML( $code, LIBXML_NOERROR | LIBXML_NOWARNING );

			libxml_clear_errors();
			libxml_use_internal_errors( $prev_errors );

			if ( $loaded ) {
				$dom->preserveWhiteSpace = false;
				$dom->formatOutput = true;
				$output = $dom->saveXML();

				if ( false !== $output ) {
					$lines = explode( "\n", $output );
					$result = array();
					foreach ( $lines as $line ) {
						if ( '' === trim( $line ) ) {
							continue;
						}
						$trimmed = ltrim( $line );
						$leading = strlen( $line ) - strlen( $trimmed );
						$level   = (int) floor( $leading / 2 );
						$result[] = str_repeat( $this->indent_str, $level ) . $trimmed;
					}
					return implode( "\n", $result );
				}
			}
		}

		// Fallback: regex-based.
		return $this->regex_html_beautify( $code );
	}

	/* ------------------------------------------------------------------
	 *  Markdown beautifier.
	 * ----------------------------------------------------------------- */

	/**
	 * Beautify Markdown code.
	 *
	 * @param string $code Raw Markdown.
	 * @return string Formatted Markdown.
	 */
	private function beautify_markdown( string $code ): string {
		$lines  = explode( "\n", $code );
		$result = array();
		$prev_was_empty = false;

		foreach ( $lines as $line ) {
			$trimmed = rtrim( $line );

			// Headers.
			if ( preg_match( '/^(#{1,6}\s)/', $trimmed ) ) {
				// Ensure blank line before header (unless first line).
				if ( ! empty( $result ) && ! $prev_was_empty ) {
					$result[] = '';
				}
				$result[] = $trimmed;
				$prev_was_empty = false;
				continue;
			}

			// Code fences.
			if ( preg_match( '/^```/', $trimmed ) ) {
				if ( ! empty( $result ) && ! $prev_was_empty ) {
					$result[] = '';
				}
				$result[] = $trimmed;
				$prev_was_empty = false;
				continue;
			}

			// List items.
			if ( preg_match( '/^\s*[-*+]\s+/', $trimmed ) || preg_match( '/^\s*\d+\.\s+/', $trimmed ) ) {
				// No extra blank line needed between list items.
				$result[] = $trimmed;
				$prev_was_empty = false;
				continue;
			}

			// Empty lines.
			if ( '' === $trimmed ) {
				if ( ! $prev_was_empty ) {
					$result[] = '';
				}
				$prev_was_empty = true;
				continue;
			}

			// Regular paragraph text: ensure blank line before if previous was not empty.
			if ( ! empty( $result ) && ! $prev_was_empty ) {
				$result[] = '';
			}
			$result[] = $trimmed;
			$prev_was_empty = false;
		}

		return trim( implode( "\n", $result ) );
	}

	/* ------------------------------------------------------------------
	 *  TXT beautifier.
	 * ----------------------------------------------------------------- */

	/**
	 * Beautify plain text.
	 *
	 * @param string $code Raw text.
	 * @return string Cleaned text.
	 */
	private function beautify_txt( string $code ): string {
		// Trim trailing whitespace from each line.
		$lines = explode( "\n", $code );
		$lines = array_map( 'rtrim', $lines );

		// Normalize line endings and remove excessive blank lines.
		$result = array();
		$blank  = 0;

		foreach ( $lines as $line ) {
			if ( '' === $line ) {
				$blank++;
				if ( $blank <= 2 ) {
					$result[] = '';
				}
			} else {
				$blank  = 0;
				$result[] = $line;
			}
		}

		return trim( implode( "\n", $result ) );
	}

	/* ==================================================================
	 *  CHARACTER-BY-CHARACTER TOKENIZER for JS / PHP.
	 * ================================================================== */

	/**
	 * Tokenize and re-indent JS or PHP code.
	 *
	 * Walks through the code character by character, recognizing
	 * string delimiters, comments, and block delimiters ({ }) to
	 * produce properly indented output.
	 *
	 * @param string $code   The code to format.
	 * @param bool   $is_php Whether the code is PHP (adds extra handling).
	 * @return string The formatted code.
	 */
	private function tokenize_and_indent( string $code, bool $is_php = false ): string {
		$len    = strlen( $code );
		$i      = 0;
		$output = array();       // Array of output lines.
		$buffer = '';            // Characters accumulated for the current line.
		$indent = 0;             // Current indentation level.
		$prev_char = '';
		$in_string  = false;    // Whether we're inside a string literal.
		$string_delim = '';     // The delimiter character (' " `).
		$template_depth = 0;    // Nesting level for template literals.
		$in_comment  = false;   // Whether we're in a single-line comment.
		$in_block_comment = false; // Whether we're in a multi-line comment.
		$in_regex    = false;   // Whether we're in a regex literal.

		while ( $i < $len ) {
			$ch = $code[ $i ];
			$next = ( $i + 1 < $len ) ? $code[ $i + 1 ] : '';

			// Handle block comments: /* ... */
			if ( ! $in_string && ! $in_comment && ! $in_block_comment && '/' === $ch && '*' === $next ) {
				// Flush current buffer as a line if not empty.
				if ( '' !== trim( $buffer ) ) {
					$output[] = $this->indent_line( $buffer, $indent );
				}
				$buffer = '/*';
				$i += 2;
				$in_block_comment = true;
				continue;
			}

			if ( $in_block_comment ) {
				$buffer .= $ch;
				if ( '*' === $ch && '/' === $next ) {
					$buffer .= '/';
					$output[] = $this->indent_line( $buffer, $indent );
					$buffer = '';
					$in_block_comment = false;
					$i += 2;
					continue;
				}
				// If comment contains a newline, flush.
				if ( "\n" === $ch ) {
					$output[] = $this->indent_line( rtrim( $buffer ), $indent );
					$buffer = '';
				}
				$i++;
				continue;
			}

			// Handle single-line comments: // or # (PHP)
			if ( ! $in_string && ! $in_comment && '/' === $ch && '/' === $next ) {
				if ( '' !== trim( $buffer ) ) {
					$output[] = $this->indent_line( $buffer, $indent );
					$buffer = '';
				}
				// Collect rest of line as comment.
				$comment = '//';
				$i += 2;
				while ( $i < $len && "\n" !== $code[ $i ] ) {
					$comment .= $code[ $i ];
					$i++;
				}
				$output[] = $this->indent_line( $comment, $indent );
				$buffer = '';
				continue;
			}

			// PHP single-line comment: #
			if ( $is_php && ! $in_string && ! $in_comment && '#' === $ch && ! $in_regex ) {
				if ( '' !== trim( $buffer ) ) {
					$output[] = $this->indent_line( $buffer, $indent );
					$buffer = '';
				}
				$comment = '#';
				$i++;
				while ( $i < $len && "\n" !== $code[ $i ] ) {
					$comment .= $code[ $i ];
					$i++;
				}
				$output[] = $this->indent_line( $comment, $indent );
				$buffer = '';
				continue;
			}

			// Handle string literals.
			if ( ! $in_string && ( '\'' === $ch || '"' === $ch || ( '`' === $ch && ! $is_php ) ) ) {
				$in_string     = true;
				$string_delim  = $ch;
				$template_depth = 0;
				$buffer .= $ch;
				$i++;
				continue;
			}

			if ( $in_string ) {
				$buffer .= $ch;

				// Handle escaped characters.
				if ( '\\' === $ch && $i + 1 < $len ) {
					$buffer .= $code[ $i + 1 ];
					$i += 2;
					continue;
				}

				// Template literal nesting.
				if ( '`' === $string_delim && '$' === $ch && '{' === $next ) {
					$template_depth++;
					$buffer .= $next;
					$i += 2;
					continue;
				}
				if ( '`' === $string_delim && '}' === $ch && $template_depth > 0 ) {
					$template_depth--;
					$i++;
					continue;
				}

				// End of string.
				if ( $ch === $string_delim && 0 === $template_depth ) {
					$in_string = false;
				}

				if ( "\n" === $ch && '`' !== $string_delim ) {
					// Multi-line string — output what we have.
					$output[] = $this->indent_line( rtrim( $buffer, "\r" ), $indent );
					$buffer = '';
				}

				$i++;
				continue;
			}

			// Handle regex literals (heuristic: / not in string/comment, preceded by operator/keyword/eol).
			if ( ! $in_regex && '/' === $ch && ! $in_string && ! $in_comment && ! $in_block_comment ) {
				// Check if this could be a regex (not a division operator).
				if ( $this->is_regex_start( $prev_char, $buffer ) ) {
					$in_regex = true;
					$buffer .= $ch;
					$i++;
					while ( $i < $len && $in_regex ) {
						$rc = $code[ $i ];
						$buffer .= $rc;

						if ( '\\' === $rc && $i + 1 < $len ) {
							$buffer .= $code[ $i + 1 ];
							$i += 2;
							continue;
						}

						if ( '/' === $rc ) {
							$in_regex = false;
							// Consume flags.
							while ( $i + 1 < $len && preg_match( '/[gimsuyv]/', $code[ $i + 1 ] ) ) {
								$i++;
								$buffer .= $code[ $i ];
							}
						}

						$i++;
					}
					continue;
				}
			}

			// Handle { and } for indentation.
			if ( '{' === $ch ) {
				$buffer .= $ch;
				$output[] = $this->indent_line( $buffer, $indent );
				$buffer = '';
				$indent++;
				$prev_char = $ch;
				$i++;
				continue;
			}

			if ( '}' === $ch ) {
				if ( '' !== trim( $buffer ) ) {
					$output[] = $this->indent_line( $buffer, $indent );
					$buffer = '';
				}
				$indent = max( 0, $indent - 1 );
				$buffer = '}';
				$output[] = $this->indent_line( $buffer, $indent );
				$buffer = '';
				$prev_char = $ch;
				$i++;
				continue;
			}

			// Handle semicolons and newlines as line breaks.
			if ( ';' === $ch || "\n" === $ch ) {
				$buffer .= $ch;
				$trimmed_buf = trim( $buffer );

				if ( ';' === $ch ) {
					// Only break on semicolons that aren't inside for-loop headers.
					// Heuristic: if the buffer contains 'for' and three semicolons haven't
					// been reached, don't break.
					if ( '' !== $trimmed_buf ) {
						$output[] = $this->indent_line( $buffer, $indent );
						$buffer = '';
					}
				} else {
					// Newline: flush buffer if it has content.
					if ( '' !== $trimmed_buf && ';' !== substr( $trimmed_buf, -1 ) ) {
						// Auto-insert semicolon behavior (JS) or just flush.
						$output[] = $this->indent_line( $buffer, $indent );
						$buffer = '';
					}
					$buffer = '';
				}

				$prev_char = $ch;
				$i++;
				continue;
			}

			// All other characters: accumulate.
			$buffer .= $ch;
			$prev_char = $ch;
			$i++;
		}

		// Flush any remaining buffer.
		if ( '' !== trim( $buffer ) ) {
			$output[] = $this->indent_line( $buffer, $indent );
		}

		// Clean up empty lines: collapse multiple empty lines into at most one.
		$final   = array();
		$empties = 0;
		foreach ( $output as $line ) {
			if ( '' === trim( $line ) ) {
				$empties++;
				if ( $empties <= 1 ) {
					$final[] = '';
				}
			} else {
				$empties = 0;
				$final[] = $line;
			}
		}

		return trim( implode( "\n", $final ) );
	}

	/**
	 * Determine if a '/' character is the start of a regex literal.
	 *
	 * @param string $prev_char The character before the '/'.
	 * @param string $buffer    The current line buffer (for keyword context).
	 * @return bool True if this appears to be a regex start.
	 */
	private function is_regex_start( string $prev_char, string $buffer ): bool {
		// Regex can follow: =, (, [, !, &, |, ;, {, }, ,, :, ?, ~, ^, <, >, +, -, *, /, %, or be at start.
		$after_ops = array( '=', '(', '[', '!', '&', '|', ';', '{', '}', ',', ':', '?', '~', '^', '<', '>', '+', '-', '*', '%', '/' );

		if ( '' === $prev_char || in_array( $prev_char, $after_ops, true ) ) {
			return true;
		}

		// After keywords that can precede regex: return, throw, case, typeof, instanceof, in, of, void, delete, new, yield, await.
		$keywords = array( 'return', 'throw', 'case', 'typeof', 'instanceof', 'void', 'delete', 'new', 'yield', 'await' );
		$trimmed  = rtrim( $buffer );
		foreach ( $keywords as $kw ) {
			if ( preg_match( '/\b' . $kw . '\s*$/', $trimmed ) ) {
				return true;
			}
		}

		return false;
	}

	/**
	 * Apply indentation to a single line.
	 *
	 * @param string $line   The line content (may have leading/trailing whitespace).
	 * @param int    $indent The indentation level.
	 * @return string The indented line with trailing whitespace stripped.
	 */
	private function indent_line( string $line, int $indent ): string {
		$trimmed = trim( $line );
		if ( '' === $trimmed ) {
			return '';
		}
		return str_repeat( $this->indent_str, $indent ) . $trimmed;
	}
}
