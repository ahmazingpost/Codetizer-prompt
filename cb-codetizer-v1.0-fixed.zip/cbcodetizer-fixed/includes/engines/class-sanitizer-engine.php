<?php
/**
 * CB CODETIZER - Sanitizer Engine
 *
 * Removes or neutralizes security-sensitive patterns from code
 * across all supported languages.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CB_Codetizer_Sanitizer_Engine
 *
 * Performs language-specific sanitization by removing dangerous
 * patterns (event handlers, script tags, dangerous URLs, etc.)
 * while preserving the rest of the code structure.
 */
class CB_Codetizer_Sanitizer_Engine {

	/**
	 * Sanitize the given code.
	 *
	 * @param string $code     The source code to sanitize.
	 * @param string $language The language identifier.
	 * @return array{sanitized_code: string, removed_items: array, stats: array}
	 */
	public function sanitize( string $code, string $language = 'html' ): array {
		$language       = strtolower( $language );
		$removed_items  = array();
		$original_size  = strlen( $code );

		switch ( $language ) {
			case 'html':
				list( $code, $removed_items ) = $this->sanitize_html( $code );
				break;
			case 'svg':
				list( $code, $removed_items ) = $this->sanitize_svg( $code );
				break;
			case 'css':
				list( $code, $removed_items ) = $this->sanitize_css( $code );
				break;
			case 'javascript':
				list( $code, $removed_items ) = $this->sanitize_javascript( $code );
				break;
			case 'php':
				list( $code, $removed_items ) = $this->sanitize_php( $code );
				break;
			case 'json':
				list( $code, $removed_items ) = $this->sanitize_json( $code );
				break;
			case 'xml':
				list( $code, $removed_items ) = $this->sanitize_xml( $code );
				break;
			case 'markdown':
				list( $code, $removed_items ) = $this->sanitize_markdown( $code );
				break;
			case 'txt':
			default:
				$code = trim( $code );
				break;
		}

		return array(
			'sanitized_code' => $code,
			'removed_items'  => $removed_items,
			'stats'          => array(
				'items_removed'  => count( $removed_items ),
				'original_size'  => $original_size,
				'cleaned_size'   => strlen( $code ),
			),
		);
	}

	/* ------------------------------------------------------------------
	 *  HTML sanitization.
	 * ----------------------------------------------------------------- */

	/**
	 * Sanitize HTML code.
	 *
	 * @param string $code Raw HTML.
	 * @return array{0: string, 1: array} [sanitized code, removed items].
	 */
	private function sanitize_html( string $code ): array {
		$removed = array();
		$lines   = explode( "\n", $code );

		foreach ( $lines as $ln => &$line ) {
			$line_num = $ln + 1;
			$original = $line;

			// Remove <script> tags and their content.
			while ( preg_match( '/<script\b[^>]*>.*?<\/script\s*>/is', $line, $m ) ) {
				$removed[] = array(
					'type'  => 'script_tag',
					'content' => CB_Codetizer_Helpers::truncate( $m[0], 200 ),
					'line'  => $line_num,
					'reason' => esc_html__( 'Removed <script> tag and its content.', 'cb-codetizer' ),
				);
				$line = str_replace( $m[0], '', $line );
			}

			// Remove self-closing or unclosed <script> tags.
			if ( preg_match( '/<script\b[^>]*\s*\/?>/i', $line, $m ) ) {
				$removed[] = array(
					'type'  => 'script_tag',
					'content' => CB_Codetizer_Helpers::truncate( $m[0], 200 ),
					'line'  => $line_num,
					'reason' => esc_html__( 'Removed <script> tag.', 'cb-codetizer' ),
				);
				$line = preg_replace( '/<script\b[^>]*\s*\/?>/i', '', $line );
			}

			// Remove on* event handler attributes.
			$event_pattern = '/\s+on(?:click|error|load|mouseover|mouseout|mousedown|mouseup|mousemove|keydown|keyup|keypress|focus|blur|change|submit|reset|select|dblclick|contextmenu|drag|dragend|dragenter|dragleave|dragover|dragstart|drop|scroll|wheel|copy|cut|paste|beforeunload|hashchange|message|offline|online|pagehide|pageshow|popstate|resize|storage|unload|touchstart|touchend|touchmove|animationend|animationiteration|animationstart|transitionend)\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s>]*)/i';
			if ( preg_match( $event_pattern, $line, $m ) ) {
				$removed[] = array(
					'type'  => 'event_handler',
					'content' => CB_Codetizer_Helpers::truncate( trim( $m[0] ), 200 ),
					'line'  => $line_num,
					'reason' => esc_html__( 'Removed inline event handler attribute.', 'cb-codetizer' ),
				);
				$line = preg_replace( $event_pattern, '', $line );
			}

			// Remove javascript: and vbscript: URLs from href/src/action.
			$url_pattern = '/((?:href|src|action|formaction|data|poster|background)\s*=\s*)(?:"([^"]*?)"|\'([^\']*?)\')/i';
			$line = preg_replace_callback(
				$url_pattern,
				function ( $matches ) use ( &$removed, $line_num ) {
					$attr  = $matches[1];
					$value = $matches[2] ?? $matches[3] ?? '';

					if ( preg_match( '/^(?:javascript|vbscript)\s*:/i', $value ) ) {
						$removed[] = array(
							'type'  => 'dangerous_url',
							'content' => CB_Codetizer_Helpers::truncate( $value, 200 ),
							'line'  => $line_num,
							'reason' => esc_html__( 'Removed javascript:/vbscript: URL from attribute.', 'cb-codetizer' ),
						);
						return $attr . '"#sanitized"';
					}

					return $matches[0];
				},
				$line
			);

			// Remove <iframe>, <embed>, <object> tags.
			$embed_pattern = '/<(iframe|embed|object)\b[^>]*>.*?<\/\1\s*>/is';
			while ( preg_match( $embed_pattern, $line, $m ) ) {
				$removed[] = array(
					'type'  => 'embedded_content',
					'content' => CB_Codetizer_Helpers::truncate( $m[0], 200 ),
					'line'  => $line_num,
					'reason' => esc_html__( 'Removed embedded content tag.', 'cb-codetizer' ),
				);
				$line = str_replace( $m[0], '', $line );
			}
			// Also remove self-closing or unclosed versions.
			$embed_sc = '/<(iframe|embed|object)\b[^>]*\s*\/?>/i';
			while ( preg_match( $embed_sc, $line, $m ) ) {
				$removed[] = array(
					'type'  => 'embedded_content',
					'content' => CB_Codetizer_Helpers::truncate( $m[0], 200 ),
					'line'  => $line_num,
					'reason' => esc_html__( 'Removed embedded content tag.', 'cb-codetizer' ),
				);
				$line = preg_replace( $embed_sc, '', $line, 1 );
			}

			// Remove data: URIs.
			$data_uri_pattern = '/data\s*:\s*[a-zA-Z0-9+\-]+\/[a-zA-Z0-9+\-]+[^"\'\s>]*/i';
			if ( preg_match( $data_uri_pattern, $line, $m ) ) {
				$removed[] = array(
					'type'  => 'data_uri',
					'content' => CB_Codetizer_Helpers::truncate( $m[0], 200 ),
					'line'  => $line_num,
					'reason' => esc_html__( 'Removed data: URI.', 'cb-codetizer' ),
				);
				$line = preg_replace( $data_uri_pattern, '#sanitized', $line );
			}

			// Remove <base> tag.
			if ( preg_match( '/<base\b[^>]*>/i', $line, $m ) ) {
				$removed[] = array(
					'type'  => 'base_tag',
					'content' => CB_Codetizer_Helpers::truncate( $m[0], 200 ),
					'line'  => $line_num,
					'reason' => esc_html__( 'Removed <base> tag.', 'cb-codetizer' ),
				);
				$line = preg_replace( '/<base\b[^>]*>/i', '', $line );
			}

			// Sanitize <meta http-equiv="refresh"> by removing redirect URLs.
			$meta_refresh = '/(<meta[^>]+http-equiv\s*=\s*["\']?refresh["\']?[^>]+content\s*=\s*["\']?)\d+\s*;\s*url\s*=\s*[^"\'>]+(["\']?[^>]*>)/i';
			if ( preg_match( $meta_refresh, $line, $m ) ) {
				$removed[] = array(
					'type'  => 'meta_refresh',
					'content' => CB_Codetizer_Helpers::truncate( $m[0], 200 ),
					'line'  => $line_num,
					'reason' => esc_html__( 'Removed redirect URL from meta refresh tag.', 'cb-codetizer' ),
				);
				$line = preg_replace( $meta_refresh, '$1 0$2', $line );
			}

			// Remove inline styles with expression/behavior/-moz-binding.
			$dangerous_style = '/style\s*=\s*(?:"[^"]*(?:expression|behavior|\-moz\-binding)[^"*]*"|\'[^\']*(?:expression|behavior|\-moz\-binding)[^\']*\')/i';
			if ( preg_match( $dangerous_style, $line, $m ) ) {
				$removed[] = array(
					'type'  => 'dangerous_inline_style',
					'content' => CB_Codetizer_Helpers::truncate( trim( $m[0] ), 200 ),
					'line'  => $line_num,
					'reason' => esc_html__( 'Removed inline style with dangerous CSS property.', 'cb-codetizer' ),
				);
				$line = preg_replace( $dangerous_style, '', $line );
			}

			if ( $original !== $line ) {
				// Line was modified.
			}
		}
		unset( $line );

		return array( implode( "\n", $lines ), $removed );
	}

	/* ------------------------------------------------------------------
	 *  SVG sanitization.
	 * ----------------------------------------------------------------- */

	/**
	 * Sanitize SVG code.
	 *
	 * @param string $code Raw SVG.
	 * @return array{0: string, 1: array}
	 */
	private function sanitize_svg( string $code ): array {
		$removed = array();
		$lines   = explode( "\n", $code );

		foreach ( $lines as $ln => &$line ) {
			$line_num = $ln + 1;

			// Remove <script> tags and content.
			while ( preg_match( '/<script\b[^>]*>.*?<\/script\s*>/is', $line, $m ) ) {
				$removed[] = array(
					'type'    => 'svg_script',
					'content' => CB_Codetizer_Helpers::truncate( $m[0], 200 ),
					'line'    => $line_num,
					'reason'  => esc_html__( 'Removed <script> from SVG.', 'cb-codetizer' ),
				);
				$line = str_replace( $m[0], '', $line );
			}
			$line = preg_replace( '/<script\b[^>]*\s*\/?>/i', '', $line );

			// Remove on* event handlers.
			$event_pattern = '/\s+on(?:click|error|load|mouseover|mouseout|mousedown|mouseup|focus|blur|begin|end|repeat)\s*=\s*(?:"[^"]*"|\'[^\']*\'|[^\s>]*)/i';
			if ( preg_match( $event_pattern, $line, $m ) ) {
				$removed[] = array(
					'type'    => 'svg_event_handler',
					'content' => CB_Codetizer_Helpers::truncate( trim( $m[0] ), 200 ),
					'line'    => $line_num,
					'reason'  => esc_html__( 'Removed inline event handler from SVG.', 'cb-codetizer' ),
				);
				$line = preg_replace( $event_pattern, '', $line );
			}

			// Remove javascript: URLs from href/xlink:href.
			$line = preg_replace_callback(
				'/(?:href|xlink:href)\s*=\s*(?:"([^"]*?)"|\'([^\']*?)\')/i',
				function ( $matches ) use ( &$removed, $line_num ) {
					$value = $matches[1] ?? $matches[2] ?? '';
					if ( preg_match( '/^(?:javascript|vbscript)\s*:/i', $value ) ) {
						$removed[] = array(
							'type'    => 'svg_dangerous_url',
							'content' => CB_Codetizer_Helpers::truncate( $value, 200 ),
							'line'    => $line_num,
							'reason'  => esc_html__( 'Removed javascript: URL from SVG.', 'cb-codetizer' ),
						);
						return 'href="#sanitized"';
					}
					return $matches[0];
				},
				$line
			);

			// Remove external references to different domains (xlink:href to http/https).
			$line = preg_replace_callback(
				'/(?:href|xlink:href)\s*=\s*(?:"(https?:\/\/[^"\'>]+)"|\'(https?:\/\/[^\'\'>]+)\')/i',
				function ( $matches ) use ( &$removed, $line_num ) {
					$url    = $matches[1] ?? $matches[2] ?? '';
					$parsed = wp_parse_url( $url );
					$site   = wp_parse_url( home_url() );
					if ( isset( $parsed['host'], $site['host'] ) && $parsed['host'] !== $site['host'] ) {
						$removed[] = array(
							'type'    => 'svg_external_reference',
							'content' => CB_Codetizer_Helpers::truncate( $url, 200 ),
							'line'    => $line_num,
							'reason'  => esc_html__( 'Removed external reference from SVG.', 'cb-codetizer' ),
						);
						return 'href="#removed-external"';
					}
					return $matches[0];
				},
				$line
			);

			// Sanitize <set>/<animate> with event-based begin.
			$anim_pattern = '/<(set|animate)\b([^>]*?)\bbegin\s*=\s*(?:"([^"]*(?:click|mouseover|focus|load)[^"]*)"|\'([^\']*(?:click|mouseover|focus|load)[^\']*)\')([^>]*)>/i';
			$line = preg_replace_callback(
				$anim_pattern,
				function ( $matches ) use ( &$removed, $line_num ) {
					$tag     = $matches[1];
					$pre     = $matches[2];
					$post    = $matches[5];
					$removed[] = array(
						'type'    => 'svg_event_animation',
						'content' => CB_Codetizer_Helpers::truncate( $matches[0], 200 ),
						'line'    => $line_num,
						'reason'  => esc_html__( 'Removed event-based begin from SVG animation.', 'cb-codetizer' ),
					);
					return '<' . $tag . $pre . ' begin="0s"' . $post . '>';
				},
				$line
			);

			// Remove data: URIs.
			$data_pattern = '/data\s*:\s*[a-zA-Z0-9+\-]+\/[a-zA-Z0-9+\-]+[^"\'\s>]*/i';
			if ( preg_match( $data_pattern, $line, $m ) ) {
				$removed[] = array(
					'type'    => 'svg_data_uri',
					'content' => CB_Codetizer_Helpers::truncate( $m[0], 200 ),
					'line'    => $line_num,
					'reason'  => esc_html__( 'Removed data: URI from SVG.', 'cb-codetizer' ),
				);
				$line = preg_replace( $data_pattern, '#sanitized', $line );
			}
		}
		unset( $line );

		return array( implode( "\n", $lines ), $removed );
	}

	/* ------------------------------------------------------------------
	 *  CSS sanitization.
	 * ----------------------------------------------------------------- */

	/**
	 * Sanitize CSS code.
	 *
	 * @param string $code Raw CSS.
	 * @return array{0: string, 1: array}
	 */
	private function sanitize_css( string $code ): array {
		$removed = array();
		$lines   = explode( "\n", $code );

		foreach ( $lines as $ln => &$line ) {
			$line_num = $ln + 1;

			// Remove expression().
			if ( preg_match( '/expression\s*\([^)]*\)/i', $line, $m ) ) {
				$removed[] = array(
					'type'    => 'css_expression',
					'content' => CB_Codetizer_Helpers::truncate( $m[0], 200 ),
					'line'    => $line_num,
					'reason'  => esc_html__( 'Removed CSS expression().', 'cb-codetizer' ),
				);
				$line = preg_replace( '/expression\s*\([^)]*\)/i', '/* removed expression */', $line );
			}

			// Remove -moz-binding.
			if ( preg_match( '/\-moz\-binding\s*:[^;]+;/i', $line, $m ) ) {
				$removed[] = array(
					'type'    => 'css_moz_binding',
					'content' => CB_Codetizer_Helpers::truncate( trim( $m[0] ), 200 ),
					'line'    => $line_num,
					'reason'  => esc_html__( 'Removed -moz-binding property.', 'cb-codetizer' ),
				);
				$line = preg_replace( '/\-moz\-binding\s*:[^;]+;/i', '', $line );
			}

			// Remove behavior property.
			if ( preg_match( '/behavior\s*:[^;]+;/i', $line, $m ) ) {
				$removed[] = array(
					'type'    => 'css_behavior',
					'content' => CB_Codetizer_Helpers::truncate( trim( $m[0] ), 200 ),
					'line'    => $line_num,
					'reason'  => esc_html__( 'Removed behavior property.', 'cb-codetizer' ),
				);
				$line = preg_replace( '/behavior\s*:[^;]+;/i', '', $line );
			}

			// Sanitize url() to remove javascript:/data:.
			$line = preg_replace_callback(
				'/url\s*\(\s*(?:"([^"]*?)"|\'([^\']*?)\'|([^)\s]*?))\s*\)/i',
				function ( $matches ) use ( &$removed, $line_num ) {
					$value = $matches[1] ?? $matches[2] ?? $matches[3] ?? '';
					if ( preg_match( '/^(?:javascript|vbscript|data)\s*:/i', $value ) ) {
						$removed[] = array(
							'type'    => 'css_dangerous_url',
							'content' => CB_Codetizer_Helpers::truncate( $value, 200 ),
							'line'    => $line_num,
							'reason'  => esc_html__( 'Removed dangerous URL from CSS url().', 'cb-codetizer' ),
						);
						return 'url(/* removed */)';
					}
					return $matches[0];
				},
				$line
			);
		}
		unset( $line );

		return array( implode( "\n", $lines ), $removed );
	}

	/* ------------------------------------------------------------------
	 *  JavaScript sanitization.
	 * ----------------------------------------------------------------- */

	/**
	 * Sanitize JavaScript code.
	 *
	 * @param string $code Raw JS.
	 * @return array{0: string, 1: array}
	 */
	private function sanitize_javascript( string $code ): array {
		$removed = array();
		$lines   = explode( "\n", $code );

		foreach ( $lines as $ln => &$line ) {
			$line_num = $ln + 1;

			// Comment out eval().
			if ( preg_match( '/\beval\s*\(/', $line ) ) {
				$removed[] = array(
					'type'    => 'js_eval',
					'content' => CB_Codetizer_Helpers::truncate( trim( $line ), 200 ),
					'line'    => $line_num,
					'reason'  => esc_html__( 'Commented out eval() call.', 'cb-codetizer' ),
				);
				$line = '/* [CB Codetizer] eval() removed */ ' . preg_replace( '/\beval\s*\(/', '/* eval */ (', $line );
			}

			// Comment out document.write.
			if ( preg_match( '/document\.write\s*\(/', $line ) ) {
				$removed[] = array(
					'type'    => 'js_document_write',
					'content' => CB_Codetizer_Helpers::truncate( trim( $line ), 200 ),
					'line'    => $line_num,
					'reason'  => esc_html__( 'Commented out document.write() call.', 'cb-codetizer' ),
				);
				$line = '/* [CB Codetizer] document.write() removed */ ' . preg_replace( '/document\.write\s*\(/', '/* document.write */ (', $line );
			}

			// Comment out new Function() constructor.
			if ( preg_match( '/(?:^|[=(:,\s])\s*new\s+Function\s*\(/', $line ) ) {
				$removed[] = array(
					'type'    => 'js_function_constructor',
					'content' => CB_Codetizer_Helpers::truncate( trim( $line ), 200 ),
					'line'    => $line_num,
					'reason'  => esc_html__( 'Commented out new Function() constructor.', 'cb-codetizer' ),
				);
				$line = '/* [CB Codetizer] new Function() removed */ ' . preg_replace( '/new\s+Function\s*\(/', '/* new Function */ (', $line );
			}

			// Add origin check comment near postMessage.
			if ( preg_match( '/\.postMessage\s*\(/', $line ) && ! preg_match( '/event\.origin/', $line ) ) {
				$removed[] = array(
					'type'    => 'js_postmessage',
					'content' => CB_Codetizer_Helpers::truncate( trim( $line ), 200 ),
					'line'    => $line_num,
					'reason'  => esc_html__( 'Added origin-check reminder for postMessage.', 'cb-codetizer' ),
				);
				$line = '/* [CB Codetizer] WARNING: Verify event.origin before processing postMessage data */ ' . $line;
			}

			// Comment out prototype pollution.
			if ( preg_match( '/(__proto__|constructor\.prototype|\.prototype\[)/', $line ) ) {
				$removed[] = array(
					'type'    => 'js_prototype_pollution',
					'content' => CB_Codetizer_Helpers::truncate( trim( $line ), 200 ),
					'line'    => $line_num,
					'reason'  => esc_html__( 'Commented out prototype pollution pattern.', 'cb-codetizer' ),
				);
				$line = '/* [CB Codetizer] Prototype pollution pattern removed */ /* ' . ltrim( $line ) . ' */';
			}

			// Wrap innerHTML assignments with warning.
			if ( preg_match( '/\.innerHTML\s*=/', $line ) ) {
				$removed[] = array(
					'type'    => 'js_innerhtml',
					'content' => CB_Codetizer_Helpers::truncate( trim( $line ), 200 ),
					'line'    => $line_num,
					'reason'  => esc_html__( 'Added sanitization warning for innerHTML.', 'cb-codetizer' ),
				);
				$line = '/* [CB Codetizer] WARNING: Sanitize value before innerHTML assignment */ ' . $line;
			}
		}
		unset( $line );

		return array( implode( "\n", $lines ), $removed );
	}

	/* ------------------------------------------------------------------
	 *  PHP sanitization.
	 * ----------------------------------------------------------------- */

	/**
	 * Sanitize PHP code.
	 *
	 * @param string $code Raw PHP.
	 * @return array{0: string, 1: array}
	 */
	private function sanitize_php( string $code ): array {
		$removed = array();
		$lines   = explode( "\n", $code );

		foreach ( $lines as $ln => &$line ) {
			$line_num = $ln + 1;

			// Comment out eval().
			if ( preg_match( '/\beval\s*\(/', $line ) ) {
				$removed[] = array(
					'type'    => 'php_eval',
					'content' => CB_Codetizer_Helpers::truncate( trim( $line ), 200 ),
					'line'    => $line_num,
					'reason'  => esc_html__( 'Commented out eval().', 'cb-codetizer' ),
				);
				$line = '// [CB Codetizer] eval() removed — ' . $line;
				$line = preg_replace( '/\beval\s*\(/', '// eval(', $line );
			}

			// Comment out command execution functions.
			$cmd_pattern = '/\b(system|exec|passthru|shell_exec|proc_open|popen)\s*\(/';
			if ( preg_match( $cmd_pattern, $line, $m ) ) {
				$removed[] = array(
					'type'    => 'php_command_execution',
					'content' => CB_Codetizer_Helpers::truncate( trim( $line ), 200 ),
					'line'    => $line_num,
					'reason'  => sprintf(
						/* translators: %s: Function name */
						esc_html__( 'Commented out %s().', 'cb-codetizer' ),
						esc_html( $m[1] )
					),
				);
				$line = '// [CB Codetizer] ' . $m[1] . '() removed — ' . $line;
				$line = preg_replace( '/\b(' . $m[1] . ')\s*\(/', '// $1(', $line );
			}

			// Add sanitization comment near direct superglobal output.
			if ( preg_match( '/(?:echo|print)\s.*\$(_GET|_POST|_REQUEST|_COOKIE)\b/', $line ) ) {
				$removed[] = array(
					'type'    => 'php_superglobal_output',
					'content' => CB_Codetizer_Helpers::truncate( trim( $line ), 200 ),
					'line'    => $line_num,
					'reason'  => esc_html__( 'Added sanitization warning for superglobal output.', 'cb-codetizer' ),
				);
				$line = '// [CB Codetizer] WARNING: Sanitize superglobal before output (esc_html, wp_kses) — ' . $line;
			}

			// Comment out preg_replace with /e modifier.
			if ( preg_match( '/preg_replace\s*\(\s*["\'][^"\']*\/e[^"\']*["\']/', $line ) ) {
				$removed[] = array(
					'type'    => 'php_preg_replace_e',
					'content' => CB_Codetizer_Helpers::truncate( trim( $line ), 200 ),
					'line'    => $line_num,
					'reason'  => esc_html__( 'Commented out preg_replace with /e modifier.', 'cb-codetizer' ),
				);
				$line = '// [CB Codetizer] preg_replace /e modifier removed — ' . $line;
				$line = preg_replace( '/(preg_replace)\s*\(/', '// $1(', $line );
			}

			// Comment out unserialize().
			if ( preg_match( '/\bunserialize\s*\(/', $line ) ) {
				$removed[] = array(
					'type'    => 'php_unserialize',
					'content' => CB_Codetizer_Helpers::truncate( trim( $line ), 200 ),
					'line'    => $line_num,
					'reason'  => esc_html__( 'Commented out unserialize().', 'cb-codetizer' ),
				);
				$line = '// [CB Codetizer] unserialize() removed — ' . $line;
				$line = preg_replace( '/\bunserialize\s*\(/', '// unserialize(', $line );
			}

			// Add warning near dynamic include/require.
			if ( preg_match( '/(?:include|require|include_once|require_once)\s*\(\s*\$/', $line ) ) {
				$removed[] = array(
					'type'    => 'php_dynamic_include',
					'content' => CB_Codetizer_Helpers::truncate( trim( $line ), 200 ),
					'line'    => $line_num,
					'reason'  => esc_html__( 'Added warning for dynamic include.', 'cb-codetizer' ),
				);
				$line = '// [CB Codetizer] WARNING: Validate file path — ' . $line;
			}

			// Comment out backtick operator.
			if ( preg_match( '/`[^`]+`/', $line, $m ) ) {
				$removed[] = array(
					'type'    => 'php_backtick',
					'content' => CB_Codetizer_Helpers::truncate( trim( $m[0] ), 200 ),
					'line'    => $line_num,
					'reason'  => esc_html__( 'Commented out backtick shell execution.', 'cb-codetizer' ),
				);
				$line = str_replace( $m[0], '/* [CB Codetizer] backtick removed: ' . str_replace( '`', '\`', $m[0] ) . ' */', $line );
			}
		}
		unset( $line );

		return array( implode( "\n", $lines ), $removed );
	}

	/* ------------------------------------------------------------------
	 *  JSON sanitization.
	 * ----------------------------------------------------------------- */

	/**
	 * Sanitize JSON code by removing prototype pollution keys.
	 *
	 * @param string $code Raw JSON.
	 * @return array{0: string, 1: array}
	 */
	private function sanitize_json( string $code ): array {
		$removed = array();
		$lines   = explode( "\n", $code );

		foreach ( $lines as $ln => &$line ) {
			$line_num = $ln + 1;

			// Remove __proto__, constructor, prototype keys.
			$proto_pattern = '/"(__proto__|constructor|prototype)"\s*:\s*(?:[^,}\]]+)/';
			if ( preg_match( $proto_pattern, $line, $m ) ) {
				$removed[] = array(
					'type'    => 'json_prototype_key',
					'content' => CB_Codetizer_Helpers::truncate( trim( $m[0] ), 200 ),
					'line'    => $line_num,
					'reason'  => sprintf(
						/* translators: %s: Key name */
						esc_html__( 'Removed prototype pollution key "%s".', 'cb-codetizer' ),
						esc_html( $m[1] )
					),
				);
				$line = preg_replace( $proto_pattern, '', $line );
				// Clean up trailing comma or leading comma artifacts.
				$line = preg_replace( '/^\s*,\s*/', '', $line );
			}
		}
		unset( $line );

		$cleaned = implode( "\n", $lines );

		// Validate the result is still valid JSON.
		$decoded = json_decode( $cleaned );
		if ( null !== $decoded || json_last_error() === JSON_ERROR_NONE ) {
			// Re-encode to normalize formatting.
			$cleaned = wp_json_encode( $decoded, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
			if ( false === $cleaned ) {
				$cleaned = implode( "\n", $lines );
			}
		}

		return array( $cleaned, $removed );
	}

	/* ------------------------------------------------------------------
	 *  XML sanitization.
	 * ----------------------------------------------------------------- */

	/**
	 * Sanitize XML code.
	 *
	 * @param string $code Raw XML.
	 * @return array{0: string, 1: array}
	 */
	private function sanitize_xml( string $code ): array {
		$removed = array();
		$lines   = explode( "\n", $code );

		foreach ( $lines as $ln => &$line ) {
			$line_num = $ln + 1;

			// Remove DOCTYPE with ENTITY declarations.
			if ( preg_match( '/<!DOCTYPE\s[^>]*<!ENTITY\s/i', $line ) ) {
				$removed[] = array(
					'type'    => 'xml_doctype_entity',
					'content' => CB_Codetizer_Helpers::truncate( trim( $line ), 200 ),
					'line'    => $line_num,
					'reason'  => esc_html__( 'Removed DOCTYPE with ENTITY declaration (XXE risk).', 'cb-codetizer' ),
				);
				$line = '/* [CB Codetizer] DOCTYPE with ENTITY removed */';
			}

			// Remove standalone ENTITY declarations.
			if ( preg_match( '/<!ENTITY\s/i', $line ) ) {
				$removed[] = array(
					'type'    => 'xml_entity',
					'content' => CB_Codetizer_Helpers::truncate( trim( $line ), 200 ),
					'line'    => $line_num,
					'reason'  => esc_html__( 'Removed ENTITY declaration.', 'cb-codetizer' ),
				);
				$line = '';
			}

			// Remove external DTD references (SYSTEM/PUBLIC).
			if ( preg_match( '/(<!DOCTYPE\s[^>[]+)\s+SYSTEM\s+["\'][^"\'>]+["\']/i', $line, $m ) ) {
				$removed[] = array(
					'type'    => 'xml_external_dtd',
					'content' => CB_Codetizer_Helpers::truncate( trim( $m[0] ), 200 ),
					'line'    => $line_num,
					'reason'  => esc_html__( 'Removed external DTD SYSTEM reference.', 'cb-codetizer' ),
				);
				$line = str_replace( $m[0], $m[1] . '>', $line );
			}

			// Remove XInclude directives.
			if ( preg_match( '/<(?:xi|xi:)include\b[^>]*>/i', $line, $m ) ) {
				$removed[] = array(
					'type'    => 'xml_xinclude',
					'content' => CB_Codetizer_Helpers::truncate( trim( $m[0] ), 200 ),
					'line'    => $line_num,
					'reason'  => esc_html__( 'Removed XInclude directive.', 'cb-codetizer' ),
				);
				$line = str_replace( $m[0], '<!-- [CB Codetizer] XInclude removed -->', $line );
			}

			// Remove XSLT script blocks.
			if ( preg_match( '/<(?:xsl|msxsl):script\b/i', $line, $m ) ) {
				$removed[] = array(
					'type'    => 'xml_xslt_script',
					'content' => CB_Codetizer_Helpers::truncate( trim( $m[0] ), 200 ),
					'line'    => $line_num,
					'reason'  => esc_html__( 'Removed XSLT script block.', 'cb-codetizer' ),
				);
				$line = str_replace( $m[0], '<!-- [CB Codetizer] XSLT script removed -->', $line );
			}

			// Remove processing instructions that reference scripts.
			if ( preg_match( '/<\?php/i', $line, $m ) ) {
				$removed[] = array(
					'type'    => 'xml_php_processing',
					'content' => CB_Codetizer_Helpers::truncate( trim( $m[0] ), 200 ),
					'line'    => $line_num,
					'reason'  => esc_html__( 'Removed PHP processing instruction from XML.', 'cb-codetizer' ),
				);
				$line = preg_replace( '/<\?php.*\?>/s', '<!-- [CB Codetizer] PHP removed -->', $line );
			}
		}
		unset( $line );

		return array( implode( "\n", $lines ), $removed );
	}

	/* ------------------------------------------------------------------
	 *  Markdown sanitization.
	 * ----------------------------------------------------------------- */

	/**
	 * Sanitize Markdown code.
	 *
	 * @param string $code Raw Markdown.
	 * @return array{0: string, 1: array}
	 */
	private function sanitize_markdown( string $code ): array {
		$removed = array();
		$lines   = explode( "\n", $code );

		foreach ( $lines as $ln => &$line ) {
			$line_num = $ln + 1;

			// Remove <script> tags.
			while ( preg_match( '/<script\b[^>]*>.*?<\/script\s*>/is', $line, $m ) ) {
				$removed[] = array(
					'type'    => 'markdown_script',
					'content' => CB_Codetizer_Helpers::truncate( $m[0], 200 ),
					'line'    => $line_num,
					'reason'  => esc_html__( 'Removed <script> tag from Markdown.', 'cb-codetizer' ),
				);
				$line = str_replace( $m[0], '', $line );
			}
			$line = preg_replace( '/<script\b[^>]*\s*\/?>/i', '', $line );

			// Sanitize data: URLs in markdown links.
			$line = preg_replace_callback(
				'/\]\(\s*(data\s*:[^)]+)\s*\)/i',
				function ( $matches ) use ( &$removed, $line_num ) {
					$removed[] = array(
						'type'    => 'markdown_data_url',
						'content' => CB_Codetizer_Helpers::truncate( $matches[1], 200 ),
						'line'    => $line_num,
						'reason'  => esc_html__( 'Removed data: URL from Markdown link.', 'cb-codetizer' ),
					);
					return '](#sanitized)';
				},
				$line
			);

			// Escape raw HTML tags (convert < and > to entities within the markdown),
			// but preserve safe inline Markdown HTML like <br>, <hr>, <em>, <strong>, etc.
			$safe_tags = array( 'br', 'hr', 'p', 'div', 'span', 'strong', 'em', 'b', 'i', 'a', 'ul', 'ol', 'li', 'h1', 'h2', 'h3', 'h4', 'h5', 'h6', 'img', 'code', 'pre', 'blockquote', 'table', 'thead', 'tbody', 'tr', 'th', 'td', 'dl', 'dt', 'dd', 'sup', 'sub', 'kbd', 'mark', 'small', 'del', 'ins', 'abbr' );
			$line = preg_replace_callback(
				'/<([a-zA-Z][a-zA-Z0-9]*)\b([^>]*)>/i',
				function ( $matches ) use ( &$removed, $line_num, $safe_tags ) {
					$tag = strtolower( $matches[1] );
					if ( ! in_array( $tag, $safe_tags, true ) ) {
						$removed[] = array(
							'type'    => 'markdown_html_tag',
							'content' => CB_Codetizer_Helpers::truncate( $matches[0], 200 ),
							'line'    => $line_num,
							'reason'  => sprintf(
								/* translators: %s: Tag name */
								esc_html__( 'Escaped unsafe HTML tag <%s> in Markdown.', 'cb-codetizer' ),
								esc_html( $tag )
							),
						);
						return '&lt;' . $matches[1] . $matches[2] . '&gt;';
					}
					return $matches[0];
				},
				$line
			);

			// Also escape closing tags for non-safe tags.
			$line = preg_replace_callback(
				'/<\/([a-zA-Z][a-zA-Z0-9]*)\s*>/i',
				function ( $matches ) use ( $safe_tags ) {
					$tag = strtolower( $matches[1] );
					if ( ! in_array( $tag, $safe_tags, true ) ) {
						return '&lt;/' . $matches[1] . '&gt;';
					}
					return $matches[0];
				},
				$line
			);
		}
		unset( $line );

		return array( implode( "\n", $lines ), $removed );
	}
}
