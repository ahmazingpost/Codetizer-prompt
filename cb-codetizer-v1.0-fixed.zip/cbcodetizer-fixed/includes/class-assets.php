<?php
/**
 * CB CODETIZER - Assets
 *
 * Enqueues CSS and JavaScript files for every admin screen
 * that belongs to the CB Codetizer plugin.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class CB_Codetizer_Assets
 *
 * Manages the conditional loading of stylesheets and scripts.
 * A global admin.css/admin.js pair is loaded on every CB Codetizer
 * page, and page-specific assets are loaded additionally.
 */
class CB_Codetizer_Assets {

	/**
	 * Map of page slugs (partial match) to their asset handles.
	 *
	 * The key is a substring expected to appear in the $hook parameter.
	 * Only pages that need extra assets beyond the global ones are listed.
	 *
	 * @var array<string, string>
	 */
	private array $page_asset_map = array(
		'cb-codetizer-inspector' => 'inspector',
		'cb-codetizer-sanitizer' => 'sanitizer',
		'cb-codetizer-beautifier'=> 'beautifier',
		'cb-codetizer-reports'   => 'reports',
		'cb-codetizer-settings'  => 'settings',
		'cb-codetizer-about'     => 'about',
	);

	/**
	 * Constructor.
	 *
	 * Hooks the enqueue method into admin_enqueue_scripts.
	 */
	public function __construct() {
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
	}

	/**
	 * Enqueue styles and scripts for CB Codetizer admin pages.
	 *
	 * First checks whether the current hook belongs to the plugin.
	 * If so, the global admin.css and admin.js are always enqueued.
	 * Then, page-specific CSS and JS files are enqueued when applicable.
	 *
	 * @param string $hook The current admin page hook suffix.
	 * @return void
	 */
	public function enqueue( string $hook ): void {
		// Only load assets on CB Codetizer pages.
		if ( ! str_contains( $hook, 'cb-codetizer' ) ) {
			return;
		}

		// Global assets — loaded on every CB Codetizer page.
		$this->register_style( 'cb-codetizer-admin', 'assets/css/admin.css' );
		$this->register_script( 'cb-codetizer-admin', 'assets/js/admin.js' );

		// Page-specific assets.
		foreach ( $this->page_asset_map as $hook_fragment => $handle ) {
			if ( str_contains( $hook, $hook_fragment ) ) {
				$this->register_style( 'cb-codetizer-' . $handle, 'assets/css/' . $handle . '.css' );
				$this->register_script( 'cb-codetizer-' . $handle, 'assets/js/' . $handle . '.js' );
				break;
			}
		}

		// Dashboard page (cb-codetizer page without a specific sub-slug) only gets globals.
	}

	/**
	 * Register and enqueue a CSS stylesheet.
	 *
	 * Uses filemtime() for the version parameter so that
	 * browser caches are busted whenever the file changes.
	 *
	 * @param string $handle  The stylesheet handle.
	 * @param string $rel_path Path relative to CB_CODETIZER_URL.
	 * @return void
	 */
	private function register_style( string $handle, string $rel_path ): void {
		$file_path = CB_CODETIZER_PATH . $rel_path;
		$version   = file_exists( $file_path ) ? (string) filemtime( $file_path ) : CB_CODETIZER_VERSION;

		wp_enqueue_style(
			$handle,
			CB_CODETIZER_URL . $rel_path,
			array(),
			$version
		);
	}

	/**
	 * Register and enqueue a JavaScript file.
	 *
	 * Uses filemtime() for the version parameter so that
	 * browser caches are busted whenever the file changes.
	 * No jQuery dependency is declared — all scripts use vanilla JS.
	 *
	 * @param string $handle  The script handle.
	 * @param string $rel_path Path relative to CB_CODETIZER_URL.
	 * @return void
	 */
	private function register_script( string $handle, string $rel_path ): void {
		$file_path = CB_CODETIZER_PATH . $rel_path;
		$version   = file_exists( $file_path ) ? (string) filemtime( $file_path ) : CB_CODETIZER_VERSION;

		wp_enqueue_script(
			$handle,
			CB_CODETIZER_URL . $rel_path,
			array(),
			$version,
			true  // Load in footer.
		);
	}
}
