<?php
/**
 * About template for CB Codetizer.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="cb-codetizer-wrap">
	<h1><?php echo esc_html__( 'About CB Codetizer', 'cb-codetizer' ); ?></h1>

	<div class="cb-codetizer-about-card">
		<h2><?php echo esc_html__( 'Plugin Information', 'cb-codetizer' ); ?></h2>
		<table class="cb-codetizer-table cb-codetizer-about-info">
			<tr>
				<th><?php echo esc_html__( 'Plugin Name', 'cb-codetizer' ); ?></th>
				<td>CB CODETIZER</td>
			</tr>
			<tr>
				<th><?php echo esc_html__( 'Version', 'cb-codetizer' ); ?></th>
				<td>1.0.0</td>
			</tr>
			<tr>
				<th><?php echo esc_html__( 'Description', 'cb-codetizer' ); ?></th>
				<td><?php echo esc_html__( 'A comprehensive code inspection, sanitization, and beautification tool for WordPress.', 'cb-codetizer' ); ?></td>
			</tr>
			<tr>
				<th><?php echo esc_html__( 'Requires PHP', 'cb-codetizer' ); ?></th>
				<td>8.1+</td>
			</tr>
			<tr>
				<th><?php echo esc_html__( 'Requires WordPress', 'cb-codetizer' ); ?></th>
				<td>6.0+</td>
			</tr>
		</table>
	</div>

	<div class="cb-codetizer-about-card">
		<h2><?php echo esc_html__( 'Credits', 'cb-codetizer' ); ?></h2>
		<p><?php echo esc_html__( 'Developed as a security and code quality tool for WordPress administrators.', 'cb-codetizer' ); ?></p>
	</div>

	<div class="cb-codetizer-about-card">
		<h2><?php echo esc_html__( 'Features', 'cb-codetizer' ); ?></h2>
		<ul class="cb-codetizer-features-list">
			<li><strong><?php echo esc_html__( 'Code Inspection', 'cb-codetizer' ); ?></strong> &mdash; <?php echo esc_html__( 'Real-time threat detection', 'cb-codetizer' ); ?></li>
			<li><strong><?php echo esc_html__( 'Code Sanitization', 'cb-codetizer' ); ?></strong> &mdash; <?php echo esc_html__( 'Remove malicious code', 'cb-codetizer' ); ?></li>
			<li><strong><?php echo esc_html__( 'Code Beautification', 'cb-codetizer' ); ?></strong> &mdash; <?php echo esc_html__( 'Format and pretty-print', 'cb-codetizer' ); ?></li>
			<li><strong><?php echo esc_html__( 'Multiple Languages', 'cb-codetizer' ); ?></strong> &mdash; <?php echo esc_html__( 'HTML, SVG, CSS, JS, PHP, JSON, XML, Markdown, TXT', 'cb-codetizer' ); ?></li>
			<li><strong><?php echo esc_html__( 'Report History', 'cb-codetizer' ); ?></strong> &mdash; <?php echo esc_html__( 'Track all scan results over time', 'cb-codetizer' ); ?></li>
			<li><strong><?php echo esc_html__( 'CSV Export', 'cb-codetizer' ); ?></strong> &mdash; <?php echo esc_html__( 'Export reports for external analysis', 'cb-codetizer' ); ?></li>
		</ul>
	</div>

	<div class="cb-codetizer-about-card">
		<h2><?php echo esc_html__( 'License', 'cb-codetizer' ); ?></h2>
		<p><?php echo esc_html__( 'This plugin is licensed under the GPLv2 or later.', 'cb-codetizer' ); ?></p>
	</div>

	<div class="cb-codetizer-about-card">
		<h2><?php echo esc_html__( 'Documentation', 'cb-codetizer' ); ?></h2>
		<p><a href="#"><?php echo esc_html__( 'View Documentation', 'cb-codetizer' ); ?></a></p>
	</div>
</div>
