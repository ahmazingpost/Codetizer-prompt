<?php
/**
 * Reports template for CB Codetizer.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="cb-codetizer-wrap">
	<h1><?php echo esc_html__( 'Scan Reports', 'cb-codetizer' ); ?></h1>
	<p><?php echo esc_html__( 'Every Inspector, Sanitizer, and Beautifier operation is automatically saved here.', 'cb-codetizer' ); ?></p>

	<div class="cb-codetizer-filter-bar">
		<div class="cb-codetizer-filter-left">
			<input
				type="text"
				id="cb-codetizer-research-input"
				class="cb-codetizer-input"
				placeholder="<?php echo esc_attr__( 'Search reports…', 'cb-codetizer' ); ?>"
			/>
			<select id="cb-codetizer-filter-select" class="cb-codetizer-select">
				<option value="all"><?php echo esc_html__( 'All Types', 'cb-codetizer' ); ?></option>
				<option value="inspector"><?php echo esc_html__( 'Inspector', 'cb-codetizer' ); ?></option>
				<option value="sanitizer"><?php echo esc_html__( 'Sanitizer', 'cb-codetizer' ); ?></option>
				<option value="beautifier"><?php echo esc_html__( 'Beautifier', 'cb-codetizer' ); ?></option>
			</select>
		</div>
		<div class="cb-codetizer-filter-right">
			<button type="button" id="cb-codetizer-export-csv-btn"
				class="cb-codetizer-btn cb-codetizer-btn-secondary">
				<?php echo esc_html__( 'Export CSV', 'cb-codetizer' ); ?>
			</button>
			<button type="button" id="cb-codetizer-clear-reports-btn"
				class="cb-codetizer-btn cb-codetizer-btn-danger"
				data-confirm="<?php echo esc_attr__( 'Clear all reports? This cannot be undone.', 'cb-codetizer' ); ?>">
				<?php echo esc_html__( 'Clear All', 'cb-codetizer' ); ?>
			</button>
		</div>
	</div>

	<table class="cb-codetizer-table" id="cb-codetizer-reports-table">
		<thead>
			<tr>
				<th><?php echo esc_html__( 'ID', 'cb-codetizer' ); ?></th>
				<th><?php echo esc_html__( 'Type', 'cb-codetizer' ); ?></th>
				<th><?php echo esc_html__( 'Language', 'cb-codetizer' ); ?></th>
				<th><?php echo esc_html__( 'Score', 'cb-codetizer' ); ?></th>
				<th><?php echo esc_html__( 'Input Summary', 'cb-codetizer' ); ?></th>
				<th><?php echo esc_html__( 'Threats', 'cb-codetizer' ); ?></th>
				<th><?php echo esc_html__( 'Severity', 'cb-codetizer' ); ?></th>
				<th><?php echo esc_html__( 'Date', 'cb-codetizer' ); ?></th>
				<th><?php echo esc_html__( 'Actions', 'cb-codetizer' ); ?></th>
			</tr>
		</thead>
		<tbody id="cb-codetizer-reports-tbody">
			<tr>
				<td colspan="9" class="cb-codetizer-no-data">
					<?php echo esc_html__( 'Loading reports…', 'cb-codetizer' ); ?>
				</td>
			</tr>
		</tbody>
	</table>

	<div id="cb-codetizer-reports-pagination" class="cb-codetizer-pagination"></div>

	<?php wp_nonce_field( 'cb_codetizer_get_reports', 'cb_codetizer_nonce' ); ?>
</div>
