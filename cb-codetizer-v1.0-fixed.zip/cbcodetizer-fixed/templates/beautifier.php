<?php
/**
 * Beautifier template for CB Codetizer.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="cb-codetizer-wrap">
	<h1><?php echo esc_html__( 'Code Beautifier', 'cb-codetizer' ); ?></h1>
	<p><?php echo esc_html__( 'Paste or upload code to automatically format and pretty-print it for improved readability. Side-by-side before/after preview is shown after formatting.', 'cb-codetizer' ); ?></p>

	<div class="cb-codetizer-form-group">
		<label for="cb-codetizer-beautify-input" class="cb-codetizer-label">
			<?php echo esc_html__( 'Code Input', 'cb-codetizer' ); ?>
		</label>
		<textarea
			id="cb-codetizer-beautify-input"
			class="cb-codetizer-textarea"
			rows="15"
			placeholder="<?php echo esc_attr__( 'Paste your code here…', 'cb-codetizer' ); ?>"
		></textarea>
	</div>

	<div class="cb-codetizer-form-group">
		<label for="cb-codetizer-beautify-upload" class="cb-codetizer-label">
			<?php echo esc_html__( 'Upload File:', 'cb-codetizer' ); ?>
		</label>
		<input type="file" id="cb-codetizer-beautify-upload"
			accept=".html,.htm,.svg,.css,.js,.json,.xml,.md,.txt,.php" />
	</div>

	<div class="cb-codetizer-form-group">
		<label for="cb-codetizer-beautify-language" class="cb-codetizer-label">
			<?php echo esc_html__( 'Language', 'cb-codetizer' ); ?>
		</label>
		<select id="cb-codetizer-beautify-language" class="cb-codetizer-select">
			<option value="auto"><?php echo esc_html__( 'Auto-detect', 'cb-codetizer' ); ?></option>
			<option value="html"><?php echo esc_html__( 'HTML', 'cb-codetizer' ); ?></option>
			<option value="svg"><?php echo esc_html__( 'SVG', 'cb-codetizer' ); ?></option>
			<option value="css"><?php echo esc_html__( 'CSS', 'cb-codetizer' ); ?></option>
			<option value="javascript"><?php echo esc_html__( 'JavaScript', 'cb-codetizer' ); ?></option>
			<option value="php"><?php echo esc_html__( 'PHP', 'cb-codetizer' ); ?></option>
			<option value="json"><?php echo esc_html__( 'JSON', 'cb-codetizer' ); ?></option>
			<option value="xml"><?php echo esc_html__( 'XML', 'cb-codetizer' ); ?></option>
			<option value="markdown"><?php echo esc_html__( 'Markdown', 'cb-codetizer' ); ?></option>
			<option value="txt"><?php echo esc_html__( 'TXT', 'cb-codetizer' ); ?></option>
		</select>
	</div>

	<button type="button" id="cb-codetizer-beautify-btn" class="cb-codetizer-btn cb-codetizer-btn-primary">
		<?php echo esc_html__( 'Beautify Code', 'cb-codetizer' ); ?>
	</button>

	<!-- Stats line: original lines → beautified lines -->
	<div id="cb-codetizer-beautify-stats" class="cb-codetizer-beautify-stats"></div>

	<!-- Before / After side-by-side -->
	<div class="cb-codetizer-before-after-grid">
		<div id="cb-codetizer-beautify-before-wrap" class="cb-codetizer-panel" style="display:none;">
			<h3 class="cb-panel-title"><?php echo esc_html__( 'Original Code', 'cb-codetizer' ); ?></h3>
			<pre class="cb-codetizer-code-block"><code id="cb-codetizer-beautify-before-code"></code></pre>
		</div>

		<div id="cb-codetizer-beautify-after-wrap" class="cb-codetizer-panel" style="display:none;">
			<h3 class="cb-panel-title"><?php echo esc_html__( 'Beautified Code', 'cb-codetizer' ); ?></h3>
			<pre class="cb-codetizer-code-block"><code id="cb-codetizer-beautify-preview"></code></pre>
			<div class="cb-codetizer-action-buttons">
				<button type="button" id="cb-codetizer-copy-beautified"
					class="cb-codetizer-btn cb-codetizer-btn-secondary">
					<?php echo esc_html__( 'Copy', 'cb-codetizer' ); ?>
				</button>
				<button type="button" id="cb-codetizer-download-beautified"
					class="cb-codetizer-btn cb-codetizer-btn-secondary">
					<?php echo esc_html__( 'Download', 'cb-codetizer' ); ?>
				</button>
			</div>
		</div>
	</div>

	<?php wp_nonce_field( 'cb_codetizer_beautify', 'cb_codetizer_nonce' ); ?>
</div>
