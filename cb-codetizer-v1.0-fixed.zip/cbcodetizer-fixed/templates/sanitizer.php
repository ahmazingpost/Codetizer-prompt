<?php
/**
 * Sanitizer template for CB Codetizer.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="cb-codetizer-wrap">
	<h1><?php echo esc_html__( 'Code Sanitizer', 'cb-codetizer' ); ?></h1>
	<p><?php echo esc_html__( 'Paste or upload code to automatically detect and remove malicious patterns. The Inspector runs before and after so you can see the full security-score change.', 'cb-codetizer' ); ?></p>

	<div class="cb-codetizer-form-group">
		<label for="cb-codetizer-sanitize-input" class="cb-codetizer-label">
			<?php echo esc_html__( 'Code Input', 'cb-codetizer' ); ?>
		</label>
		<textarea
			id="cb-codetizer-sanitize-input"
			class="cb-codetizer-textarea"
			rows="15"
			placeholder="<?php echo esc_attr__( 'Paste your code here…', 'cb-codetizer' ); ?>"
		></textarea>
	</div>

	<div class="cb-codetizer-form-group">
		<label for="cb-codetizer-sanitize-upload" class="cb-codetizer-label">
			<?php echo esc_html__( 'Upload File:', 'cb-codetizer' ); ?>
		</label>
		<input type="file" id="cb-codetizer-sanitize-upload"
			accept=".html,.htm,.svg,.css,.js,.json,.xml,.md,.txt,.php" />
	</div>

	<div class="cb-codetizer-form-group">
		<label for="cb-codetizer-sanitize-language" class="cb-codetizer-label">
			<?php echo esc_html__( 'Language', 'cb-codetizer' ); ?>
		</label>
		<select id="cb-codetizer-sanitize-language" class="cb-codetizer-select">
			<option value="auto"><?php echo esc_html__( 'Auto-detect', 'cb-codetizer' ); ?></option>
			<option value="html"><?php echo esc_html__( 'HTML', 'cb-codetizer' ); ?></option>
			<option value="svg"><?php echo esc_html__( 'SVG', 'cb-codetizer' ); ?></option>
			<option value="css"><?php echo esc_html__( 'CSS', 'cb-codetizer' ); ?></option>
			<option value="javascript"><?php echo esc_html__( 'JavaScript', 'cb-codetizer' ); ?></option>
			<option value="php"><?php echo esc_html__( 'PHP', 'cb-codetizer' ); ?></option>
			<option value="json"><?php echo esc_html__( 'JSON', 'cb-codetizer' ); ?></option>
			<option value="xml"><?php echo esc_html__( 'XML', 'cb-codetizer' ); ?></option>
			<option value="markdown"><?php echo esc_html__( 'Markdown', 'cb-codetizer' ); ?></option>
			<option value="txt"><?php echo esc_html__( 'TXT', 'cb-codetizer' ); ?></option>
		</select>
	</div>

	<button type="button" id="cb-codetizer-sanitize-btn" class="cb-codetizer-btn cb-codetizer-btn-primary">
		<?php echo esc_html__( 'Sanitize Code', 'cb-codetizer' ); ?>
	</button>

	<!-- Stats bar populated by sanitizer.js -->
	<div id="cb-codetizer-sanitize-stats" class="cb-codetizer-sanitize-stats"></div>

	<!-- Security score comparison -->
	<div id="cb-codetizer-score-comparison" class="cb-codetizer-score-comparison">
		<div class="cb-score-box">
			<span class="cb-score-label"><?php echo esc_html__( 'Score Before', 'cb-codetizer' ); ?></span>
			<span id="cb-codetizer-score-before" class="cb-codetizer-score-value">—</span>
		</div>
		<div class="cb-score-arrow">→</div>
		<div class="cb-score-box">
			<span class="cb-score-label"><?php echo esc_html__( 'Score After', 'cb-codetizer' ); ?></span>
			<span id="cb-codetizer-score-after" class="cb-codetizer-score-value">—</span>
		</div>
	</div>

	<!-- Before / After code previews -->
	<div class="cb-codetizer-before-after-grid">
		<div id="cb-codetizer-before-wrap" class="cb-codetizer-panel" style="display:none;">
			<h3 class="cb-panel-title"><?php echo esc_html__( 'Original Code', 'cb-codetizer' ); ?></h3>
			<pre class="cb-codetizer-code-block"><code id="cb-codetizer-before-code"></code></pre>
		</div>

		<div id="cb-codetizer-after-wrap" class="cb-codetizer-panel" style="display:none;">
			<h3 class="cb-panel-title"><?php echo esc_html__( 'Sanitized Code', 'cb-codetizer' ); ?></h3>
			<pre class="cb-codetizer-code-block"><code id="cb-codetizer-after-code"></code></pre>
			<div class="cb-codetizer-action-buttons">
				<button type="button" id="cb-codetizer-copy-output"
					class="cb-codetizer-btn cb-codetizer-btn-secondary">
					<?php echo esc_html__( 'Copy Sanitized', 'cb-codetizer' ); ?>
				</button>
				<button type="button" id="cb-codetizer-download-cleaned"
					class="cb-codetizer-btn cb-codetizer-btn-secondary">
					<?php echo esc_html__( 'Download Sanitized File', 'cb-codetizer' ); ?>
				</button>
				<button type="button" id="cb-codetizer-download-san-report"
					class="cb-codetizer-btn cb-codetizer-btn-secondary">
					<?php echo esc_html__( 'Download JSON Report', 'cb-codetizer' ); ?>
				</button>
			</div>
		</div>
	</div>

	<!-- Removed items -->
	<div id="cb-codetizer-removed-items" class="cb-codetizer-removed-items"></div>

	<!-- Remaining threats requiring manual review -->
	<div id="cb-codetizer-remaining-threats" class="cb-codetizer-remaining-threats"></div>

	<?php wp_nonce_field( 'cb_codetizer_sanitize', 'cb_codetizer_nonce' ); ?>
</div>
