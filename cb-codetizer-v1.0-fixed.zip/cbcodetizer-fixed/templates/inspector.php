<?php
/**
 * Inspector template for CB Codetizer.
 *
 * @package CB_Codetizer
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>

<div class="cb-codetizer-wrap">
	<h1><?php echo esc_html__( 'Code Inspector', 'cb-codetizer' ); ?></h1>
	<p><?php echo esc_html__( 'Paste or upload code to scan for security threats, vulnerabilities, and code quality issues. Results include a security score, threat list, and downloadable reports.', 'cb-codetizer' ); ?></p>

	<div class="cb-codetizer-inspector-layout">
		<div class="cb-codetizer-inspector-left">
			<textarea
				id="cb-codetizer-code-input"
				class="cb-codetizer-textarea"
				rows="15"
				placeholder="<?php echo esc_attr__( 'Paste your code here…', 'cb-codetizer' ); ?>"
			></textarea>
			<div class="cb-codetizer-upload-row">
				<label for="cb-codetizer-upload-file" class="cb-codetizer-label">
					<?php echo esc_html__( 'Upload File:', 'cb-codetizer' ); ?>
				</label>
				<input type="file" id="cb-codetizer-upload-file"
					accept=".html,.htm,.svg,.css,.js,.json,.xml,.md,.txt,.php" />
			</div>
		</div>

		<div class="cb-codetizer-inspector-right">
			<div class="cb-codetizer-form-group">
				<label for="cb-codetizer-language-select" class="cb-codetizer-label">
					<?php echo esc_html__( 'Language', 'cb-codetizer' ); ?>
				</label>
				<select id="cb-codetizer-language-select" class="cb-codetizer-select">
					<option value="auto"><?php echo esc_html__( 'Auto-detect', 'cb-codetizer' ); ?></option>
					<option value="html"><?php echo esc_html__( 'HTML', 'cb-codetizer' ); ?></option>
					<option value="svg"><?php echo esc_html__( 'SVG', 'cb-codetizer' ); ?></option>
					<option value="css"><?php echo esc_html__( 'CSS', 'cb-codetizer' ); ?></option>
					<option value="javascript"><?php echo esc_html__( 'JavaScript', 'cb-codetizer' ); ?></option>
					<option value="php"><?php echo esc_html__( 'PHP', 'cb-codetizer' ); ?></option>
					<option value="json"><?php echo esc_html__( 'JSON', 'cb-codetizer' ); ?></option>
					<option value="xml"><?php echo esc_html__( 'XML', 'cb-codetizer' ); ?></option>
					<option value="markdown"><?php echo esc_html__( 'Markdown', 'cb-codetizer' ); ?></option>
					<option value="txt"><?php echo esc_html__( 'TXT', 'cb-codetizer' ); ?></option>
				</select>
			</div>

			<div class="cb-codetizer-form-group">
				<label for="cb-codetizer-scan-profile" class="cb-codetizer-label">
					<?php echo esc_html__( 'Scan Profile', 'cb-codetizer' ); ?>
				</label>
				<select id="cb-codetizer-scan-profile" class="cb-codetizer-select">
					<option value="standard"><?php echo esc_html__( 'Standard', 'cb-codetizer' ); ?></option>
					<option value="strict"><?php echo esc_html__( 'Strict', 'cb-codetizer' ); ?></option>
				</select>
			</div>

			<button type="button" id="cb-codetizer-scan-btn"
				class="cb-codetizer-btn cb-codetizer-btn-primary">
				<?php echo esc_html__( 'Scan Code', 'cb-codetizer' ); ?>
			</button>
		</div>
	</div>

	<div id="cb-codetizer-progress" class="cb-codetizer-progress" style="display: none;">
		<div class="cb-codetizer-progress-bar" id="cb-codetizer-progress-bar"></div>
	</div>

	<!-- Results rendered by inspector.js (includes original code preview + download buttons) -->
	<div id="cb-codetizer-results"></div>

	<?php wp_nonce_field( 'cb_codetizer_inspect', 'cb_codetizer_nonce' ); ?>
</div>
