/* global CBCodeTizer */
'use strict';

document.addEventListener('DOMContentLoaded', function () {
    var inputEl   = document.getElementById('cb-codetizer-beautify-input');
    var langEl    = document.getElementById('cb-codetizer-beautify-language');
    var uploadEl  = document.getElementById('cb-codetizer-beautify-upload');
    var btn       = document.getElementById('cb-codetizer-beautify-btn');

    // Before / after preview panels.
    var beforeWrap   = document.getElementById('cb-codetizer-beautify-before-wrap');
    var beforeEl     = document.getElementById('cb-codetizer-beautify-before-code');
    var afterWrap    = document.getElementById('cb-codetizer-beautify-after-wrap');
    var previewEl    = document.getElementById('cb-codetizer-beautify-preview');

    var statsEl   = document.getElementById('cb-codetizer-beautify-stats');
    var copyBtn   = document.getElementById('cb-codetizer-copy-beautified');
    var dlBtn     = document.getElementById('cb-codetizer-download-beautified');

    if (!btn || !inputEl) return;

    var lastCode   = '';
    var lastLang   = '';
    var lastReport = null;

    var extMap = {
        js: 'javascript', ts: 'javascript', php: 'php', html: 'html', htm: 'html',
        svg: 'svg', css: 'css', json: 'json', xml: 'xml', md: 'markdown',
        txt: 'txt', markdown: 'markdown'
    };

    if (uploadEl) {
        uploadEl.addEventListener('change', function () {
            var file = uploadEl.files[0];
            if (!file) return;
            var reader = new FileReader();
            reader.onload = function (e) {
                inputEl.value = e.target.result;
                if (langEl && file.name) {
                    var ext = file.name.split('.').pop().toLowerCase();
                    if (extMap[ext]) langEl.value = extMap[ext];
                }
            };
            reader.readAsText(file);
        });
    }

    function showPanel(wrap, show) {
        if (!wrap) return;
        wrap.style.display = show ? '' : 'none';
    }

    btn.addEventListener('click', function () {
        var code     = inputEl.value.trim();
        var language = langEl ? langEl.value : '';

        if (!code) {
            CBCodeTizer.showToast('Please enter or upload code to beautify.', 'error');
            return;
        }

        btn.disabled    = true;
        btn.textContent = 'Beautifying…';

        CBCodeTizer.ajax('cb_codetizer_beautify', { code: code, language: language })
            .then(function (res) {
                btn.disabled    = false;
                btn.textContent = 'Beautify Code';

                if (!res.success) {
                    CBCodeTizer.showToast((res.data && res.data.message) || 'Beautification failed.', 'error');
                    return;
                }

                var data        = res.data;
                lastCode        = data.beautified_code || '';
                lastLang        = data.language || language;
                lastReport      = data;

                // Show original code (before panel).
                showPanel(beforeWrap, true);
                if (beforeEl) beforeEl.textContent = data.original_code || code;

                // Show beautified code (after panel).
                showPanel(afterWrap, true);
                if (previewEl) previewEl.textContent = lastCode;

                // Stats.
                var origLines = data.original_lines !== undefined
                    ? data.original_lines
                    : (data.stats && data.stats.original_lines !== undefined ? data.stats.original_lines : code.split('\n').length);
                var newLines = data.beautified_lines !== undefined
                    ? data.beautified_lines
                    : (data.stats && data.stats.beautified_lines !== undefined ? data.stats.beautified_lines : lastCode.split('\n').length);

                if (statsEl) {
                    statsEl.textContent = origLines + ' lines → ' + newLines + ' lines  |  Language: ' + (lastLang || 'auto');
                }

                CBCodeTizer.showToast('Code beautified successfully.', 'success');
            })
            .catch(function () {
                btn.disabled    = false;
                btn.textContent = 'Beautify Code';
                CBCodeTizer.showToast('Network error during beautification.', 'error');
            });
    });

    if (copyBtn) {
        copyBtn.addEventListener('click', function () {
            if (!lastCode) {
                CBCodeTizer.showToast('No beautified code to copy.', 'warning');
                return;
            }
            navigator.clipboard.writeText(lastCode).then(function () {
                CBCodeTizer.showToast('Copied to clipboard.', 'success');
            });
        });
    }

    if (dlBtn) {
        dlBtn.addEventListener('click', function () {
            if (!lastCode) {
                CBCodeTizer.showToast('No beautified code to download.', 'warning');
                return;
            }
            var extMap2 = { javascript: 'js', markdown: 'md', txt: 'txt' };
            var ext = extMap2[lastLang] || lastLang || 'txt';
            downloadText(lastCode, 'beautified.' + ext, 'text/plain');
        });
    }

    function downloadText(content, filename, mime) {
        var blob = new Blob([content], { type: mime });
        var url  = URL.createObjectURL(blob);
        var a    = document.createElement('a');
        a.href   = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }
});
