/* global CBCodeTizer */
'use strict';

document.addEventListener('DOMContentLoaded', function () {
    var maxUpload = document.getElementById('cb-codetizer-max-upload');
    var defaultLang = document.getElementById('cb-codetizer-default-lang');
    var scanProfile = document.getElementById('cb-codetizer-scan-profile');
    var indentSize = document.getElementById('cb-codetizer-indent-size');
    var indentType = document.getElementById('cb-codetizer-indent-type');
    var saveBtn = document.getElementById('cb-codetizer-save-settings-btn');
    var resetBtn = document.getElementById('cb-codetizer-reset-settings-btn');
    var clearBtn = document.getElementById('cb-codetizer-clear-reports-btn');

    if (!saveBtn) return;

    saveBtn.addEventListener('click', function () {
        var settings = {
            max_upload_size: maxUpload ? maxUpload.value : '',
            default_language: defaultLang ? defaultLang.value : '',
            scan_profile: scanProfile ? scanProfile.value : '',
            indent_size: indentSize ? indentSize.value : '',
            indent_type: indentType ? indentType.value : ''
        };
        CBCodeTizer.ajax('cb_codetizer_save_settings', { settings: JSON.stringify(settings) })
            .then(function (res) {
                if (res.success) {
                    CBCodeTizer.showToast('Settings saved successfully.', 'success');
                } else {
                    CBCodeTizer.showToast(res.data || 'Failed to save settings.', 'error');
                }
            });
    });

    if (resetBtn) {
        resetBtn.addEventListener('click', function () {
            if (!confirm('Reset all settings to defaults?')) return;
            CBCodeTizer.ajax('cb_codetizer_reset_settings', {})
                .then(function (res) {
                    if (res.success) {
                        location.reload();
                    } else {
                        CBCodeTizer.showToast(res.data || 'Failed to reset settings.', 'error');
                    }
                });
        });
    }

    if (clearBtn) {
        clearBtn.addEventListener('click', function () {
            if (!confirm('Are you sure you want to delete ALL reports? This cannot be undone.')) return;
            clearBtn.disabled = true;
            CBCodeTizer.ajax('cb_codetizer_clear_reports', {})
                .then(function (res) {
                    if (res.success) {
                        CBCodeTizer.showToast('All reports cleared.', 'success');
                    } else {
                        CBCodeTizer.showToast(res.data || 'Failed to clear reports.', 'error');
                    }
                    setTimeout(function () { clearBtn.disabled = false; }, 2000);
                });
        });
    }
});
