/* global CBCodeTizer */
'use strict';

document.addEventListener('DOMContentLoaded', function () {
    var inputEl   = document.getElementById('cb-codetizer-sanitize-input');
    var langEl    = document.getElementById('cb-codetizer-sanitize-language');
    var uploadEl  = document.getElementById('cb-codetizer-sanitize-upload');
    var btn       = document.getElementById('cb-codetizer-sanitize-btn');

    // Before panel
    var beforeWrap = document.getElementById('cb-codetizer-before-wrap');
    var beforeEl   = document.getElementById('cb-codetizer-before-code');

    // After panel
    var afterWrap  = document.getElementById('cb-codetizer-after-wrap');
    var afterEl    = document.getElementById('cb-codetizer-after-code');

    // Scores
    var scoreBefore = document.getElementById('cb-codetizer-score-before');
    var scoreAfter  = document.getElementById('cb-codetizer-score-after');

    // Stats bar
    var statsEl   = document.getElementById('cb-codetizer-sanitize-stats');

    // Removed items list
    var removedEl = document.getElementById('cb-codetizer-removed-items');

    // Remaining threats list
    var remainingEl = document.getElementById('cb-codetizer-remaining-threats');

    // Action buttons
    var copyBtn = document.getElementById('cb-codetizer-copy-output');
    var dlBtn   = document.getElementById('cb-codetizer-download-cleaned');
    var dlJsonBtn = document.getElementById('cb-codetizer-download-san-report');

    if (!btn || !inputEl) return;

    var lastCode = '';
    var lastLang = '';
    var lastReport = null;

    var extMap = {
        js: 'javascript', ts: 'javascript', php: 'php', html: 'html', htm: 'html',
        svg: 'svg', css: 'css', json: 'json', xml: 'xml', md: 'markdown',
        txt: 'txt', markdown: 'markdown'
    };

    if (uploadEl) {
        uploadEl.addEventListener('change', function () {
            var file = uploadEl.files[0];
            if (!file) return;
            var reader = new FileReader();
            reader.onload = function (e) {
                inputEl.value = e.target.result;
                if (langEl && file.name) {
                    var ext = file.name.split('.').pop().toLowerCase();
                    if (extMap[ext]) langEl.value = extMap[ext];
                }
            };
            reader.readAsText(file);
        });
    }

    function setScore(el, score) {
        if (!el) return;
        el.textContent = score + '/100';
        el.className = 'cb-codetizer-score-value';
        if (score >= 80) {
            el.className += ' score-good';
        } else if (score >= 50) {
            el.className += ' score-warn';
        } else {
            el.className += ' score-danger';
        }
    }

    function showPanel(wrap, show) {
        if (!wrap) return;
        wrap.style.display = show ? '' : 'none';
    }

    btn.addEventListener('click', function () {
        var code = inputEl.value.trim();
        var language = langEl ? langEl.value : '';
        if (!code) {
            CBCodeTizer.showToast('Please enter or upload code to sanitize.', 'error');
            return;
        }

        btn.disabled = true;
        btn.textContent = 'Sanitizing…';

        CBCodeTizer.ajax('cb_codetizer_sanitize', { code: code, language: language })
            .then(function (res) {
                btn.disabled = false;
                btn.textContent = 'Sanitize Code';

                if (!res.success) {
                    CBCodeTizer.showToast((res.data && res.data.message) || 'Sanitization failed.', 'error');
                    return;
                }

                var data = res.data;
                lastCode   = data.sanitized_code || '';
                lastLang   = data.language || language;
                lastReport = data;

                // Before panel.
                showPanel(beforeWrap, true);
                if (beforeEl) beforeEl.textContent = data.original_code || code;

                // After panel.
                showPanel(afterWrap, true);
                if (afterEl) afterEl.textContent = lastCode;

                // Scores.
                setScore(scoreBefore, data.score_before !== undefined ? data.score_before : 100);
                setScore(scoreAfter,  data.score_after  !== undefined ? data.score_after  : 100);

                // Stats bar.
                var found     = data.threats_found     || 0;
                var removed   = data.threats_removed   || 0;
                var remaining = (data.threats_remaining || []).length;
                if (statsEl) {
                    statsEl.innerHTML = [
                        '<span class="cb-san-stat threats-found">Threats Found: <strong>' + found + '</strong></span>',
                        '<span class="cb-san-stat threats-removed">Threats Removed: <strong>' + removed + '</strong></span>',
                        '<span class="cb-san-stat threats-remaining">Threats Remaining: <strong>' + remaining + '</strong></span>'
                    ].join('');
                }

                // Removed items list.
                if (removedEl) {
                    removedEl.innerHTML = '';
                    var items = data.removed_items || [];
                    if (items.length > 0) {
                        var title = document.createElement('h4');
                        title.textContent = 'Removed (' + items.length + ')';
                        removedEl.appendChild(title);
                        items.forEach(function (item) {
                            var div = document.createElement('div');
                            div.className = 'cb-codetizer-removed-item';
                            div.innerHTML =
                                '<span class="cb-codetizer-removed-type">' + escHtml(item.type || 'Unknown') + '</span>' +
                                '<span class="cb-codetizer-removed-line">Line ' + (item.line || '?') + '</span>' +
                                '<span class="cb-codetizer-removed-reason">' + escHtml(item.reason || '') + '</span>';
                            removedEl.appendChild(div);
                        });
                    } else {
                        removedEl.innerHTML = '<p class="cb-codetizer-no-data">No items were automatically removed.</p>';
                    }
                }

                // Remaining threats list.
                if (remainingEl) {
                    remainingEl.innerHTML = '';
                    var rem = data.threats_remaining || [];
                    if (rem.length > 0) {
                        var remTitle = document.createElement('h4');
                        remTitle.textContent = 'Remaining Threats (' + rem.length + ') — Manual Review Required';
                        remainingEl.appendChild(remTitle);
                        rem.forEach(function (t) {
                            var div = document.createElement('div');
                            div.className = 'cb-codetizer-threat-item severity-' + (t.severity || 'info');
                            div.innerHTML =
                                '<span class="cb-threat-type">' + escHtml(t.type || '') + '</span>' +
                                '<span class="cb-threat-sev badge-' + escHtml(t.severity || 'info') + '">' + escHtml(t.severity || '') + '</span>' +
                                '<span class="cb-threat-line">Line ' + (t.line || '?') + '</span>' +
                                '<span class="cb-threat-desc">' + escHtml(t.description || '') + '</span>' +
                                '<span class="cb-threat-reason">' + escHtml(t.reason_not_auto_removed || '') + '</span>';
                            remainingEl.appendChild(div);
                        });
                    } else if (found > 0) {
                        remainingEl.innerHTML = '<p class="cb-codetizer-clean">All detected threats were removed successfully.</p>';
                    }
                }

                if (removed > 0) {
                    CBCodeTizer.showToast(removed + ' threat(s) removed. Score: ' + data.score_before + ' → ' + data.score_after + '.', 'warning');
                } else if (found === 0) {
                    CBCodeTizer.showToast('No threats detected. Code is clean.', 'success');
                } else {
                    CBCodeTizer.showToast(found + ' threat(s) found but none could be removed automatically. Manual review required.', 'warning');
                }
            })
            .catch(function () {
                btn.disabled = false;
                btn.textContent = 'Sanitize Code';
                CBCodeTizer.showToast('Network error during sanitization.', 'error');
            });
    });

    if (copyBtn) {
        copyBtn.addEventListener('click', function () {
            if (!lastCode) {
                CBCodeTizer.showToast('No sanitized code to copy.', 'warning');
                return;
            }
            navigator.clipboard.writeText(lastCode).then(function () {
                CBCodeTizer.showToast('Copied to clipboard.', 'success');
            });
        });
    }

    if (dlBtn) {
        dlBtn.addEventListener('click', function () {
            if (!lastCode) {
                CBCodeTizer.showToast('No sanitized code to download.', 'warning');
                return;
            }
            var extMap2 = { javascript: 'js', markdown: 'md', txt: 'txt' };
            var ext = extMap2[lastLang] || lastLang || 'txt';
            downloadText(lastCode, 'sanitized.' + ext, 'text/plain');
        });
    }

    if (dlJsonBtn) {
        dlJsonBtn.addEventListener('click', function () {
            if (!lastReport) {
                CBCodeTizer.showToast('No report to download.', 'warning');
                return;
            }
            var json = JSON.stringify(lastReport, null, 2);
            downloadText(json, 'sanitizer-report.json', 'application/json');
        });
    }

    function downloadText(content, filename, mime) {
        var blob = new Blob([content], { type: mime });
        var url  = URL.createObjectURL(blob);
        var a    = document.createElement('a');
        a.href   = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    }

    function escHtml(str) {
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }
});
