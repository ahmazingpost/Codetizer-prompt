'use strict';

(function () {
    /**
     * CBCodeTizer global — initialised as soon as this script loads (footer).
     * All page-specific scripts (inspector.js, sanitizer.js, etc.) rely on
     * window.CBCodeTizer being set before DOMContentLoaded fires on their own
     * modules; loading admin.js first (registered without deps but in footer)
     * ensures this is always the case.
     */
    var wrap = document.querySelector('.cb-codetizer-wrap');

    var CBCodeTizer = {

        /**
         * Show a transient notice inside .cb-codetizer-wrap.
         *
         * @param {string} message Text to display.
         * @param {string} type    'success' | 'error' | 'warning' | 'info'
         */
        showToast: function (message, type) {
            var container = document.querySelector('.cb-codetizer-wrap') || document.body;
            var el = document.createElement('div');
            el.className = 'cb-codetizer-notice cb-codetizer-notice-' + (type || 'success');
            el.setAttribute('role', 'alert');
            el.textContent = message;
            container.prepend(el);
            setTimeout(function () {
                if (el.parentNode) el.parentNode.removeChild(el);
            }, 5000);
        },

        /**
         * Perform a WordPress AJAX request, automatically attaching the
         * nonce from whichever nonce field is present on the page.
         *
         * @param  {string} action AJAX action name (without leading wp_ajax_).
         * @param  {Object} data   Key/value pairs to append to the form data.
         * @return {Promise}       Resolves with the parsed JSON response.
         */
        ajax: function (action, data) {
            var formData = new FormData();
            formData.append('action', action);

            // Find the nonce field — each page outputs wp_nonce_field() with
            // name="cb_codetizer_nonce". Use the first one found.
            var nonceField = document.querySelector('[name="cb_codetizer_nonce"]');
            if (nonceField) {
                formData.append('cb_codetizer_nonce', nonceField.value);
            }

            if (data && typeof data === 'object') {
                for (var key in data) {
                    if (Object.prototype.hasOwnProperty.call(data, key)) {
                        var val = data[key];
                        if (val !== null && val !== undefined) {
                            formData.append(key, val);
                        }
                    }
                }
            }

            // ajaxurl is always available in WP admin.
            return fetch(
                typeof ajaxurl !== 'undefined' ? ajaxurl : '/wp-admin/admin-ajax.php',
                { method: 'POST', body: formData }
            )
                .then(function (response) {
                    if (!response.ok) {
                        throw new Error('HTTP ' + response.status);
                    }
                    return response.json();
                })
                .catch(function (err) {
                    CBCodeTizer.showToast('Network error: ' + err.message, 'error');
                    return { success: false, data: { message: 'Network error: ' + err.message } };
                });
        },

        /**
         * Download a string as a file without a server round-trip.
         *
         * @param {string} content  File content.
         * @param {string} filename Suggested filename.
         * @param {string} mime     MIME type.
         */
        downloadText: function (content, filename, mime) {
            var blob = new Blob([content], { type: mime || 'text/plain' });
            var url  = URL.createObjectURL(blob);
            var a    = document.createElement('a');
            a.href   = url;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        },
    };

    window.CBCodeTizer = CBCodeTizer;

    // ── Danger-button confirmation guard ─────────────────────────────────
    // Intercepts clicks on any .cb-codetizer-btn-danger and requires
    // confirmation before letting the event propagate.
    document.addEventListener('click', function (e) {
        var btn = e.target.closest
            ? e.target.closest('.cb-codetizer-btn-danger')
            : null;

        if (!btn) return;

        var msg = btn.getAttribute('data-confirm') || 'Are you sure?';

        // If the handler is attached inline (e.g., reports clear button),
        // we let its own listener handle confirm. Only intercept buttons
        // that don't already have a click listener with confirm logic.
        // Check for a data-auto-confirm attribute to skip guard.
        if (btn.getAttribute('data-auto-confirm') === 'true') return;

        if (!confirm(msg)) {
            e.preventDefault();
            e.stopImmediatePropagation();
        }
    }, true);

})();
