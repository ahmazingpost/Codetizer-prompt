<?php
/**
 * The footer for the Cliqhost child theme.
 *
 * Carries the site-wide footer (newsletter form, link columns, legal row),
 * converted verbatim from the supplied HTML design (source: about_page.html).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>
</main><!-- #page-content -->

<footer class="site-footer">
  <div class="container">

    <!-- Newsletter (always visible) -->
    <div class="footer-newsletter">
      <div class="newsletter-copy">
        <h3>Stay ahead of the curve</h3>
        <p>Monthly insights on cloud, data, AI and security. No spam — unsubscribe anytime.</p>
      </div>
      <form class="newsletter-form" id="newsletter-form" action="#">
        <label class="visually-hidden" for="newsletter-email">Email address</label>
        <input type="email" id="newsletter-email" name="email" placeholder="Enter your work email" autocomplete="email" required>
        <button type="submit" class="btn btn--gold">Subscribe</button>
        <p class="newsletter-msg" id="newsletter-msg" role="status" aria-live="polite"></p>
      </form>
    </div>

    <!-- Link columns (accordions on mobile; contact info stays visible) -->
    <div class="footer-columns">
      <div class="footer-brand-col">
        <p class="footer-tagline">CLIQHOST is a global technology consultancy helping organizations build, modernize and scale with confidence.</p>
        <ul class="footer-contact">
          <li><svg class="icon" aria-hidden="true"><use href="#i-mail"></use></svg><a href="mailto:info@cliqhost.com">info@cliqhost.com</a></li>
          <li><svg class="icon" aria-hidden="true"><use href="#i-phone"></use></svg><a href="tel:+15550132456">+1 (555) 013-2456</a></li>
          <li><svg class="icon" aria-hidden="true"><use href="#i-pin"></use></svg><span>500 Harbor Boulevard, Suite 900,<br>New York, NY 10005</span></li>
        </ul>
        <ul class="social-links">
          <li><a href="#top" aria-label="CLIQHOST on LinkedIn"><svg class="icon" aria-hidden="true"><use href="#i-linkedin"></use></svg></a></li>
          <li><a href="#top" aria-label="CLIQHOST on X (Twitter)"><svg class="icon icon--fill" aria-hidden="true"><use href="#i-x"></use></svg></a></li>
          <li><a href="#top" aria-label="CLIQHOST on GitHub"><svg class="icon" aria-hidden="true"><use href="#i-github"></use></svg></a></li>
          <li><a href="#top" aria-label="CLIQHOST on YouTube"><svg class="icon" aria-hidden="true"><use href="#i-youtube"></use></svg></a></li>
        </ul>
      </div>

      <nav class="footer-group" aria-label="Footer solutions">
        <h3 class="footer-heading"><button class="footer-toggle" type="button" aria-expanded="false">Solutions <svg class="icon" aria-hidden="true"><use href="#i-chev"></use></svg></button></h3>
        <ul class="footer-panel">
          <li><a href="solutions_archive.html">Digital Transformation</a></li>
          <li><a href="solutions_archive.html">Cloud Solutions</a></li>
          <li><a href="solutions_archive.html">Data &amp; Analytics</a></li>
          <li><a href="solutions_archive.html">Cybersecurity</a></li>
          <li><a href="solutions_archive.html">AI &amp; Automation</a></li>
          <li><a href="solutions_archive.html">Managed Services</a></li>
        </ul>
      </nav>

      <nav class="footer-group" aria-label="Footer services">
        <h3 class="footer-heading"><button class="footer-toggle" type="button" aria-expanded="false">Services <svg class="icon" aria-hidden="true"><use href="#i-chev"></use></svg></button></h3>
        <ul class="footer-panel">
          <li><a href="services_archive.html">Software Engineering</a></li>
          <li><a href="services_archive.html">Cloud Engineering</a></li>
          <li><a href="services_archive.html">AI &amp; Machine Learning</a></li>
          <li><a href="services_archive.html">Cybersecurity</a></li>
          <li><a href="services_archive.html">Data Engineering</a></li>
          <li><a href="services_archive.html">IT Consulting</a></li>
          <li><a href="services_archive.html">DevOps</a></li>
          <li><a href="services_archive.html">Support &amp; Maintenance</a></li>
        </ul>
      </nav>

      <nav class="footer-group" aria-label="Footer industries">
        <h3 class="footer-heading"><button class="footer-toggle" type="button" aria-expanded="false">Industries <svg class="icon" aria-hidden="true"><use href="#i-chev"></use></svg></button></h3>
        <ul class="footer-panel">
          <li><a href="industries_archive.html">Finance</a></li>
          <li><a href="industries_archive.html">Healthcare</a></li>
          <li><a href="industries_archive.html">Retail</a></li>
          <li><a href="industries_archive.html">Logistics</a></li>
          <li><a href="industries_archive.html">Education</a></li>
          <li><a href="industries_archive.html">Professional Services</a></li>
        </ul>
      </nav>

      <div class="footer-group-col">
        <nav class="footer-group" aria-label="Footer resources">
          <h3 class="footer-heading"><button class="footer-toggle" type="button" aria-expanded="false">Resources <svg class="icon" aria-hidden="true"><use href="#i-chev"></use></svg></button></h3>
          <ul class="footer-panel">
            <li><a href="insights_archive.html">Insights</a></li>
            <li><a href="case_studies_archive.html">Case Studies</a></li>
            <li><a href="careers_jobs_archive.html">Careers</a></li>
            <li><a href="contact_page.html">Contact</a></li>
          </ul>
        </nav>
        <nav class="footer-group" aria-label="Footer company">
          <h3 class="footer-heading"><button class="footer-toggle" type="button" aria-expanded="false">Company <svg class="icon" aria-hidden="true"><use href="#i-chev"></use></svg></button></h3>
          <ul class="footer-panel">
            <li><a href="about_page.html">About</a></li>
            <li><a href="contact_page.html">Contact</a></li>
            <li><a href="careers_jobs_archive.html">Careers</a></li>
          </ul>
        </nav>
      </div>
    </div>

    <!-- Legal -->
    <div class="footer-bottom">
      <p class="copyright">© CLIQHOST. All rights reserved.</p>
      <ul class="legal-links">
        <li><a href="#top">Privacy Policy</a></li>
        <li><a href="#top">Terms of Service</a></li>
        <li><a href="#top">Cookie Policy</a></li>
      </ul>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
