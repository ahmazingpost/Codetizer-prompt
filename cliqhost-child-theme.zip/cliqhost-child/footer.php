<?php
/**
 * The footer for the Cliqhost child theme.
 *
 * Carries the site-wide footer (newsletter form, link columns, legal row).
 * Structure and styling are converted verbatim from the supplied HTML design
 * (source: about_page.html); all editable text/links are pulled from the
 * Cliqhost Header & Footer Editor plugin when active, falling back to the
 * original design's values otherwise so the theme never breaks on its own.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( function_exists( 'cliqhost_hf_get' ) ) {
	$cliqhost_footer_tagline         = cliqhost_hf_get( 'cliqhost_footer_tagline' );
	$cliqhost_newsletter_heading     = cliqhost_hf_get( 'cliqhost_newsletter_heading' );
	$cliqhost_newsletter_description = cliqhost_hf_get( 'cliqhost_newsletter_description' );
	$cliqhost_copyright_text         = cliqhost_hf_get( 'cliqhost_copyright_text' );
	$cliqhost_contact_email          = cliqhost_hf_get( 'cliqhost_contact_email' );
	$cliqhost_contact_phone_display  = cliqhost_hf_get( 'cliqhost_contact_phone_display' );
	$cliqhost_contact_phone_tel      = cliqhost_hf_get( 'cliqhost_contact_phone_tel' );
	$cliqhost_contact_address        = cliqhost_hf_get( 'cliqhost_contact_address' );
	$cliqhost_social_linkedin        = cliqhost_hf_get( 'cliqhost_social_linkedin' );
	$cliqhost_social_x               = cliqhost_hf_get( 'cliqhost_social_x' );
	$cliqhost_social_github          = cliqhost_hf_get( 'cliqhost_social_github' );
	$cliqhost_social_youtube         = cliqhost_hf_get( 'cliqhost_social_youtube' );
	$cliqhost_nav_footer_solutions   = cliqhost_hf_get_links( 'cliqhost_nav_footer_solutions' );
	$cliqhost_nav_footer_services    = cliqhost_hf_get_links( 'cliqhost_nav_footer_services' );
	$cliqhost_nav_footer_industries  = cliqhost_hf_get_links( 'cliqhost_nav_footer_industries' );
	$cliqhost_nav_footer_resources   = cliqhost_hf_get_links( 'cliqhost_nav_footer_resources' );
	$cliqhost_nav_footer_company     = cliqhost_hf_get_links( 'cliqhost_nav_footer_company' );
	$cliqhost_legal_links            = cliqhost_hf_get_links( 'cliqhost_legal_links' );
} else {
	$cliqhost_footer_tagline         = 'CLIQHOST is a global technology consultancy helping organizations build, modernize and scale with confidence.';
	$cliqhost_newsletter_heading     = 'Stay ahead of the curve';
	$cliqhost_newsletter_description = 'Monthly insights on cloud, data, AI and security. No spam — unsubscribe anytime.';
	$cliqhost_copyright_text         = '© CLIQHOST. All rights reserved.';
	$cliqhost_contact_email          = 'info@cliqhost.com';
	$cliqhost_contact_phone_display  = '+1 (555) 013-2456';
	$cliqhost_contact_phone_tel      = '+15550132456';
	$cliqhost_contact_address        = "500 Harbor Boulevard, Suite 900,\nNew York, NY 10005";
	$cliqhost_social_linkedin        = '';
	$cliqhost_social_x               = '';
	$cliqhost_social_github          = '';
	$cliqhost_social_youtube         = '';
	$cliqhost_nav_footer_solutions   = array(
		array( 'label' => 'Digital Transformation', 'url' => 'solutions_archive.html' ),
		array( 'label' => 'Cloud Solutions', 'url' => 'solutions_archive.html' ),
		array( 'label' => 'Data & Analytics', 'url' => 'solutions_archive.html' ),
		array( 'label' => 'Cybersecurity', 'url' => 'solutions_archive.html' ),
		array( 'label' => 'AI & Automation', 'url' => 'solutions_archive.html' ),
		array( 'label' => 'Managed Services', 'url' => 'solutions_archive.html' ),
	);
	$cliqhost_nav_footer_services    = array(
		array( 'label' => 'Software Engineering', 'url' => 'services_archive.html' ),
		array( 'label' => 'Cloud Engineering', 'url' => 'services_archive.html' ),
		array( 'label' => 'AI & Machine Learning', 'url' => 'services_archive.html' ),
		array( 'label' => 'Cybersecurity', 'url' => 'services_archive.html' ),
		array( 'label' => 'Data Engineering', 'url' => 'services_archive.html' ),
		array( 'label' => 'IT Consulting', 'url' => 'services_archive.html' ),
		array( 'label' => 'DevOps', 'url' => 'services_archive.html' ),
		array( 'label' => 'Support & Maintenance', 'url' => 'services_archive.html' ),
	);
	$cliqhost_nav_footer_industries  = array(
		array( 'label' => 'Finance', 'url' => 'industries_archive.html' ),
		array( 'label' => 'Healthcare', 'url' => 'industries_archive.html' ),
		array( 'label' => 'Retail', 'url' => 'industries_archive.html' ),
		array( 'label' => 'Logistics', 'url' => 'industries_archive.html' ),
		array( 'label' => 'Education', 'url' => 'industries_archive.html' ),
		array( 'label' => 'Professional Services', 'url' => 'industries_archive.html' ),
	);
	$cliqhost_nav_footer_resources   = array(
		array( 'label' => 'Insights', 'url' => 'insights_archive.html' ),
		array( 'label' => 'Case Studies', 'url' => 'case_studies_archive.html' ),
		array( 'label' => 'Careers', 'url' => 'careers_jobs_archive.html' ),
		array( 'label' => 'Contact', 'url' => 'contact_page.html' ),
	);
	$cliqhost_nav_footer_company     = array(
		array( 'label' => 'About', 'url' => 'about_page.html' ),
		array( 'label' => 'Contact', 'url' => 'contact_page.html' ),
		array( 'label' => 'Careers', 'url' => 'careers_jobs_archive.html' ),
	);
	$cliqhost_legal_links            = array(
		array( 'label' => 'Privacy Policy', 'url' => '#' ),
		array( 'label' => 'Terms of Service', 'url' => '#' ),
		array( 'label' => 'Cookie Policy', 'url' => '#' ),
	);
}

/** Render one footer nav column. Kept as a local function to avoid repeating the same markup five times. */
if ( ! function_exists( 'cliqhost_render_footer_group' ) ) {
	function cliqhost_render_footer_group( $aria_label, $heading, $links ) {
		?>
		<nav class="footer-group" aria-label="<?php echo esc_attr( $aria_label ); ?>">
			<h3 class="footer-heading"><button class="footer-toggle" type="button" aria-expanded="false"><?php echo esc_html( $heading ); ?> <svg class="icon" aria-hidden="true"><use href="#i-chev"></use></svg></button></h3>
			<ul class="footer-panel">
				<?php foreach ( $links as $link ) : ?>
				<li><a href="<?php echo esc_url( $link['url'] ); ?>"><?php echo esc_html( $link['label'] ); ?></a></li>
				<?php endforeach; ?>
			</ul>
		</nav>
		<?php
	}
}
?>
</main><!-- #page-content -->

<footer class="site-footer">
  <div class="container">

    <!-- Newsletter (always visible) -->
    <div class="footer-newsletter">
      <div class="newsletter-copy">
        <h3><?php echo esc_html( $cliqhost_newsletter_heading ); ?></h3>
        <p><?php echo esc_html( $cliqhost_newsletter_description ); ?></p>
      </div>
      <form class="newsletter-form" id="newsletter-form" action="#">
        <label class="visually-hidden" for="newsletter-email">Email address</label>
        <input type="email" id="newsletter-email" name="email" placeholder="Enter your work email" autocomplete="email" required>
        <button type="submit" class="btn btn--gold">Subscribe</button>
        <p class="newsletter-msg" id="newsletter-msg" role="status" aria-live="polite"></p>
      </form>
    </div>

    <!-- Link columns (accordions on mobile; contact info stays visible) -->
    <div class="footer-columns">
      <div class="footer-brand-col">
        <p class="footer-tagline"><?php echo esc_html( $cliqhost_footer_tagline ); ?></p>
        <ul class="footer-contact">
          <li><svg class="icon" aria-hidden="true"><use href="#i-mail"></use></svg><a href="mailto:<?php echo esc_attr( $cliqhost_contact_email ); ?>"><?php echo esc_html( $cliqhost_contact_email ); ?></a></li>
          <li><svg class="icon" aria-hidden="true"><use href="#i-phone"></use></svg><a href="tel:<?php echo esc_attr( $cliqhost_contact_phone_tel ); ?>"><?php echo esc_html( $cliqhost_contact_phone_display ); ?></a></li>
          <li><svg class="icon" aria-hidden="true"><use href="#i-pin"></use></svg><span><?php echo nl2br( esc_html( $cliqhost_contact_address ) ); ?></span></li>
        </ul>
        <ul class="social-links">
          <li><a href="<?php echo esc_url( $cliqhost_social_linkedin ? $cliqhost_social_linkedin : '#' ); ?>" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ? get_bloginfo( 'name' ) : 'CLIQHOST' ); ?> on LinkedIn"><svg class="icon" aria-hidden="true"><use href="#i-linkedin"></use></svg></a></li>
          <li><a href="<?php echo esc_url( $cliqhost_social_x ? $cliqhost_social_x : '#' ); ?>" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ? get_bloginfo( 'name' ) : 'CLIQHOST' ); ?> on X (Twitter)"><svg class="icon icon--fill" aria-hidden="true"><use href="#i-x"></use></svg></a></li>
          <li><a href="<?php echo esc_url( $cliqhost_social_github ? $cliqhost_social_github : '#' ); ?>" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ? get_bloginfo( 'name' ) : 'CLIQHOST' ); ?> on GitHub"><svg class="icon" aria-hidden="true"><use href="#i-github"></use></svg></a></li>
          <li><a href="<?php echo esc_url( $cliqhost_social_youtube ? $cliqhost_social_youtube : '#' ); ?>" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ? get_bloginfo( 'name' ) : 'CLIQHOST' ); ?> on YouTube"><svg class="icon" aria-hidden="true"><use href="#i-youtube"></use></svg></a></li>
        </ul>
      </div>

      <?php cliqhost_render_footer_group( 'Footer solutions', 'Solutions', $cliqhost_nav_footer_solutions ); ?>
      <?php cliqhost_render_footer_group( 'Footer services', 'Services', $cliqhost_nav_footer_services ); ?>
      <?php cliqhost_render_footer_group( 'Footer industries', 'Industries', $cliqhost_nav_footer_industries ); ?>

      <div class="footer-group-col">
        <?php cliqhost_render_footer_group( 'Footer resources', 'Resources', $cliqhost_nav_footer_resources ); ?>
        <?php cliqhost_render_footer_group( 'Footer company', 'Company', $cliqhost_nav_footer_company ); ?>
      </div>
    </div>

    <!-- Legal -->
    <div class="footer-bottom">
      <p class="copyright"><?php echo esc_html( $cliqhost_copyright_text ); ?></p>
      <ul class="legal-links">
        <?php foreach ( $cliqhost_legal_links as $cliqhost_link ) : ?>
        <li><a href="<?php echo esc_url( $cliqhost_link['url'] ); ?>"><?php echo esc_html( $cliqhost_link['label'] ); ?></a></li>
        <?php endforeach; ?>
      </ul>
    </div>
  </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
