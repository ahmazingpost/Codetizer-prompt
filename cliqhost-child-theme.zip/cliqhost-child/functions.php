<?php
/**
 * Cliqhost Child Theme functions and definitions.
 *
 * Loads the Hello Elementor parent stylesheet, the Cliqhost design tokens /
 * header / footer stylesheet, and the header/footer JavaScript (sticky
 * header, mobile navigation, footer accordions, footer newsletter form).
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

if ( ! function_exists( 'cliqhost_child_enqueue_assets' ) ) {
	function cliqhost_child_enqueue_assets() {

		// Hello Elementor parent stylesheet.
		wp_enqueue_style(
			'hello-elementor-parent',
			get_template_directory_uri() . '/style.css',
			array(),
			wp_get_theme( get_template() )->get( 'Version' )
		);

		// Child theme stylesheet (required header block only — see style.css).
		wp_enqueue_style(
			'cliqhost-child-style',
			get_stylesheet_uri(),
			array( 'hello-elementor-parent' ),
			wp_get_theme()->get( 'Version' )
		);

		// Cliqhost design tokens, reset, and header/footer styles.
		wp_enqueue_style(
			'cliqhost-header-footer',
			get_stylesheet_directory_uri() . '/assets/css/header-footer.css',
			array( 'cliqhost-child-style' ),
			wp_get_theme()->get( 'Version' )
		);

		// Header/footer interactions (sticky header, mobile nav, footer accordions, newsletter).
		wp_enqueue_script(
			'cliqhost-header-footer-js',
			get_stylesheet_directory_uri() . '/assets/js/header-footer.js',
			array(),
			wp_get_theme()->get( 'Version' ),
			true
		);
	}
	add_action( 'wp_enqueue_scripts', 'cliqhost_child_enqueue_assets' );
}
