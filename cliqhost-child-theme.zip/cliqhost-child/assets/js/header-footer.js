/*
 * Cliqhost header/footer interactions.
 * Extracted verbatim from the supplied HTML design's global script (sticky header,
 * mobile navigation, footer accordions, footer newsletter form) — unmodified except
 * for the NEXORA -> CLIQHOST brand rename.
 */
(function () {
  'use strict';
  var doc = document;

  function onMediaQuery(mq, handler) {
    if (mq.addEventListener) { mq.addEventListener('change', handler); }
    else if (mq.addListener) { mq.addListener(handler); }
  }

  /* 1. Sticky header shadow ------------------------------------------------ */
  var header = doc.querySelector('.site-header');
  if (header) {
    var onScroll = function () {
      header.classList.toggle('is-scrolled', window.scrollY > 8);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* 2. Mobile navigation ---------------------------------------------------- */
  var navToggle = doc.querySelector('.nav-toggle');
  var navPanel = doc.getElementById('mobile-menu');
  function setNav(open) {
    if (!navToggle || !navPanel) { return; }
    navToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    navToggle.setAttribute('aria-label', open ? 'Close menu' : 'Open menu');
    navPanel.classList.toggle('is-open', open);
    doc.body.classList.toggle('nav-open', open);
  }
  if (navToggle && navPanel) {
    navToggle.addEventListener('click', function () {
      setNav(navToggle.getAttribute('aria-expanded') !== 'true');
    });
    navPanel.addEventListener('click', function (event) {
      if (event.target.closest('a')) { setNav(false); }
    });
    doc.addEventListener('keydown', function (event) {
      if (event.key === 'Escape' && navPanel.classList.contains('is-open')) {
        setNav(false);
        navToggle.focus();
      }
    });
    var desktopMq = window.matchMedia('(min-width: 1080px)');
    onMediaQuery(desktopMq, function (event) {
      if (event.matches) { setNav(false); }
    });
  }

  /* 3. Footer accordions (mobile only) --------------------------------------- */
  var footerMq = window.matchMedia('(max-width: 767.98px)');
  var footerGroups = Array.prototype.slice.call(doc.querySelectorAll('.footer-group'));
  function syncFooterGroups() {
    footerGroups.forEach(function (group) {
      var btn = group.querySelector('.footer-toggle');
      if (!btn) { return; }
      if (!footerMq.matches) {
        group.classList.add('is-open');
        btn.setAttribute('aria-expanded', 'true');
        btn.tabIndex = -1;
      } else {
        btn.tabIndex = 0;
        btn.setAttribute('aria-expanded', group.classList.contains('is-open') ? 'true' : 'false');
      }
    });
  }
  footerGroups.forEach(function (group) {
    var btn = group.querySelector('.footer-toggle');
    if (!btn) { return; }
    btn.addEventListener('click', function () {
      if (!footerMq.matches) { return; }
      var open = group.classList.toggle('is-open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  });
  syncFooterGroups();
  onMediaQuery(footerMq, syncFooterGroups);

  /* 4. Newsletter (demo only — no data is sent) ---------------------------------- */
  var form = doc.getElementById('newsletter-form');
  var msg = doc.getElementById('newsletter-msg');
  if (form && msg) {
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      var email = doc.getElementById('newsletter-email');
      if (email && !email.value) {
        msg.textContent = 'Please enter your email address.';
        return;
      }
      form.reset();
      msg.textContent = 'Thanks for subscribing! (Demo form — no data is sent.)';
    });
  }
})();
