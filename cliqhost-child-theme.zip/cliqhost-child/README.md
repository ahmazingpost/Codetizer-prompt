# Cliqhost Child (Hello Elementor child theme)

A child theme of **Hello Elementor** that supplies the site-wide header and
footer, converted from the supplied HTML design. Page content itself is
built separately in Elementor using the section files already delivered.

## Install

1. Install and activate the parent theme **Hello Elementor** first.
2. Upload/activate this `cliqhost-child` theme.
3. Install and activate the companion **Cliqhost Header & Footer Editor**
   plugin (delivered separately) to edit links, labels, the logo link,
   contact info, social links and legal links from Settings → Header & Footer.
   The theme works fine without the plugin too — it just falls back to the
   original design's content until the plugin is active.

## What's inside

- `style.css` — required child-theme header block only (declares the
  `hello-elementor` parent). The actual CSS lives in `assets/css/`.
- `functions.php` — enqueues the parent stylesheet, then
  `assets/css/header-footer.css`, then `assets/js/header-footer.js`; also
  hides Hello Elementor's default page title (see below).
- `header.php` — the `<head>`, opening `<body>`, skip link, hidden icon
  sprite, site header (logo, nav, mobile toggle), and mobile nav panel.
  Content is pulled from the editor plugin when active. Opens
  `<main id="page-content">`, which Elementor fills with your page content.
- `footer.php` — closes `<main>`, outputs the site footer (newsletter
  form, all five link columns, contact info, social links, legal row),
  then `wp_footer()`. Content is pulled from the editor plugin when active.
- `assets/css/header-footer.css` — the full design-token/reset/component
  stylesheet from the supplied design (same one embedded in every
  Elementor section file), plus the Cliqhost-specific additions listed
  below, appended at the end of the file in their own clearly marked
  section.
- `assets/js/header-footer.js` — sticky header on scroll, mobile menu
  open/close, footer accordions (mobile), and the footer newsletter form
  — extracted verbatim from the original site's script.

## What changed in this revision

1. **Full-width header & footer.** The header and footer's inner content
   now stretches the full width of the viewport instead of being capped
   by the shared `.container` max-width. This only touches the header and
   footer — page content built in Elementor still uses the normal
   `.container` width everywhere else, since the override targets
   `.site-header .header-inner` and `.site-footer .container`
   specifically.
2. **Page title hidden.** Hello Elementor's default page-title bar is
   disabled via `add_filter( 'hello_elementor_page_title', '__return_false' )`
   in `functions.php`, with a small CSS rule as a backup in case a
   theme-builder plugin outputs its own title element instead.
3. **Header & Footer Editor plugin.** All header/footer links, labels,
   the logo link, contact details, social links, and legal links are now
   editable from the WordPress admin (Settings → Header & Footer) instead
   of being hardcoded — see the plugin's own README.
4. **Responsive audit.** Reviewed every header/footer breakpoint
   (mobile hamburger nav below 1080px, 2-column then 5-column footer
   grid at 768px/1100px, mobile footer accordions). No collapsing,
   overlapping, or broken layouts were found in the original design's
   responsive rules, so nothing there needed changing.

## Notes carried over from the original conversion

Everything above is the original design, copied as-is, with the brand
renamed from NEXORA to CLIQHOST throughout. Two small, necessary
technical fixes remain from the original build, both purely functional:

1. **Logo link** defaults to `home_url()` (editable in the plugin)
   instead of the static placeholder filename `homepage_cliqhost.html`.
2. **"About" active-state** (`is-active` / `aria-current="page"`) was
   removed from the nav, since it was hardcoded onto the About link in
   the source page it was pulled from — on a shared header that would
   incorrectly mark "About" as the current page everywhere.

All footer/header navigation links still default to the same static
filenames used throughout the rest of the delivered project
(`solutions_archive.html`, `contact_page.html`, etc.) — update these
(via the plugin, no code editing needed) to your real WordPress
permalinks when the pages go live.
