# Cliqhost Child (Hello Elementor child theme)

A child theme of **Hello Elementor** that supplies the site-wide header and
footer, converted from the supplied HTML design. Page content itself is
built separately in Elementor using the section files already delivered.

## Install

1. Install and activate the parent theme **Hello Elementor** first.
2. Zip this `cliqhost-child` folder and upload it via
   Appearance → Themes → Add New → Upload Theme, or upload the folder
   directly to `/wp-content/themes/`.
3. Activate **Cliqhost Child**.

## What's inside

- `style.css` — required child-theme header block only (declares the
  `hello-elementor` parent). The actual CSS lives in `assets/css/`.
- `functions.php` — enqueues the parent stylesheet, then
  `assets/css/header-footer.css`, then `assets/js/header-footer.js`.
- `header.php` — the `<head>`, opening `<body>`, skip link, hidden icon
  sprite, site header (logo, nav, mobile toggle), and mobile nav panel.
  Opens `<main id="page-content">`, which Hello Elementor / Elementor
  fills with your page content.
- `footer.php` — closes `<main>`, outputs the site footer (newsletter
  form, link columns, legal row), then `wp_footer()`.
- `assets/css/header-footer.css` — the full design-token/reset/component
  stylesheet from the supplied design (same one embedded in every
  Elementor section file), so the header and footer render identically
  without depending on any particular page's Elementor content.
- `assets/js/header-footer.js` — sticky header on scroll, mobile menu
  open/close, footer accordions (mobile), and the footer newsletter form
  — extracted verbatim from the original site's script.

## Adjustments made (name changes only, not a redesign)

Everything above is the original design, copied as-is, with the brand
renamed from NEXORA to CLIQHOST throughout. Two small, necessary
technical fixes were made so the header/footer work correctly as a
*shared, site-wide* template instead of a single static page:

1. **Logo link** now points to `home_url()` instead of the static
   placeholder filename `homepage_cliqhost.html`.
2. **"About" active-state** (`is-active` / `aria-current="page"`) was
   removed from the nav, since that was hardcoded onto the About link
   in the source file it was pulled from — on a shared header that
   would incorrectly mark "About" as the current page everywhere. If
   you want the active link to reflect the real current page, this can
   be added back with a WordPress conditional (e.g. `is_page()`) once
   your actual page slugs are set up.

All other links (nav items, footer columns) still point to the same
static filenames used throughout the rest of the delivered project
(`solutions_archive.html`, `contact_page.html`, etc.) — update these to
your real WordPress permalinks when the pages go live.
